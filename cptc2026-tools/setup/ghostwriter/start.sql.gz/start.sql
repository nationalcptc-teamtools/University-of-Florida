--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4 (Debian 16.4-1.pgdg120+2)
-- Dumped by pg_dump version 16.4 (Debian 16.4-1.pgdg120+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hdb_catalog; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA hdb_catalog;


ALTER SCHEMA hdb_catalog OWNER TO postgres;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: gen_hasura_uuid(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog.gen_hasura_uuid() RETURNS uuid
    LANGUAGE sql
    AS $$select gen_random_uuid()$$;


ALTER FUNCTION hdb_catalog.gen_hasura_uuid() OWNER TO postgres;

--
-- Name: insert_event_log(text, text, text, text, json); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog.insert_event_log(schema_name text, table_name text, trigger_name text, op text, row_data json) RETURNS text
    LANGUAGE plpgsql
    AS $$
  DECLARE
    id text;
    payload json;
    session_variables json;
    server_version_num int;
    trace_context json;
  BEGIN
    id := gen_random_uuid();
    server_version_num := current_setting('server_version_num');
    IF server_version_num >= 90600 THEN
      session_variables := current_setting('hasura.user', 't');
      trace_context := current_setting('hasura.tracecontext', 't');
    ELSE
      BEGIN
        session_variables := current_setting('hasura.user');
      EXCEPTION WHEN OTHERS THEN
                  session_variables := NULL;
      END;
      BEGIN
        trace_context := current_setting('hasura.tracecontext');
      EXCEPTION WHEN OTHERS THEN
        trace_context := NULL;
      END;
    END IF;
    payload := json_build_object(
      'op', op,
      'data', row_data,
      'session_variables', session_variables,
      'trace_context', trace_context
    );
    INSERT INTO hdb_catalog.event_log
                (id, schema_name, table_name, trigger_name, payload)
    VALUES
    (id, schema_name, table_name, trigger_name, payload);
    RETURN id;
  END;
$$;


ALTER FUNCTION hdb_catalog.insert_event_log(schema_name text, table_name text, trigger_name text, op text, row_data json) OWNER TO postgres;

--
-- Name: notify_hasura_CleanDomainName_INSERT(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_CleanDomainName_INSERT"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."burned_explanation" , OLD."expiration" , OLD."expired" , OLD."note" , OLD."domain_status_id" , OLD."health_status_id" , OLD."whois_status_id" , OLD."vt_permalink" , OLD."dns" , OLD."last_used_by_id" , OLD."id" , OLD."reset_dns" , OLD."registrar" , OLD."categorization" , OLD."extra_fields" , OLD."last_health_check" , OLD."creation" , OLD."name" , OLD."auto_renew"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."burned_explanation" , NEW."expiration" , NEW."expired" , NEW."note" , NEW."domain_status_id" , NEW."health_status_id" , NEW."whois_status_id" , NEW."vt_permalink" , NEW."dns" , NEW."last_used_by_id" , NEW."id" , NEW."reset_dns" , NEW."registrar" , NEW."categorization" , NEW."extra_fields" , NEW."last_health_check" , NEW."creation" , NEW."name" , NEW."auto_renew"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', NULL,
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."burned_explanation" , NEW."expiration" , NEW."expired" , NEW."note" , NEW."domain_status_id" , NEW."health_status_id" , NEW."whois_status_id" , NEW."vt_permalink" , NEW."dns" , NEW."last_used_by_id" , NEW."id" , NEW."reset_dns" , NEW."registrar" , NEW."categorization" , NEW."extra_fields" , NEW."last_health_check" , NEW."creation" , NEW."name" , NEW."auto_renew"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('shepherd_domain' AS text), CAST('CleanDomainName' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('shepherd_domain' AS text), CAST('CleanDomainName' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_CleanDomainName_INSERT"() OWNER TO postgres;

--
-- Name: notify_hasura_CleanDomainName_UPDATE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_CleanDomainName_UPDATE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."domain_status_id" , OLD."name"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."domain_status_id" , NEW."name"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."burned_explanation" , OLD."expiration" , OLD."expired" , OLD."note" , OLD."domain_status_id" , OLD."health_status_id" , OLD."whois_status_id" , OLD."vt_permalink" , OLD."dns" , OLD."last_used_by_id" , OLD."id" , OLD."reset_dns" , OLD."registrar" , OLD."categorization" , OLD."extra_fields" , OLD."last_health_check" , OLD."creation" , OLD."name" , OLD."auto_renew"        ) AS "e"      ) ),
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."burned_explanation" , NEW."expiration" , NEW."expired" , NEW."note" , NEW."domain_status_id" , NEW."health_status_id" , NEW."whois_status_id" , NEW."vt_permalink" , NEW."dns" , NEW."last_used_by_id" , NEW."id" , NEW."reset_dns" , NEW."registrar" , NEW."categorization" , NEW."extra_fields" , NEW."last_health_check" , NEW."creation" , NEW."name" , NEW."auto_renew"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('shepherd_domain' AS text), CAST('CleanDomainName' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('shepherd_domain' AS text), CAST('CleanDomainName' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_CleanDomainName_UPDATE"() OWNER TO postgres;

--
-- Name: notify_hasura_CreateOplogEntry_INSERT(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_CreateOplogEntry_INSERT"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."operator_name" , OLD."dest_ip" , OLD."output" , OLD."entry_identifier" , OLD."user_context" , OLD."id" , OLD."tool" , OLD."description" , OLD."extra_fields" , OLD."end_date" , OLD."source_ip" , OLD."command" , OLD."comments" , OLD."oplog_id_id" , OLD."start_date"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."operator_name" , NEW."dest_ip" , NEW."output" , NEW."entry_identifier" , NEW."user_context" , NEW."id" , NEW."tool" , NEW."description" , NEW."extra_fields" , NEW."end_date" , NEW."source_ip" , NEW."command" , NEW."comments" , NEW."oplog_id_id" , NEW."start_date"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', NULL,
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."operator_name" , NEW."dest_ip" , NEW."output" , NEW."entry_identifier" , NEW."user_context" , NEW."id" , NEW."tool" , NEW."description" , NEW."extra_fields" , NEW."end_date" , NEW."source_ip" , NEW."command" , NEW."comments" , NEW."oplog_id_id" , NEW."start_date"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('oplog_oplogentry' AS text), CAST('CreateOplogEntry' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('oplog_oplogentry' AS text), CAST('CreateOplogEntry' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_CreateOplogEntry_INSERT"() OWNER TO postgres;

--
-- Name: notify_hasura_CreateReportFinding_INSERT(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_CreateReportFinding_INSERT"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."report_id" , OLD."assigned_to_id" , OLD."host_detection_techniques" , OLD."severity_id" , OLD."finding_guidance" , OLD."complete" , OLD."impact" , OLD."added_as_blank" , OLD."id" , OLD."references" , OLD."description" , OLD."finding_type_id" , OLD."network_detection_techniques" , OLD."cvss_score" , OLD."cvss_vector" , OLD."replication_steps" , OLD."title" , OLD."mitigation" , OLD."extra_fields" , OLD."affected_entities" , OLD."position"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."report_id" , NEW."assigned_to_id" , NEW."host_detection_techniques" , NEW."severity_id" , NEW."finding_guidance" , NEW."complete" , NEW."impact" , NEW."added_as_blank" , NEW."id" , NEW."references" , NEW."description" , NEW."finding_type_id" , NEW."network_detection_techniques" , NEW."cvss_score" , NEW."cvss_vector" , NEW."replication_steps" , NEW."title" , NEW."mitigation" , NEW."extra_fields" , NEW."affected_entities" , NEW."position"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', NULL,
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."report_id" , NEW."assigned_to_id" , NEW."host_detection_techniques" , NEW."severity_id" , NEW."finding_guidance" , NEW."complete" , NEW."impact" , NEW."added_as_blank" , NEW."id" , NEW."references" , NEW."description" , NEW."finding_type_id" , NEW."network_detection_techniques" , NEW."cvss_score" , NEW."cvss_vector" , NEW."replication_steps" , NEW."title" , NEW."mitigation" , NEW."extra_fields" , NEW."affected_entities" , NEW."position"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_reportfindinglink' AS text), CAST('CreateReportFinding' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_reportfindinglink' AS text), CAST('CreateReportFinding' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_CreateReportFinding_INSERT"() OWNER TO postgres;

--
-- Name: notify_hasura_CreateReportFinding_UPDATE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_CreateReportFinding_UPDATE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."severity_id" , OLD."position"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."severity_id" , NEW."position"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."report_id" , OLD."assigned_to_id" , OLD."host_detection_techniques" , OLD."severity_id" , OLD."finding_guidance" , OLD."complete" , OLD."impact" , OLD."added_as_blank" , OLD."id" , OLD."references" , OLD."description" , OLD."finding_type_id" , OLD."network_detection_techniques" , OLD."cvss_score" , OLD."cvss_vector" , OLD."replication_steps" , OLD."title" , OLD."mitigation" , OLD."extra_fields" , OLD."affected_entities" , OLD."position"        ) AS "e"      ) ),
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."report_id" , NEW."assigned_to_id" , NEW."host_detection_techniques" , NEW."severity_id" , NEW."finding_guidance" , NEW."complete" , NEW."impact" , NEW."added_as_blank" , NEW."id" , NEW."references" , NEW."description" , NEW."finding_type_id" , NEW."network_detection_techniques" , NEW."cvss_score" , NEW."cvss_vector" , NEW."replication_steps" , NEW."title" , NEW."mitigation" , NEW."extra_fields" , NEW."affected_entities" , NEW."position"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_reportfindinglink' AS text), CAST('CreateReportFinding' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_reportfindinglink' AS text), CAST('CreateReportFinding' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_CreateReportFinding_UPDATE"() OWNER TO postgres;

--
-- Name: notify_hasura_DeleteOplogEntry_DELETE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_DeleteOplogEntry_DELETE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."operator_name" , OLD."dest_ip" , OLD."output" , OLD."entry_identifier" , OLD."user_context" , OLD."id" , OLD."tool" , OLD."description" , OLD."extra_fields" , OLD."end_date" , OLD."source_ip" , OLD."command" , OLD."comments" , OLD."oplog_id_id" , OLD."start_date"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."operator_name" , NEW."dest_ip" , NEW."output" , NEW."entry_identifier" , NEW."user_context" , NEW."id" , NEW."tool" , NEW."description" , NEW."extra_fields" , NEW."end_date" , NEW."source_ip" , NEW."command" , NEW."comments" , NEW."oplog_id_id" , NEW."start_date"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."operator_name" , OLD."dest_ip" , OLD."output" , OLD."entry_identifier" , OLD."user_context" , OLD."id" , OLD."tool" , OLD."description" , OLD."extra_fields" , OLD."end_date" , OLD."source_ip" , OLD."command" , OLD."comments" , OLD."oplog_id_id" , OLD."start_date"        ) AS "e"      ) ),
      'new', NULL
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('oplog_oplogentry' AS text), CAST('DeleteOplogEntry' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('oplog_oplogentry' AS text), CAST('DeleteOplogEntry' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_DeleteOplogEntry_DELETE"() OWNER TO postgres;

--
-- Name: notify_hasura_DeleteReportFinding_DELETE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_DeleteReportFinding_DELETE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."report_id" , OLD."assigned_to_id" , OLD."host_detection_techniques" , OLD."severity_id" , OLD."finding_guidance" , OLD."complete" , OLD."impact" , OLD."added_as_blank" , OLD."id" , OLD."references" , OLD."description" , OLD."finding_type_id" , OLD."network_detection_techniques" , OLD."cvss_score" , OLD."cvss_vector" , OLD."replication_steps" , OLD."title" , OLD."mitigation" , OLD."extra_fields" , OLD."affected_entities" , OLD."position"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."report_id" , NEW."assigned_to_id" , NEW."host_detection_techniques" , NEW."severity_id" , NEW."finding_guidance" , NEW."complete" , NEW."impact" , NEW."added_as_blank" , NEW."id" , NEW."references" , NEW."description" , NEW."finding_type_id" , NEW."network_detection_techniques" , NEW."cvss_score" , NEW."cvss_vector" , NEW."replication_steps" , NEW."title" , NEW."mitigation" , NEW."extra_fields" , NEW."affected_entities" , NEW."position"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."report_id" , OLD."assigned_to_id" , OLD."host_detection_techniques" , OLD."severity_id" , OLD."finding_guidance" , OLD."complete" , OLD."impact" , OLD."added_as_blank" , OLD."id" , OLD."references" , OLD."description" , OLD."finding_type_id" , OLD."network_detection_techniques" , OLD."cvss_score" , OLD."cvss_vector" , OLD."replication_steps" , OLD."title" , OLD."mitigation" , OLD."extra_fields" , OLD."affected_entities" , OLD."position"        ) AS "e"      ) ),
      'new', NULL
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_reportfindinglink' AS text), CAST('DeleteReportFinding' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_reportfindinglink' AS text), CAST('DeleteReportFinding' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_DeleteReportFinding_DELETE"() OWNER TO postgres;

--
-- Name: notify_hasura_EvidenceUpdate_DELETE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_EvidenceUpdate_DELETE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."report_id" , OLD."upload_date" , OLD."document" , OLD."id" , OLD."caption" , OLD."uploaded_by_id" , OLD."description" , OLD."friendly_name" , OLD."finding_id"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."report_id" , NEW."upload_date" , NEW."document" , NEW."id" , NEW."caption" , NEW."uploaded_by_id" , NEW."description" , NEW."friendly_name" , NEW."finding_id"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."report_id" , OLD."upload_date" , OLD."document" , OLD."id" , OLD."caption" , OLD."uploaded_by_id" , OLD."description" , OLD."friendly_name" , OLD."finding_id"        ) AS "e"      ) ),
      'new', NULL
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_evidence' AS text), CAST('EvidenceUpdate' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_evidence' AS text), CAST('EvidenceUpdate' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_EvidenceUpdate_DELETE"() OWNER TO postgres;

--
-- Name: notify_hasura_EvidenceUpdate_UPDATE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_EvidenceUpdate_UPDATE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."document" , OLD."friendly_name"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."document" , NEW."friendly_name"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."report_id" , OLD."upload_date" , OLD."document" , OLD."id" , OLD."caption" , OLD."uploaded_by_id" , OLD."description" , OLD."friendly_name" , OLD."finding_id"        ) AS "e"      ) ),
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."report_id" , NEW."upload_date" , NEW."document" , NEW."id" , NEW."caption" , NEW."uploaded_by_id" , NEW."description" , NEW."friendly_name" , NEW."finding_id"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_evidence' AS text), CAST('EvidenceUpdate' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('reporting_evidence' AS text), CAST('EvidenceUpdate' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_EvidenceUpdate_UPDATE"() OWNER TO postgres;

--
-- Name: notify_hasura_UpdateOplogEntry_UPDATE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_UpdateOplogEntry_UPDATE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."operator_name" , OLD."dest_ip" , OLD."output" , OLD."entry_identifier" , OLD."user_context" , OLD."id" , OLD."tool" , OLD."description" , OLD."extra_fields" , OLD."end_date" , OLD."source_ip" , OLD."command" , OLD."comments" , OLD."oplog_id_id" , OLD."start_date"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."operator_name" , NEW."dest_ip" , NEW."output" , NEW."entry_identifier" , NEW."user_context" , NEW."id" , NEW."tool" , NEW."description" , NEW."extra_fields" , NEW."end_date" , NEW."source_ip" , NEW."command" , NEW."comments" , NEW."oplog_id_id" , NEW."start_date"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."operator_name" , OLD."dest_ip" , OLD."output" , OLD."entry_identifier" , OLD."user_context" , OLD."id" , OLD."tool" , OLD."description" , OLD."extra_fields" , OLD."end_date" , OLD."source_ip" , OLD."command" , OLD."comments" , OLD."oplog_id_id" , OLD."start_date"        ) AS "e"      ) ),
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."operator_name" , NEW."dest_ip" , NEW."output" , NEW."entry_identifier" , NEW."user_context" , NEW."id" , NEW."tool" , NEW."description" , NEW."extra_fields" , NEW."end_date" , NEW."source_ip" , NEW."command" , NEW."comments" , NEW."oplog_id_id" , NEW."start_date"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('oplog_oplogentry' AS text), CAST('UpdateOplogEntry' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('oplog_oplogentry' AS text), CAST('UpdateOplogEntry' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_UpdateOplogEntry_UPDATE"() OWNER TO postgres;

--
-- Name: notify_hasura_UpdateProjectContact_INSERT(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_UpdateProjectContact_INSERT"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."note" , OLD."project_id" , OLD."timezone" , OLD."job_title" , OLD."phone" , OLD."id" , OLD."primary" , OLD."name" , OLD."email"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."note" , NEW."project_id" , NEW."timezone" , NEW."job_title" , NEW."phone" , NEW."id" , NEW."primary" , NEW."name" , NEW."email"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', NULL,
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."note" , NEW."project_id" , NEW."timezone" , NEW."job_title" , NEW."phone" , NEW."id" , NEW."primary" , NEW."name" , NEW."email"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectcontact' AS text), CAST('UpdateProjectContact' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectcontact' AS text), CAST('UpdateProjectContact' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_UpdateProjectContact_INSERT"() OWNER TO postgres;

--
-- Name: notify_hasura_UpdateProjectContact_UPDATE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_UpdateProjectContact_UPDATE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."primary"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."primary"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."note" , OLD."project_id" , OLD."timezone" , OLD."job_title" , OLD."phone" , OLD."id" , OLD."primary" , OLD."name" , OLD."email"        ) AS "e"      ) ),
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."note" , NEW."project_id" , NEW."timezone" , NEW."job_title" , NEW."phone" , NEW."id" , NEW."primary" , NEW."name" , NEW."email"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectcontact' AS text), CAST('UpdateProjectContact' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectcontact' AS text), CAST('UpdateProjectContact' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_UpdateProjectContact_UPDATE"() OWNER TO postgres;

--
-- Name: notify_hasura_UpdateProjectObjective_INSERT(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_UpdateProjectObjective_INSERT"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."project_id" , OLD."status_id" , OLD."complete" , OLD."result" , OLD."marked_complete" , OLD."deadline" , OLD."id" , OLD."description" , OLD."objective" , OLD."priority_id" , OLD."position"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."project_id" , NEW."status_id" , NEW."complete" , NEW."result" , NEW."marked_complete" , NEW."deadline" , NEW."id" , NEW."description" , NEW."objective" , NEW."priority_id" , NEW."position"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', NULL,
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."project_id" , NEW."status_id" , NEW."complete" , NEW."result" , NEW."marked_complete" , NEW."deadline" , NEW."id" , NEW."description" , NEW."objective" , NEW."priority_id" , NEW."position"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectobjective' AS text), CAST('UpdateProjectObjective' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectobjective' AS text), CAST('UpdateProjectObjective' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_UpdateProjectObjective_INSERT"() OWNER TO postgres;

--
-- Name: notify_hasura_UpdateProjectObjective_UPDATE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_UpdateProjectObjective_UPDATE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."complete" , OLD."deadline"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."complete" , NEW."deadline"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."project_id" , OLD."status_id" , OLD."complete" , OLD."result" , OLD."marked_complete" , OLD."deadline" , OLD."id" , OLD."description" , OLD."objective" , OLD."priority_id" , OLD."position"        ) AS "e"      ) ),
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."project_id" , NEW."status_id" , NEW."complete" , NEW."result" , NEW."marked_complete" , NEW."deadline" , NEW."id" , NEW."description" , NEW."objective" , NEW."priority_id" , NEW."position"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectobjective' AS text), CAST('UpdateProjectObjective' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectobjective' AS text), CAST('UpdateProjectObjective' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_UpdateProjectObjective_UPDATE"() OWNER TO postgres;

--
-- Name: notify_hasura_UpdateProjectSubTask_INSERT(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_UpdateProjectSubTask_INSERT"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."status_id" , OLD."complete" , OLD."parent_id" , OLD."marked_complete" , OLD."deadline" , OLD."id" , OLD."task"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."status_id" , NEW."complete" , NEW."parent_id" , NEW."marked_complete" , NEW."deadline" , NEW."id" , NEW."task"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', NULL,
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."status_id" , NEW."complete" , NEW."parent_id" , NEW."marked_complete" , NEW."deadline" , NEW."id" , NEW."task"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectsubtask' AS text), CAST('UpdateProjectSubTask' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectsubtask' AS text), CAST('UpdateProjectSubTask' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_UpdateProjectSubTask_INSERT"() OWNER TO postgres;

--
-- Name: notify_hasura_UpdateProjectSubTask_UPDATE(); Type: FUNCTION; Schema: hdb_catalog; Owner: postgres
--

CREATE FUNCTION hdb_catalog."notify_hasura_UpdateProjectSubTask_UPDATE"() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
  DECLARE
    _old record;
    _new record;
    _data json;
  BEGIN
    IF TG_OP = 'UPDATE' THEN
      _old := row((SELECT  "e"  FROM  (SELECT  OLD."complete" , OLD."deadline"        ) AS "e"      ) );
      _new := row((SELECT  "e"  FROM  (SELECT  NEW."complete" , NEW."deadline"        ) AS "e"      ) );
    ELSE
    /* initialize _old and _new with dummy values for INSERT and UPDATE events*/
      _old := row((select 1));
      _new := row((select 1));
    END IF;
    _data := json_build_object(
      'old', row_to_json((SELECT  "e"  FROM  (SELECT  OLD."status_id" , OLD."complete" , OLD."parent_id" , OLD."marked_complete" , OLD."deadline" , OLD."id" , OLD."task"        ) AS "e"      ) ),
      'new', row_to_json((SELECT  "e"  FROM  (SELECT  NEW."status_id" , NEW."complete" , NEW."parent_id" , NEW."marked_complete" , NEW."deadline" , NEW."id" , NEW."task"        ) AS "e"      ) )
    );
    BEGIN
    /* NOTE: formerly we used TG_TABLE_NAME in place of tableName here. However in the case of
    partitioned tables this will give the name of the partitioned table and since we use the table name to
    get the event trigger configuration from the schema, this fails because the event trigger is only created
    on the original table.  */
      IF (TG_OP <> 'UPDATE') OR (_old <> _new) THEN
        PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectsubtask' AS text), CAST('UpdateProjectSubTask' AS text), TG_OP, _data);
      END IF;
      EXCEPTION WHEN undefined_function THEN
        IF (TG_OP <> 'UPDATE') OR (_old *<> _new) THEN
          PERFORM hdb_catalog.insert_event_log(CAST('public' AS text), CAST('rolodex_projectsubtask' AS text), CAST('UpdateProjectSubTask' AS text), TG_OP, _data);
        END IF;
    END;

    RETURN NULL;
  END;
$$;


ALTER FUNCTION hdb_catalog."notify_hasura_UpdateProjectSubTask_UPDATE"() OWNER TO postgres;

--
-- Name: is_timezone(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.is_timezone() RETURNS trigger
    LANGUAGE plpgsql STABLE
    AS $$
            BEGIN
                IF EXISTS(SELECT *
                    FROM pg_timezone_names
                    WHERE LOWER(name) = LOWER(NEW.timezone)
                ) THEN
                    RETURN NEW;
                ELSE
                    RAISE EXCEPTION 'Invalid timezone: "%"',NEW.timezone;
                END IF;
            END;
            $$;


ALTER FUNCTION public.is_timezone() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: event_invocation_logs; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.event_invocation_logs (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    trigger_name text,
    event_id text,
    status integer,
    request json,
    response json,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE hdb_catalog.event_invocation_logs OWNER TO postgres;

--
-- Name: event_log; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.event_log (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    schema_name text NOT NULL,
    table_name text NOT NULL,
    trigger_name text NOT NULL,
    payload jsonb NOT NULL,
    delivered boolean DEFAULT false NOT NULL,
    error boolean DEFAULT false NOT NULL,
    tries integer DEFAULT 0 NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    locked timestamp with time zone,
    next_retry_at timestamp without time zone,
    archived boolean DEFAULT false NOT NULL
);


ALTER TABLE hdb_catalog.event_log OWNER TO postgres;

--
-- Name: hdb_action_log; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_action_log (
    id uuid DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    action_name text,
    input_payload jsonb NOT NULL,
    request_headers jsonb NOT NULL,
    session_variables jsonb NOT NULL,
    response_payload jsonb,
    errors jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    response_received_at timestamp with time zone,
    status text NOT NULL,
    CONSTRAINT hdb_action_log_status_check CHECK ((status = ANY (ARRAY['created'::text, 'processing'::text, 'completed'::text, 'error'::text])))
);


ALTER TABLE hdb_catalog.hdb_action_log OWNER TO postgres;

--
-- Name: hdb_cron_event_invocation_logs; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_cron_event_invocation_logs (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    event_id text,
    status integer,
    request json,
    response json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE hdb_catalog.hdb_cron_event_invocation_logs OWNER TO postgres;

--
-- Name: hdb_cron_events; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_cron_events (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    trigger_name text NOT NULL,
    scheduled_time timestamp with time zone NOT NULL,
    status text DEFAULT 'scheduled'::text NOT NULL,
    tries integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    next_retry_at timestamp with time zone,
    CONSTRAINT valid_status CHECK ((status = ANY (ARRAY['scheduled'::text, 'locked'::text, 'delivered'::text, 'error'::text, 'dead'::text])))
);


ALTER TABLE hdb_catalog.hdb_cron_events OWNER TO postgres;

--
-- Name: hdb_event_log_cleanups; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_event_log_cleanups (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    trigger_name text NOT NULL,
    scheduled_at timestamp without time zone NOT NULL,
    deleted_event_logs integer,
    deleted_event_invocation_logs integer,
    status text NOT NULL,
    CONSTRAINT hdb_event_log_cleanups_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'paused'::text, 'completed'::text, 'dead'::text])))
);


ALTER TABLE hdb_catalog.hdb_event_log_cleanups OWNER TO postgres;

--
-- Name: hdb_metadata; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_metadata (
    id integer NOT NULL,
    metadata json NOT NULL,
    resource_version integer DEFAULT 1 NOT NULL
);


ALTER TABLE hdb_catalog.hdb_metadata OWNER TO postgres;

--
-- Name: hdb_scheduled_event_invocation_logs; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_scheduled_event_invocation_logs (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    event_id text,
    status integer,
    request json,
    response json,
    created_at timestamp with time zone DEFAULT now()
);


ALTER TABLE hdb_catalog.hdb_scheduled_event_invocation_logs OWNER TO postgres;

--
-- Name: hdb_scheduled_events; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_scheduled_events (
    id text DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    webhook_conf json NOT NULL,
    scheduled_time timestamp with time zone NOT NULL,
    retry_conf json,
    payload json,
    header_conf json,
    status text DEFAULT 'scheduled'::text NOT NULL,
    tries integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    next_retry_at timestamp with time zone,
    comment text,
    CONSTRAINT valid_status CHECK ((status = ANY (ARRAY['scheduled'::text, 'locked'::text, 'delivered'::text, 'error'::text, 'dead'::text])))
);


ALTER TABLE hdb_catalog.hdb_scheduled_events OWNER TO postgres;

--
-- Name: hdb_schema_notifications; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_schema_notifications (
    id integer NOT NULL,
    notification json NOT NULL,
    resource_version integer DEFAULT 1 NOT NULL,
    instance_id uuid NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT hdb_schema_notifications_id_check CHECK ((id = 1))
);


ALTER TABLE hdb_catalog.hdb_schema_notifications OWNER TO postgres;

--
-- Name: hdb_source_catalog_version; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_source_catalog_version (
    version text NOT NULL,
    upgraded_on timestamp with time zone NOT NULL
);


ALTER TABLE hdb_catalog.hdb_source_catalog_version OWNER TO postgres;

--
-- Name: hdb_version; Type: TABLE; Schema: hdb_catalog; Owner: postgres
--

CREATE TABLE hdb_catalog.hdb_version (
    hasura_uuid uuid DEFAULT hdb_catalog.gen_hasura_uuid() NOT NULL,
    version text NOT NULL,
    upgraded_on timestamp with time zone NOT NULL,
    cli_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    console_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    ee_client_id text,
    ee_client_secret text
);


ALTER TABLE hdb_catalog.hdb_version OWNER TO postgres;

--
-- Name: account_emailaddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_emailaddress (
    id integer NOT NULL,
    email character varying(254) NOT NULL,
    verified boolean NOT NULL,
    "primary" boolean NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.account_emailaddress OWNER TO postgres;

--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.account_emailaddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.account_emailaddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: account_emailconfirmation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.account_emailconfirmation (
    id integer NOT NULL,
    created timestamp with time zone NOT NULL,
    sent timestamp with time zone,
    key character varying(64) NOT NULL,
    email_address_id integer NOT NULL
);


ALTER TABLE public.account_emailconfirmation OWNER TO postgres;

--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.account_emailconfirmation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.account_emailconfirmation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: api_apikey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.api_apikey (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token text NOT NULL,
    created timestamp with time zone NOT NULL,
    expiry_date timestamp with time zone,
    revoked boolean NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.api_apikey OWNER TO postgres;

--
-- Name: api_apikey_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.api_apikey ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.api_apikey_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_bannerconfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_bannerconfiguration (
    id bigint NOT NULL,
    enable_banner boolean NOT NULL,
    banner_message character varying(255) NOT NULL,
    banner_link character varying(255) NOT NULL,
    banner_title character varying(255) NOT NULL,
    expiry_date timestamp with time zone,
    public_banner boolean NOT NULL
);


ALTER TABLE public.commandcenter_bannerconfiguration OWNER TO postgres;

--
-- Name: commandcenter_bannerconfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_bannerconfiguration ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_bannerconfiguration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_cloudservicesconfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_cloudservicesconfiguration (
    id bigint NOT NULL,
    enable boolean NOT NULL,
    aws_key character varying(255) NOT NULL,
    aws_secret character varying(255) NOT NULL,
    do_api_key character varying(255) NOT NULL,
    ignore_tag character varying(255) NOT NULL,
    notification_delay integer NOT NULL
);


ALTER TABLE public.commandcenter_cloudservicesconfiguration OWNER TO postgres;

--
-- Name: commandcenter_cloudservicesconfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_cloudservicesconfiguration ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_cloudservicesconfiguration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_companyinformation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_companyinformation (
    id bigint NOT NULL,
    company_name character varying(255) NOT NULL,
    company_twitter character varying(255) NOT NULL,
    company_email character varying(255) NOT NULL,
    company_address text NOT NULL,
    company_short_name character varying(255) NOT NULL
);


ALTER TABLE public.commandcenter_companyinformation OWNER TO postgres;

--
-- Name: commandcenter_companyinformation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_companyinformation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_companyinformation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_extrafieldmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_extrafieldmodel (
    model_internal_name character varying(255) NOT NULL,
    model_display_name character varying(255) NOT NULL,
    is_collab_editable boolean NOT NULL
);


ALTER TABLE public.commandcenter_extrafieldmodel OWNER TO postgres;

--
-- Name: commandcenter_extrafieldspec; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_extrafieldspec (
    id bigint NOT NULL,
    internal_name character varying(255) NOT NULL,
    display_name character varying(255) NOT NULL,
    type character varying(255) NOT NULL,
    target_model_id character varying(255) NOT NULL,
    _order integer NOT NULL,
    user_default_value text NOT NULL,
    description text NOT NULL
);


ALTER TABLE public.commandcenter_extrafieldspec OWNER TO postgres;

--
-- Name: commandcenter_extrafieldspec_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_extrafieldspec ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_extrafieldspec_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_generalconfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_generalconfiguration (
    id bigint NOT NULL,
    default_timezone character varying(63) NOT NULL,
    hostname character varying(255) NOT NULL
);


ALTER TABLE public.commandcenter_generalconfiguration OWNER TO postgres;

--
-- Name: commandcenter_generalconfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_generalconfiguration ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_generalconfiguration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_namecheapconfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_namecheapconfiguration (
    id bigint NOT NULL,
    enable boolean NOT NULL,
    api_key character varying(255) NOT NULL,
    username character varying(255) NOT NULL,
    api_username character varying(255) NOT NULL,
    client_ip character varying(255) NOT NULL,
    page_size integer NOT NULL
);


ALTER TABLE public.commandcenter_namecheapconfiguration OWNER TO postgres;

--
-- Name: commandcenter_namecheapconfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_namecheapconfiguration ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_namecheapconfiguration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_reportconfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_reportconfiguration (
    id bigint NOT NULL,
    border_weight integer NOT NULL,
    border_color character varying(6) NOT NULL,
    prefix_figure character varying(255) NOT NULL,
    prefix_table character varying(255) NOT NULL,
    default_docx_template_id bigint,
    default_pptx_template_id bigint,
    enable_borders boolean NOT NULL,
    label_figure character varying(255) NOT NULL,
    label_table character varying(255) NOT NULL,
    report_filename character varying(255) NOT NULL,
    target_delivery_date integer NOT NULL,
    title_case_captions boolean NOT NULL,
    title_case_exceptions character varying(255) NOT NULL,
    project_filename character varying(255) NOT NULL,
    table_caption_location character varying(10) NOT NULL,
    figure_caption_location character varying(10) NOT NULL
);


ALTER TABLE public.commandcenter_reportconfiguration OWNER TO postgres;

--
-- Name: commandcenter_reportconfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_reportconfiguration ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_reportconfiguration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_slackconfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_slackconfiguration (
    id bigint NOT NULL,
    enable boolean NOT NULL,
    webhook_url character varying(255) NOT NULL,
    slack_emoji character varying(255) NOT NULL,
    slack_channel character varying(255) NOT NULL,
    slack_username character varying(255) NOT NULL,
    slack_alert_target character varying(255) NOT NULL
);


ALTER TABLE public.commandcenter_slackconfiguration OWNER TO postgres;

--
-- Name: commandcenter_slackconfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_slackconfiguration ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_slackconfiguration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: commandcenter_virustotalconfiguration; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.commandcenter_virustotalconfiguration (
    id bigint NOT NULL,
    enable boolean NOT NULL,
    api_key character varying(255) NOT NULL,
    sleep_time integer NOT NULL
);


ALTER TABLE public.commandcenter_virustotalconfiguration OWNER TO postgres;

--
-- Name: commandcenter_virustotalconfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.commandcenter_virustotalconfiguration ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.commandcenter_virustotalconfiguration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_q_ormq; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_q_ormq (
    id integer NOT NULL,
    key character varying(100) NOT NULL,
    payload text NOT NULL,
    lock timestamp with time zone
);


ALTER TABLE public.django_q_ormq OWNER TO postgres;

--
-- Name: django_q_ormq_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_q_ormq ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_q_ormq_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_q_schedule; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_q_schedule (
    id integer NOT NULL,
    func character varying(256) NOT NULL,
    hook character varying(256),
    args text,
    kwargs text,
    schedule_type character varying(2) NOT NULL,
    repeats integer NOT NULL,
    next_run timestamp with time zone,
    task character varying(100),
    name character varying(100),
    minutes smallint,
    cron character varying(100),
    cluster character varying(100),
    intended_date_kwarg character varying(100),
    CONSTRAINT django_q_schedule_minutes_check CHECK ((minutes >= 0))
);


ALTER TABLE public.django_q_schedule OWNER TO postgres;

--
-- Name: django_q_schedule_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_q_schedule ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_q_schedule_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_q_task; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_q_task (
    name character varying(100) NOT NULL,
    func character varying(256) NOT NULL,
    hook character varying(256),
    args text,
    kwargs text,
    result text,
    started timestamp with time zone NOT NULL,
    stopped timestamp with time zone NOT NULL,
    success boolean NOT NULL,
    id character varying(32) NOT NULL,
    "group" character varying(100),
    attempt_count integer NOT NULL,
    cluster character varying(100)
);


ALTER TABLE public.django_q_task OWNER TO postgres;

--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.django_site ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: health_check_db_testmodel; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.health_check_db_testmodel (
    id integer NOT NULL,
    title character varying(128) NOT NULL
);


ALTER TABLE public.health_check_db_testmodel OWNER TO postgres;

--
-- Name: health_check_db_testmodel_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.health_check_db_testmodel ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.health_check_db_testmodel_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: home_userprofile; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.home_userprofile (
    id bigint NOT NULL,
    avatar character varying(100) NOT NULL,
    user_id bigint NOT NULL,
    hide_quickstart boolean NOT NULL
);


ALTER TABLE public.home_userprofile OWNER TO postgres;

--
-- Name: home_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.home_userprofile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.home_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: oplog_oplog; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oplog_oplog (
    id bigint NOT NULL,
    name text NOT NULL,
    project_id bigint,
    mute_notifications boolean DEFAULT false NOT NULL
);


ALTER TABLE public.oplog_oplog OWNER TO postgres;

--
-- Name: oplog_oplog_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.oplog_oplog ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.oplog_oplog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: oplog_oplogentry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.oplog_oplogentry (
    id bigint NOT NULL,
    start_date timestamp with time zone,
    end_date timestamp with time zone,
    source_ip text,
    dest_ip text,
    tool text,
    user_context text,
    command text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    output text DEFAULT ''::text NOT NULL,
    comments text DEFAULT ''::text NOT NULL,
    operator_name text,
    oplog_id_id bigint,
    entry_identifier character varying(65535) DEFAULT ''::character varying NOT NULL,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.oplog_oplogentry OWNER TO postgres;

--
-- Name: oplog_oplogentry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.oplog_oplogentry ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.oplog_oplogentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: otp_static_staticdevice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_static_staticdevice (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    confirmed boolean NOT NULL,
    user_id bigint NOT NULL,
    throttling_failure_count integer NOT NULL,
    throttling_failure_timestamp timestamp with time zone,
    created_at timestamp with time zone,
    last_used_at timestamp with time zone,
    CONSTRAINT otp_static_staticdevice_throttling_failure_count_check CHECK ((throttling_failure_count >= 0))
);


ALTER TABLE public.otp_static_staticdevice OWNER TO postgres;

--
-- Name: otp_static_staticdevice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.otp_static_staticdevice ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.otp_static_staticdevice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: otp_static_statictoken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_static_statictoken (
    id integer NOT NULL,
    token character varying(16) NOT NULL,
    device_id integer NOT NULL
);


ALTER TABLE public.otp_static_statictoken OWNER TO postgres;

--
-- Name: otp_static_statictoken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.otp_static_statictoken ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.otp_static_statictoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: otp_totp_totpdevice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.otp_totp_totpdevice (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    confirmed boolean NOT NULL,
    key character varying(80) NOT NULL,
    step smallint NOT NULL,
    t0 bigint NOT NULL,
    digits smallint NOT NULL,
    tolerance smallint NOT NULL,
    drift smallint NOT NULL,
    last_t bigint NOT NULL,
    user_id bigint NOT NULL,
    throttling_failure_count integer NOT NULL,
    throttling_failure_timestamp timestamp with time zone,
    created_at timestamp with time zone,
    last_used_at timestamp with time zone,
    CONSTRAINT otp_totp_totpdevice_digits_check CHECK ((digits >= 0)),
    CONSTRAINT otp_totp_totpdevice_step_check CHECK ((step >= 0)),
    CONSTRAINT otp_totp_totpdevice_throttling_failure_count_check CHECK ((throttling_failure_count >= 0)),
    CONSTRAINT otp_totp_totpdevice_tolerance_check CHECK ((tolerance >= 0))
);


ALTER TABLE public.otp_totp_totpdevice OWNER TO postgres;

--
-- Name: otp_totp_totpdevice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.otp_totp_totpdevice ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.otp_totp_totpdevice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_archive; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_archive (
    id bigint NOT NULL,
    report_archive character varying(100) NOT NULL,
    project_id bigint
);


ALTER TABLE public.reporting_archive OWNER TO postgres;

--
-- Name: reporting_archive_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_archive ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_archive_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_doctype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_doctype (
    id bigint NOT NULL,
    doc_type character varying(20) NOT NULL,
    extension character varying(10) NOT NULL,
    name character varying(255) NOT NULL
);


ALTER TABLE public.reporting_doctype OWNER TO postgres;

--
-- Name: reporting_doctype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_doctype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_doctype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_evidence; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_evidence (
    id bigint NOT NULL,
    document character varying(255) NOT NULL,
    friendly_name character varying(255) DEFAULT ''::character varying NOT NULL,
    upload_date date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    caption character varying(255) NOT NULL,
    description text NOT NULL,
    finding_id bigint,
    uploaded_by_id bigint,
    report_id bigint,
    CONSTRAINT reporting_evidence_finding_or_report CHECK ((((finding_id IS NULL) AND (report_id IS NOT NULL)) OR ((finding_id IS NOT NULL) AND (report_id IS NULL))))
);


ALTER TABLE public.reporting_evidence OWNER TO postgres;

--
-- Name: reporting_evidence_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_evidence ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_evidence_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_finding; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_finding (
    id bigint NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    impact text DEFAULT ''::text NOT NULL,
    mitigation text DEFAULT ''::text NOT NULL,
    replication_steps text DEFAULT ''::text NOT NULL,
    host_detection_techniques text DEFAULT ''::text NOT NULL,
    network_detection_techniques text DEFAULT ''::text NOT NULL,
    "references" text DEFAULT ''::text NOT NULL,
    finding_guidance text DEFAULT ''::text NOT NULL,
    finding_type_id bigint NOT NULL,
    severity_id bigint NOT NULL,
    cvss_score double precision,
    cvss_vector character varying(255) DEFAULT ''::character varying NOT NULL,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.reporting_finding OWNER TO postgres;

--
-- Name: reporting_finding_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_finding ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_finding_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_findingnote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_findingnote (
    id bigint NOT NULL,
    "timestamp" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    finding_id bigint NOT NULL,
    operator_id bigint
);


ALTER TABLE public.reporting_findingnote OWNER TO postgres;

--
-- Name: reporting_findingnote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_findingnote ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_findingnote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_findingtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_findingtype (
    id bigint NOT NULL,
    finding_type character varying(255) NOT NULL
);


ALTER TABLE public.reporting_findingtype OWNER TO postgres;

--
-- Name: reporting_findingtype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_findingtype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_findingtype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_localfindingnote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_localfindingnote (
    id bigint NOT NULL,
    "timestamp" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    finding_id bigint NOT NULL,
    operator_id bigint
);


ALTER TABLE public.reporting_localfindingnote OWNER TO postgres;

--
-- Name: reporting_localfindingnote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_localfindingnote ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_localfindingnote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_observation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_observation (
    id bigint NOT NULL,
    title text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.reporting_observation OWNER TO postgres;

--
-- Name: reporting_observation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_observation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_observation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_report; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_report (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    creation date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_update date NOT NULL,
    complete boolean DEFAULT false NOT NULL,
    archived boolean DEFAULT false NOT NULL,
    created_by_id bigint,
    project_id bigint,
    delivered boolean DEFAULT false NOT NULL,
    docx_template_id bigint,
    pptx_template_id bigint,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.reporting_report OWNER TO postgres;

--
-- Name: reporting_report_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_report ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_report_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_reportfindinglink; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_reportfindinglink (
    id bigint NOT NULL,
    title text NOT NULL,
    "position" integer DEFAULT 1 NOT NULL,
    affected_entities text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    impact text DEFAULT ''::text NOT NULL,
    mitigation text DEFAULT ''::text NOT NULL,
    replication_steps text DEFAULT ''::text NOT NULL,
    host_detection_techniques text DEFAULT ''::text NOT NULL,
    network_detection_techniques text DEFAULT ''::text NOT NULL,
    "references" text DEFAULT ''::text NOT NULL,
    complete boolean DEFAULT false NOT NULL,
    assigned_to_id bigint,
    finding_type_id bigint NOT NULL,
    report_id bigint,
    severity_id bigint NOT NULL,
    finding_guidance text DEFAULT ''::text NOT NULL,
    cvss_score double precision,
    cvss_vector character varying(255) DEFAULT ''::character varying NOT NULL,
    added_as_blank boolean DEFAULT false NOT NULL,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.reporting_reportfindinglink OWNER TO postgres;

--
-- Name: reporting_reportfindinglink_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_reportfindinglink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_reportfindinglink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_reportobservationlink; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_reportobservationlink (
    id bigint NOT NULL,
    title character varying(255) NOT NULL,
    "position" integer NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    added_as_blank boolean NOT NULL,
    assigned_to_id bigint,
    report_id bigint,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.reporting_reportobservationlink OWNER TO postgres;

--
-- Name: reporting_reportobservationlink_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_reportobservationlink ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_reportobservationlink_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_reporttemplate; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_reporttemplate (
    id bigint NOT NULL,
    document character varying(100) NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    upload_date date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_update date NOT NULL,
    description text NOT NULL,
    protected boolean DEFAULT false NOT NULL,
    client_id bigint,
    uploaded_by_id bigint,
    lint_result jsonb,
    changelog text DEFAULT ''::text NOT NULL,
    doc_type_id bigint,
    landscape boolean NOT NULL,
    p_style character varying(255) DEFAULT ''::character varying NOT NULL,
    filename_override character varying(255) NOT NULL,
    evidence_image_width double precision NOT NULL
);


ALTER TABLE public.reporting_reporttemplate OWNER TO postgres;

--
-- Name: reporting_reporttemplate_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_reporttemplate ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_reporttemplate_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reporting_severity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reporting_severity (
    id bigint NOT NULL,
    severity character varying(255) NOT NULL,
    weight integer NOT NULL,
    color character varying(6) NOT NULL
);


ALTER TABLE public.reporting_severity OWNER TO postgres;

--
-- Name: reporting_severity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reporting_severity ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.reporting_severity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rest_framework_api_key_apikey; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rest_framework_api_key_apikey (
    id character varying(150) NOT NULL,
    created timestamp with time zone NOT NULL,
    name character varying(50) NOT NULL,
    revoked boolean NOT NULL,
    expiry_date timestamp with time zone,
    hashed_key character varying(150) NOT NULL,
    prefix character varying(8) NOT NULL
);


ALTER TABLE public.rest_framework_api_key_apikey OWNER TO postgres;

--
-- Name: rolodex_client; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_client (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    short_name character varying(255) DEFAULT ''::character varying NOT NULL,
    codename character varying(255) DEFAULT ''::character varying NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    address text DEFAULT ''::text NOT NULL,
    timezone character varying(63) DEFAULT 'America/Los_Angeles'::character varying NOT NULL,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.rolodex_client OWNER TO postgres;

--
-- Name: rolodex_client_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_client ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_client_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_clientcontact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_clientcontact (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    job_title character varying(255) DEFAULT ''::character varying NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    phone character varying(50) DEFAULT ''::character varying NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    client_id bigint NOT NULL,
    timezone character varying(63) DEFAULT 'America/Los_Angeles'::character varying NOT NULL
);


ALTER TABLE public.rolodex_clientcontact OWNER TO postgres;

--
-- Name: rolodex_clientcontact_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_clientcontact ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_clientcontact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_clientinvite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_clientinvite (
    id bigint NOT NULL,
    comment text DEFAULT ''::text NOT NULL,
    client_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.rolodex_clientinvite OWNER TO postgres;

--
-- Name: rolodex_clientinvite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_clientinvite ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_clientinvite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_clientnote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_clientnote (
    id bigint NOT NULL,
    "timestamp" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    client_id bigint NOT NULL,
    operator_id bigint
);


ALTER TABLE public.rolodex_clientnote OWNER TO postgres;

--
-- Name: rolodex_clientnote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_clientnote ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_clientnote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_deconfliction; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_deconfliction (
    id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    report_timestamp timestamp with time zone NOT NULL,
    alert_timestamp timestamp with time zone,
    response_timestamp timestamp with time zone,
    title character varying(255) NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    alert_source character varying(255) DEFAULT ''::character varying NOT NULL,
    project_id bigint NOT NULL,
    status_id bigint
);


ALTER TABLE public.rolodex_deconfliction OWNER TO postgres;

--
-- Name: rolodex_deconfliction_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_deconfliction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_deconfliction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_deconflictionstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_deconflictionstatus (
    id bigint NOT NULL,
    status character varying(255) NOT NULL,
    weight integer NOT NULL
);


ALTER TABLE public.rolodex_deconflictionstatus OWNER TO postgres;

--
-- Name: rolodex_deconflictionstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_deconflictionstatus ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_deconflictionstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_objectivepriority; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_objectivepriority (
    id bigint NOT NULL,
    weight integer NOT NULL,
    priority character varying(255) NOT NULL
);


ALTER TABLE public.rolodex_objectivepriority OWNER TO postgres;

--
-- Name: rolodex_objectivepriority_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_objectivepriority ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_objectivepriority_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_objectivestatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_objectivestatus (
    id bigint NOT NULL,
    objective_status character varying(255) NOT NULL
);


ALTER TABLE public.rolodex_objectivestatus OWNER TO postgres;

--
-- Name: rolodex_objectivestatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_objectivestatus ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_objectivestatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_project (
    id bigint NOT NULL,
    codename character varying(255) DEFAULT ''::character varying NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    slack_channel character varying(255) DEFAULT ''::character varying NOT NULL,
    complete boolean DEFAULT false NOT NULL,
    client_id bigint NOT NULL,
    operator_id bigint,
    project_type_id bigint NOT NULL,
    timezone character varying(63) DEFAULT 'America/Los_Angeles'::character varying NOT NULL,
    end_time time without time zone,
    start_time time without time zone,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.rolodex_project OWNER TO postgres;

--
-- Name: rolodex_project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_project ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_project_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projectassignment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projectassignment (
    id bigint NOT NULL,
    start_date date,
    end_date date,
    note text DEFAULT ''::text NOT NULL,
    operator_id bigint,
    project_id bigint NOT NULL,
    role_id bigint
);


ALTER TABLE public.rolodex_projectassignment OWNER TO postgres;

--
-- Name: rolodex_projectassignment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projectassignment ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projectassignment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projectcontact; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projectcontact (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    job_title character varying(255) DEFAULT ''::character varying NOT NULL,
    email character varying(255) DEFAULT ''::character varying NOT NULL,
    phone character varying(50) DEFAULT ''::character varying NOT NULL,
    timezone character varying(63) DEFAULT 'America/Los_Angeles'::character varying NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    project_id bigint NOT NULL,
    "primary" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.rolodex_projectcontact OWNER TO postgres;

--
-- Name: rolodex_projectcontact_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projectcontact ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projectcontact_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projectinvite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projectinvite (
    id bigint NOT NULL,
    comment text DEFAULT ''::text NOT NULL,
    project_id bigint NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.rolodex_projectinvite OWNER TO postgres;

--
-- Name: rolodex_projectinvite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projectinvite ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projectinvite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projectnote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projectnote (
    id bigint NOT NULL,
    "timestamp" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    operator_id bigint,
    project_id bigint NOT NULL
);


ALTER TABLE public.rolodex_projectnote OWNER TO postgres;

--
-- Name: rolodex_projectnote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projectnote ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projectnote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projectobjective; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projectobjective (
    id bigint NOT NULL,
    objective character varying(255) DEFAULT ''::character varying NOT NULL,
    complete boolean DEFAULT false NOT NULL,
    deadline date,
    project_id bigint NOT NULL,
    status_id bigint NOT NULL,
    marked_complete date,
    description text DEFAULT ''::text NOT NULL,
    priority_id bigint DEFAULT 1,
    "position" integer DEFAULT 1 NOT NULL,
    result text NOT NULL
);


ALTER TABLE public.rolodex_projectobjective OWNER TO postgres;

--
-- Name: rolodex_projectobjective_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projectobjective ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projectobjective_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projectrole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projectrole (
    id bigint NOT NULL,
    project_role character varying(255) NOT NULL
);


ALTER TABLE public.rolodex_projectrole OWNER TO postgres;

--
-- Name: rolodex_projectrole_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projectrole ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projectrole_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projectscope; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projectscope (
    id bigint NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    scope text DEFAULT ''::text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    disallowed boolean DEFAULT false NOT NULL,
    requires_caution boolean DEFAULT false NOT NULL,
    project_id bigint NOT NULL
);


ALTER TABLE public.rolodex_projectscope OWNER TO postgres;

--
-- Name: rolodex_projectscope_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projectscope ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projectscope_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projectsubtask; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projectsubtask (
    id bigint NOT NULL,
    task text DEFAULT ''::text NOT NULL,
    complete boolean DEFAULT false NOT NULL,
    deadline date,
    parent_id bigint NOT NULL,
    status_id bigint NOT NULL,
    marked_complete date
);


ALTER TABLE public.rolodex_projectsubtask OWNER TO postgres;

--
-- Name: rolodex_projectsubtask_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projectsubtask ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projectsubtask_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projecttarget; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projecttarget (
    id bigint NOT NULL,
    ip_address character varying(45) DEFAULT ''::character varying NOT NULL,
    hostname character varying(255) DEFAULT ''::character varying NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    compromised boolean DEFAULT false NOT NULL,
    project_id bigint NOT NULL
);


ALTER TABLE public.rolodex_projecttarget OWNER TO postgres;

--
-- Name: rolodex_projecttarget_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projecttarget ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projecttarget_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_projecttype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_projecttype (
    id bigint NOT NULL,
    project_type character varying(255) NOT NULL
);


ALTER TABLE public.rolodex_projecttype OWNER TO postgres;

--
-- Name: rolodex_projecttype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_projecttype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_projecttype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rolodex_whitecard; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rolodex_whitecard (
    id bigint NOT NULL,
    issued timestamp with time zone,
    title character varying(255) DEFAULT ''::character varying NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    project_id bigint NOT NULL
);


ALTER TABLE public.rolodex_whitecard OWNER TO postgres;

--
-- Name: rolodex_whitecard_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rolodex_whitecard ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.rolodex_whitecard_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_activitytype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_activitytype (
    id bigint NOT NULL,
    activity character varying(255) NOT NULL
);


ALTER TABLE public.shepherd_activitytype OWNER TO postgres;

--
-- Name: shepherd_activitytype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_activitytype ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_activitytype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_auxserveraddress; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_auxserveraddress (
    id bigint NOT NULL,
    ip_address inet,
    static_server_id bigint NOT NULL,
    "primary" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.shepherd_auxserveraddress OWNER TO postgres;

--
-- Name: shepherd_auxserveraddress_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_auxserveraddress ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_auxserveraddress_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_domain; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_domain (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    registrar character varying(255) DEFAULT ''::character varying NOT NULL,
    creation date NOT NULL,
    expiration date NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    burned_explanation text DEFAULT ''::text NOT NULL,
    domain_status_id bigint DEFAULT 1,
    health_status_id bigint DEFAULT 1,
    last_used_by_id bigint,
    whois_status_id bigint DEFAULT 1,
    auto_renew boolean DEFAULT false NOT NULL,
    expired boolean DEFAULT false NOT NULL,
    last_health_check date,
    vt_permalink character varying(255) DEFAULT ''::character varying NOT NULL,
    reset_dns boolean DEFAULT false NOT NULL,
    categorization jsonb,
    dns jsonb,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.shepherd_domain OWNER TO postgres;

--
-- Name: shepherd_domain_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_domain ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_domain_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_domainnote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_domainnote (
    id bigint NOT NULL,
    "timestamp" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    domain_id bigint NOT NULL,
    operator_id bigint
);


ALTER TABLE public.shepherd_domainnote OWNER TO postgres;

--
-- Name: shepherd_domainnote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_domainnote ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_domainnote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_domainserverconnection; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_domainserverconnection (
    id bigint NOT NULL,
    endpoint character varying(255) DEFAULT ''::character varying NOT NULL,
    subdomain character varying(255) DEFAULT ''::character varying NOT NULL,
    domain_id bigint NOT NULL,
    project_id bigint NOT NULL,
    static_server_id bigint,
    transient_server_id bigint,
    CONSTRAINT only_one_server CHECK ((((static_server_id IS NOT NULL) AND (transient_server_id IS NULL)) OR ((static_server_id IS NULL) AND (transient_server_id IS NOT NULL))))
);


ALTER TABLE public.shepherd_domainserverconnection OWNER TO postgres;

--
-- Name: shepherd_domainserverconnection_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_domainserverconnection ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_domainserverconnection_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_domainstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_domainstatus (
    id bigint NOT NULL,
    domain_status character varying(255) NOT NULL
);


ALTER TABLE public.shepherd_domainstatus OWNER TO postgres;

--
-- Name: shepherd_domainstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_domainstatus ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_domainstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_healthstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_healthstatus (
    id bigint NOT NULL,
    health_status character varying(255) NOT NULL
);


ALTER TABLE public.shepherd_healthstatus OWNER TO postgres;

--
-- Name: shepherd_healthstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_healthstatus ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_healthstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_history; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_history (
    id bigint NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    activity_type_id bigint NOT NULL,
    client_id bigint NOT NULL,
    domain_id bigint NOT NULL,
    operator_id bigint,
    project_id bigint
);


ALTER TABLE public.shepherd_history OWNER TO postgres;

--
-- Name: shepherd_history_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_history ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_history_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_serverhistory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_serverhistory (
    id bigint NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    activity_type_id bigint NOT NULL,
    client_id bigint NOT NULL,
    operator_id bigint,
    project_id bigint,
    server_id bigint NOT NULL,
    server_role_id bigint NOT NULL
);


ALTER TABLE public.shepherd_serverhistory OWNER TO postgres;

--
-- Name: shepherd_serverhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_serverhistory ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_serverhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_servernote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_servernote (
    id bigint NOT NULL,
    "timestamp" date DEFAULT CURRENT_TIMESTAMP NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    operator_id bigint,
    server_id bigint NOT NULL
);


ALTER TABLE public.shepherd_servernote OWNER TO postgres;

--
-- Name: shepherd_servernote_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_servernote ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_servernote_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_serverprovider; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_serverprovider (
    id bigint NOT NULL,
    server_provider character varying(255) NOT NULL
);


ALTER TABLE public.shepherd_serverprovider OWNER TO postgres;

--
-- Name: shepherd_serverprovider_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_serverprovider ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_serverprovider_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_serverrole; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_serverrole (
    id bigint NOT NULL,
    server_role character varying(255) NOT NULL
);


ALTER TABLE public.shepherd_serverrole OWNER TO postgres;

--
-- Name: shepherd_serverrole_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_serverrole ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_serverrole_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_serverstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_serverstatus (
    id bigint NOT NULL,
    server_status character varying(255) NOT NULL
);


ALTER TABLE public.shepherd_serverstatus OWNER TO postgres;

--
-- Name: shepherd_serverstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_serverstatus ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_serverstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_staticserver; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_staticserver (
    id bigint NOT NULL,
    ip_address inet NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    last_used_by_id bigint,
    server_provider_id bigint,
    server_status_id bigint,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    extra_fields jsonb DEFAULT '{}'::jsonb NOT NULL
);


ALTER TABLE public.shepherd_staticserver OWNER TO postgres;

--
-- Name: shepherd_staticserver_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_staticserver ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_staticserver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_transientserver; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_transientserver (
    id bigint NOT NULL,
    ip_address inet NOT NULL,
    note text DEFAULT ''::text NOT NULL,
    activity_type_id bigint NOT NULL,
    operator_id bigint,
    project_id bigint,
    server_provider_id bigint,
    server_role_id bigint NOT NULL,
    name character varying(255) DEFAULT ''::character varying NOT NULL,
    aux_address inet[]
);


ALTER TABLE public.shepherd_transientserver OWNER TO postgres;

--
-- Name: shepherd_transientserver_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_transientserver ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_transientserver_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: shepherd_whoisstatus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.shepherd_whoisstatus (
    id bigint NOT NULL,
    whois_status character varying(255) NOT NULL
);


ALTER TABLE public.shepherd_whoisstatus OWNER TO postgres;

--
-- Name: shepherd_whoisstatus_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.shepherd_whoisstatus ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.shepherd_whoisstatus_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: socialaccount_socialaccount; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialaccount_socialaccount (
    id integer NOT NULL,
    provider character varying(200) NOT NULL,
    uid character varying(191) NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    extra_data jsonb NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.socialaccount_socialaccount OWNER TO postgres;

--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.socialaccount_socialaccount ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.socialaccount_socialaccount_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: socialaccount_socialapp; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialaccount_socialapp (
    id integer NOT NULL,
    provider character varying(30) NOT NULL,
    name character varying(40) NOT NULL,
    client_id character varying(191) NOT NULL,
    secret character varying(191) NOT NULL,
    key character varying(191) NOT NULL,
    provider_id character varying(200) NOT NULL,
    settings jsonb NOT NULL
);


ALTER TABLE public.socialaccount_socialapp OWNER TO postgres;

--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.socialaccount_socialapp ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.socialaccount_socialapp_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: socialaccount_socialapp_sites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialaccount_socialapp_sites (
    id bigint NOT NULL,
    socialapp_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE public.socialaccount_socialapp_sites OWNER TO postgres;

--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.socialaccount_socialapp_sites ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.socialaccount_socialapp_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: socialaccount_socialtoken; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.socialaccount_socialtoken (
    id integer NOT NULL,
    token text NOT NULL,
    token_secret text NOT NULL,
    expires_at timestamp with time zone,
    account_id integer NOT NULL,
    app_id integer
);


ALTER TABLE public.socialaccount_socialtoken OWNER TO postgres;

--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.socialaccount_socialtoken ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.socialaccount_socialtoken_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: taggit_tag; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.taggit_tag (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    slug character varying(100) NOT NULL
);


ALTER TABLE public.taggit_tag OWNER TO postgres;

--
-- Name: taggit_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.taggit_tag ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.taggit_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: taggit_taggeditem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.taggit_taggeditem (
    id integer NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.taggit_taggeditem OWNER TO postgres;

--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.taggit_taggeditem ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.taggit_taggeditem_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL,
    name character varying(255) NOT NULL,
    phone character varying(50),
    timezone character varying(63) NOT NULL,
    role character varying(120) NOT NULL,
    enable_finding_create boolean NOT NULL,
    enable_finding_edit boolean NOT NULL,
    enable_finding_delete boolean NOT NULL,
    require_2fa boolean NOT NULL,
    enable_observation_create boolean NOT NULL,
    enable_observation_delete boolean NOT NULL,
    enable_observation_edit boolean NOT NULL
);


ALTER TABLE public.users_user OWNER TO postgres;

--
-- Name: users_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.users_user_groups OWNER TO postgres;

--
-- Name: users_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.users_user_user_permissions OWNER TO postgres;

--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.users_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: event_invocation_logs; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.event_invocation_logs (id, trigger_name, event_id, status, request, response, created_at) FROM stdin;
\.


--
-- Data for Name: event_log; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.event_log (id, schema_name, table_name, trigger_name, payload, delivered, error, tries, created_at, locked, next_retry_at, archived) FROM stdin;
\.


--
-- Data for Name: hdb_action_log; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_action_log (id, action_name, input_payload, request_headers, session_variables, response_payload, errors, created_at, response_received_at, status) FROM stdin;
\.


--
-- Data for Name: hdb_cron_event_invocation_logs; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_cron_event_invocation_logs (id, event_id, status, request, response, created_at) FROM stdin;
\.


--
-- Data for Name: hdb_cron_events; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_cron_events (id, trigger_name, scheduled_time, status, tries, created_at, next_retry_at) FROM stdin;
\.


--
-- Data for Name: hdb_event_log_cleanups; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_event_log_cleanups (id, trigger_name, scheduled_at, deleted_event_logs, deleted_event_invocation_logs, status) FROM stdin;
\.


--
-- Data for Name: hdb_metadata; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_metadata (id, metadata, resource_version) FROM stdin;
1	{"actions":[{"comment":"Attach a finding from the library to a report","definition":{"arguments":[{"name":"findingId","type":"Int!"},{"name":"reportId","type":"Int!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/attachFinding","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"attachFindingResponse","type":"mutation"},"name":"attachFinding","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Attempt to checkout a domain for a project","definition":{"arguments":[{"name":"domainId","type":"Int!"},{"name":"projectId","type":"Int!"},{"name":"startDate","type":"date!"},{"name":"endDate","type":"date!"},{"name":"activityTypeId","type":"Int!"},{"name":"note","type":"String"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/checkoutDomain","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"checkoutResponse","type":"mutation"},"name":"checkoutDomain","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Attempt to checkout a server for a project","definition":{"arguments":[{"name":"serverId","type":"Int!"},{"name":"projectId","type":"Int!"},{"name":"startDate","type":"date!"},{"name":"endDate","type":"date!"},{"name":"activityTypeId","type":"Int!"},{"name":"serverRoleId","type":"Int!"},{"name":"note","type":"String"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/checkoutServer","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"checkoutResponse","type":"mutation"},"name":"checkoutServer","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Attempt to create a new user with the specified details","definition":{"arguments":[{"name":"name","type":"String!"},{"name":"email","type":"String!"},{"name":"username","type":"String!"},{"name":"password","type":"String!"},{"name":"role","type":"String!"},{"name":"timezone","type":"String"},{"name":"phone","type":"String"},{"name":"enableFindingCreate","type":"Boolean"},{"name":"enableFindingEdit","type":"Boolean"},{"name":"enableFindingDelete","type":"Boolean"},{"name":"enableObservationCreate","type":"Boolean"},{"name":"enableObservationEdit","type":"Boolean"},{"name":"enableObservationDelete","type":"Boolean"},{"name":"require2fa","type":"Boolean"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/createUser","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"createUserResponse","type":"mutation"},"name":"createUser"},{"comment":"Delete the specified domain checkout and release the domain if deleted entry was the latest checkout","definition":{"arguments":[{"name":"checkoutId","type":"Int!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/deleteDomainCheckout","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"checkoutResponse","type":"mutation"},"name":"deleteDomainCheckout","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Delete the specified server checkout and release the server if deleted entry was the latest checkout","definition":{"arguments":[{"name":"checkoutId","type":"Int!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/deleteServerCheckout","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"checkoutResponse","type":"mutation"},"name":"deleteServerCheckout","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Delete the specified template file and remove the associated file from the filesystem","definition":{"arguments":[{"name":"templateId","type":"Int!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/deleteTemplate","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"deleteResponse","type":"mutation"},"name":"deleteTemplate","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"FindingsByTag","definition":{"arguments":[{"name":"tag","type":"String!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/tags/get_by/finding","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"output_type":"[GetFindingByTagsResponse!]","type":"query"},"name":"finding_by_tag","permissions":[{"role":"manager"},{"role":"user"}]},{"comment":"generateCodename","definition":{"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/generateCodename","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"codenameResponse","type":"mutation"},"name":"generateCodename","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Generate a JSON report for the given report ID","definition":{"arguments":[{"name":"id","type":"Int!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/generateReport","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"ReportResponse","type":"mutation"},"name":"generateReport","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Fetch the extra field spec for a model","definition":{"arguments":[{"name":"model","type":"String!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/getExtraFieldSpec","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"output_type":"ExtraFieldSpecOutput","type":"query"},"name":"getExtraFieldSpec","permissions":[{"role":"user"},{"role":"manager"}]},{"definition":{"arguments":[{"name":"username","type":"String!"},{"name":"password","type":"String!"}],"handler":"{{ACTIONS_URL_BASE}}/login","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"LoginResponse","type":"mutation"},"name":"login","permissions":[{"role":"manager"},{"role":"user"},{"role":"public"}]},{"comment":"ObservationsByTag","definition":{"arguments":[{"name":"tag","type":"String!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/tags/get_by/observation","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"output_type":"[GetObservationByTagsResponse!]","type":"query"},"name":"observation_by_tag","permissions":[{"role":"user"},{"role":"manager"}]},{"definition":{"arguments":[{"name":"tag","type":"String!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/tags/get_by/oplog_entry","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"output_type":"[GetOplogEntryByTagsResponse!]","type":"query"},"name":"oplogEntry_by_tag","permissions":[{"role":"user"},{"role":"manager"}]},{"definition":{"arguments":[{"name":"tag","type":"String!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/tags/get_by/report_finding_link","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"output_type":"[GetReportFindingByTagsResponse!]","type":"query"},"name":"reportedFinding_by_tag","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"ReportObservationsByTag","definition":{"arguments":[{"name":"tag","type":"String!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/tags/get_by/report_observation_link","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"output_type":"[GetReportObservationByTagsResponse!]","type":"query"},"name":"reportedObservation_by_tag","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Set Tags","definition":{"arguments":[{"name":"model","type":"String!"},{"name":"id","type":"bigint!"},{"name":"tags","type":"[String!]!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/tags/set","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"TagsResult!","type":"mutation"},"name":"setTags","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"Get Tags","definition":{"arguments":[{"name":"model","type":"String!"},{"name":"id","type":"bigint!"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/tags/get","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"output_type":"TagsResult!","type":"query"},"name":"tags","permissions":[{"role":"user"},{"role":"manager"}]},{"definition":{"arguments":[{"name":"file_base64","type":"String!"},{"name":"filename","type":"String!"},{"name":"friendly_name","type":"String!"},{"name":"caption","type":"String!"},{"name":"description","type":"String"},{"name":"tags","type":"String"},{"name":"report","type":"Int"},{"name":"finding","type":"Int"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/uploadEvidence","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"UploadEvidenceResult!","type":"mutation"},"name":"uploadEvidence","permissions":[{"role":"user"},{"role":"manager"}]},{"definition":{"arguments":[{"name":"file_base64","type":"String!"},{"name":"filename","type":"String!"},{"name":"name","type":"String!"},{"name":"description","type":"String!"},{"name":"protected","type":"Boolean"},{"name":"changelog","type":"String"},{"name":"landscape","type":"Boolean"},{"name":"filename_override","type":"String"},{"name":"tags","type":"String"},{"name":"client","type":"Int"},{"name":"doc_type","type":"Int!"},{"name":"p_style","type":"String"}],"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/uploadReportTemplate","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"kind":"synchronous","output_type":"UploadReportTemplateResult!","type":"mutation"},"name":"uploadReportTemplate","permissions":[{"role":"user"},{"role":"manager"}]},{"comment":"User `whoami` query for JWT","definition":{"forward_client_headers":true,"handler":"{{ACTIONS_URL_BASE}}/whoami","headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"output_type":"WhoamiOutput","type":"query"},"name":"whoami","permissions":[{"role":"user"},{"role":"manager"}]}],"custom_types":{"objects":[{"fields":[{"name":"token","type":"String!"},{"name":"expires","type":"date"}],"name":"LoginResponse"},{"fields":[{"name":"username","type":"String!"},{"name":"role","type":"String!"},{"name":"expires","type":"date"}],"name":"WhoamiOutput"},{"fields":[{"name":"reportData","type":"String!"},{"name":"docxUrl","type":"String!"},{"name":"xlsxUrl","type":"String!"},{"name":"pptxUrl","type":"String!"}],"name":"ReportResponse"},{"fields":[{"name":"result","type":"String!"}],"name":"checkoutResponse"},{"fields":[{"name":"result","type":"String!"}],"name":"deleteResponse"},{"fields":[{"name":"id","type":"Int!"}],"name":"attachFindingResponse"},{"fields":[{"name":"codename","type":"String!"}],"name":"codenameResponse"},{"fields":[{"name":"extraFieldSpec","type":"String!"}],"name":"ExtraFieldSpecOutput"},{"fields":[{"name":"id","type":"Int!"}],"name":"UploadEvidenceResult"},{"fields":[{"name":"id","type":"Int!"}],"name":"UploadReportTemplateResult"},{"fields":[{"name":"tags","type":"[String!]!"}],"name":"TagsResult"},{"fields":[{"name":"id","type":"Int!"},{"name":"name","type":"String!"},{"name":"username","type":"String!"},{"name":"email","type":"String!"},{"name":"role","type":"String!"},{"name":"result","type":"String!"}],"name":"createUserResponse","relationships":[{"field_mapping":{"id":"id"},"name":"user","remote_table":{"name":"users_user","schema":"public"},"source":"default","type":"object"}]},{"fields":[{"name":"id","type":"Int!"}],"name":"GetByTagsResponse","relationships":[{"field_mapping":{"id":"id"},"name":"observation","remote_table":{"name":"reporting_observation","schema":"public"},"source":"default","type":"object"}]},{"fields":[{"name":"id","type":"Int!"}],"name":"GetByTagsObject"},{"fields":[{"name":"id","type":"Int!"}],"name":"GetFindingByTagsResponse","relationships":[{"field_mapping":{"id":"id"},"name":"finding","remote_table":{"name":"reporting_finding","schema":"public"},"source":"default","type":"object"}]},{"fields":[{"name":"id","type":"Int!"}],"name":"GetObservationByTagsResponse","relationships":[{"field_mapping":{"id":"id"},"name":"observation","remote_table":{"name":"reporting_observation","schema":"public"},"source":"default","type":"object"}]},{"fields":[{"name":"id","type":"Int!"}],"name":"GetReportObservationByTagsResponse","relationships":[{"field_mapping":{"id":"id"},"name":"report_observation","remote_table":{"name":"reporting_reportobservationlink","schema":"public"},"source":"default","type":"object"}]},{"fields":[{"name":"id","type":"Int!"}],"name":"GetReportFindingByTagsResponse","relationships":[{"field_mapping":{"id":"id"},"name":"report_finding","remote_table":{"name":"reporting_finding","schema":"public"},"source":"default","type":"object"}]},{"fields":[{"name":"id","type":"Int!"}],"name":"GetOplogEntryByTagsResponse","relationships":[{"field_mapping":{"id":"id"},"name":"oplog_entry","remote_table":{"name":"oplog_oplogentry","schema":"public"},"source":"default","type":"object"}]}]},"network":{"tls_allowlist":[{"host":"host.docker.internal","permissions":null,"suffix":null},{"host":"nginx","permissions":null,"suffix":null}]},"sources":[{"configuration":{"connection_info":{"database_url":{"from_env":"HASURA_GRAPHQL_DATABASE_URL"},"isolation_level":"read-committed","pool_settings":{"connection_lifetime":600,"idle_timeout":180,"max_connections":50,"retries":1},"use_prepared_statements":true}},"kind":"postgres","name":"default","tables":[{"array_relationships":[{"name":"groupPermissions","using":{"foreign_key_constraint_on":{"column":"group_id","table":{"name":"auth_group_permissions","schema":"public"}}}},{"name":"users","using":{"foreign_key_constraint_on":{"column":"group_id","table":{"name":"users_user_groups","schema":"public"}}}}],"configuration":{"column_config":{},"custom_column_names":{},"custom_name":"group","custom_root_fields":{}},"table":{"name":"auth_group","schema":"public"}},{"configuration":{"column_config":{"group_id":{"custom_name":"groupId"},"permission_id":{"custom_name":"permissionId"}},"custom_column_names":{"group_id":"groupId","permission_id":"permissionId"},"custom_name":"groupPermission","custom_root_fields":{}},"object_relationships":[{"name":"authGroup","using":{"foreign_key_constraint_on":"group_id"}},{"name":"authPermission","using":{"foreign_key_constraint_on":"permission_id"}}],"table":{"name":"auth_group_permissions","schema":"public"}},{"array_relationships":[{"name":"authGroupPermissions","using":{"foreign_key_constraint_on":{"column":"permission_id","table":{"name":"auth_group_permissions","schema":"public"}}}},{"name":"userPermissions","using":{"foreign_key_constraint_on":{"column":"permission_id","table":{"name":"users_user_user_permissions","schema":"public"}}}}],"configuration":{"column_config":{"content_type_id":{"custom_name":"contentTypeId"}},"custom_column_names":{"content_type_id":"contentTypeId"},"custom_name":"authPermission","custom_root_fields":{}},"object_relationships":[{"name":"djangoContentType","using":{"foreign_key_constraint_on":"content_type_id"}}],"table":{"name":"auth_permission","schema":"public"}},{"configuration":{"column_config":{"company_email":{"custom_name":"email"},"company_name":{"custom_name":"name"},"company_twitter":{"custom_name":"twitter"}},"custom_column_names":{"company_email":"email","company_name":"name","company_twitter":"twitter"},"custom_name":"companyInfo","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["company_email","company_name","company_twitter","id"],"filter":{}},"role":"manager"},{"permission":{"columns":["company_email","company_name","company_twitter","id"],"filter":{}},"role":"user"}],"table":{"name":"commandcenter_companyinformation","schema":"public"},"update_permissions":[{"permission":{"check":null,"columns":["company_email","company_name","company_twitter"],"filter":{}},"role":"manager"}]},{"configuration":{"column_config":{"model_display_name":{"custom_name":"modelDisplayName"},"model_internal_name":{"custom_name":"modelInternalName"}},"custom_column_names":{"model_display_name":"modelDisplayName","model_internal_name":"modelInternalName"},"custom_name":"extraFieldModel","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["model_display_name","model_internal_name"],"filter":{}},"role":"manager"},{"permission":{"columns":["model_display_name","model_internal_name"],"filter":{}},"role":"user"}],"table":{"name":"commandcenter_extrafieldmodel","schema":"public"}},{"configuration":{"column_config":{"display_name":{"custom_name":"displayName"},"internal_name":{"custom_name":"internalName"},"target_model_id":{"custom_name":"targetModel"},"user_default_value":{"custom_name":"defaultValue"}},"custom_column_names":{"display_name":"displayName","internal_name":"internalName","target_model_id":"targetModel","user_default_value":"defaultValue"},"custom_name":"extraFieldSpec","custom_root_fields":{}},"object_relationships":[{"name":"extraFieldModel","using":{"foreign_key_constraint_on":"target_model_id"}}],"select_permissions":[{"permission":{"columns":["display_name","internal_name","target_model_id","type","user_default_value"],"filter":{}},"role":"manager"},{"permission":{"columns":["display_name","internal_name","target_model_id","type","user_default_value"],"filter":{}},"role":"user"}],"table":{"name":"commandcenter_extrafieldspec","schema":"public"}},{"configuration":{"column_config":{"border_color":{"custom_name":"borderColor"},"border_weight":{"custom_name":"borderWeight"},"default_docx_template_id":{"custom_name":"docxTemplateId"},"default_pptx_template_id":{"custom_name":"pptxTemplateId"},"enable_borders":{"custom_name":"enableBorders"},"label_figure":{"custom_name":"labelFigure"},"label_table":{"custom_name":"labelTable"},"prefix_figure":{"custom_name":"prefixFigure"},"prefix_table":{"custom_name":"prefixTable"}},"custom_column_names":{"border_color":"borderColor","border_weight":"borderWeight","default_docx_template_id":"docxTemplateId","default_pptx_template_id":"pptxTemplateId","enable_borders":"enableBorders","label_figure":"labelFigure","label_table":"labelTable","prefix_figure":"prefixFigure","prefix_table":"prefixTable"},"custom_name":"reportConfiguration","custom_root_fields":{}},"object_relationships":[{"name":"docxTemplate","using":{"foreign_key_constraint_on":"default_docx_template_id"}},{"name":"pptxTemplate","using":{"foreign_key_constraint_on":"default_pptx_template_id"}}],"select_permissions":[{"permission":{"columns":["border_color","border_weight","default_docx_template_id","default_pptx_template_id","enable_borders","id","label_figure","label_table","prefix_figure","prefix_table"],"filter":{}},"role":"manager"},{"permission":{"columns":["border_color","border_weight","default_docx_template_id","default_pptx_template_id","enable_borders","id","label_figure","label_table","prefix_figure","prefix_table"],"filter":{}},"role":"user"}],"table":{"name":"commandcenter_reportconfiguration","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["border_color","border_weight","default_docx_template_id","default_pptx_template_id","enable_borders","label_figure","label_table","prefix_figure","prefix_table"],"filter":{}},"role":"manager"}]},{"array_relationships":[{"name":"authPermissions","using":{"foreign_key_constraint_on":{"column":"content_type_id","table":{"name":"auth_permission","schema":"public"}}}},{"name":"tags","using":{"foreign_key_constraint_on":{"column":"content_type_id","table":{"name":"taggit_taggeditem","schema":"public"}}}}],"configuration":{"column_config":{"app_label":{"custom_name":"appLabel"}},"custom_column_names":{"app_label":"appLabel"},"custom_name":"djangoContentType","custom_root_fields":{}},"select_permissions":[{"comment":"","permission":{"columns":["app_label","model","id"],"filter":{}},"role":"manager"}],"table":{"name":"django_content_type","schema":"public"}},{"configuration":{"column_config":{},"custom_column_names":{},"custom_name":"task","custom_root_fields":{}},"insert_permissions":[{"permission":{"backend_only":true,"check":{},"columns":["args","attempt_count","func","group","hook","kwargs"]},"role":"manager"},{"permission":{"backend_only":true,"check":{},"columns":["args","attempt_count","func","group","hook","kwargs"]},"role":"user"}],"select_permissions":[{"permission":{"columns":["success","func","group","hook","id","name","attempt_count","args","kwargs","result","started","stopped"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"django_q_task","schema":"public"}},{"configuration":{"column_config":{"user_id":{"custom_name":"userId"}},"custom_column_names":{"user_id":"userId"},"custom_name":"userProfile","custom_root_fields":{}},"object_relationships":[{"name":"user","using":{"foreign_key_constraint_on":"user_id"}}],"table":{"name":"home_userprofile","schema":"public"}},{"array_relationships":[{"name":"entries","using":{"foreign_key_constraint_on":{"column":"oplog_id_id","table":{"name":"oplog_oplogentry","schema":"public"}}}}],"configuration":{"column_config":{"project_id":{"custom_name":"projectId"}},"custom_column_names":{"project_id":"projectId"},"custom_name":"oplog","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["mute_notifications","name","project_id"]},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["name","project_id"]},"role":"user"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}}],"select_permissions":[{"permission":{"columns":["id","mute_notifications","name","project_id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"oplog_oplog","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["mute_notifications","name","project_id"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["name","project_id"],"filter":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"configuration":{"column_config":{"dest_ip":{"custom_name":"destIp"},"end_date":{"custom_name":"endDate"},"entry_identifier":{"custom_name":"entryIdentifier"},"extra_fields":{"custom_name":"extraFields"},"operator_name":{"custom_name":"operatorName"},"oplog_id_id":{"custom_name":"oplog"},"source_ip":{"custom_name":"sourceIp"},"start_date":{"custom_name":"startDate"},"user_context":{"custom_name":"userContext"}},"custom_column_names":{"dest_ip":"destIp","end_date":"endDate","entry_identifier":"entryIdentifier","extra_fields":"extraFields","operator_name":"operatorName","oplog_id_id":"oplog","source_ip":"sourceIp","start_date":"startDate","user_context":"userContext"},"custom_name":"oplogEntry","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"log":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}],"event_triggers":[{"definition":{"enable_manual":false,"insert":{"columns":"*"}},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"CreateOplogEntry","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/oplogentry/create"},{"definition":{"delete":{"columns":"*"},"enable_manual":false},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"DeleteOplogEntry","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/oplogentry/delete"},{"definition":{"enable_manual":false,"update":{"columns":"*"}},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"UpdateOplogEntry","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/oplogentry/update"}],"insert_permissions":[{"permission":{"check":{},"columns":["command","comments","description","dest_ip","end_date","entry_identifier","extra_fields","operator_name","oplog_id_id","output","source_ip","start_date","tool","user_context"]},"role":"manager"},{"permission":{"check":{"log":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"columns":["command","comments","description","dest_ip","end_date","entry_identifier","extra_fields","operator_name","oplog_id_id","output","source_ip","start_date","tool","user_context"]},"role":"user"}],"object_relationships":[{"name":"log","using":{"foreign_key_constraint_on":"oplog_id_id"}}],"select_permissions":[{"permission":{"columns":["command","comments","description","dest_ip","end_date","entry_identifier","extra_fields","id","operator_name","oplog_id_id","output","source_ip","start_date","tool","user_context"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"log":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}],"table":{"name":"oplog_oplogentry","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["command","comments","description","dest_ip","end_date","entry_identifier","extra_fields","operator_name","oplog_id_id","output","source_ip","start_date","tool","user_context"],"filter":{}},"role":"manager"},{"permission":{"check":{"log":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"columns":["command","comments","description","dest_ip","end_date","entry_identifier","extra_fields","operator_name","oplog_id_id","output","source_ip","start_date","tool","user_context"],"filter":{"log":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}]},{"configuration":{"column_config":{"project_id":{"custom_name":"projectId"},"report_archive":{"custom_name":"reportArchive"}},"custom_column_names":{"project_id":"projectId","report_archive":"reportArchive"},"custom_name":"archive","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}}],"select_permissions":[{"permission":{"columns":["report_archive","id","project_id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"reporting_archive","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["project_id","report_archive"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["project_id","report_archive"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"templates","using":{"foreign_key_constraint_on":{"column":"doc_type_id","table":{"name":"reporting_reporttemplate","schema":"public"}}}}],"configuration":{"column_config":{"doc_type":{"custom_name":"docType"}},"custom_column_names":{"doc_type":"docType"},"custom_name":"docType","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","doc_type"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"reporting_doctype","schema":"public"}},{"configuration":{"column_config":{"finding_id":{"custom_name":"findingId"},"friendly_name":{"custom_name":"friendlyName"},"upload_date":{"custom_name":"uploadDate"},"uploaded_by_id":{"custom_name":"uploadedById"}},"custom_column_names":{"finding_id":"findingId","friendly_name":"friendlyName","upload_date":"uploadDate","uploaded_by_id":"uploadedById"},"custom_name":"evidence","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"_or":[{"finding":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}]}},"role":"user"}],"event_triggers":[{"definition":{"delete":{"columns":"*"},"enable_manual":false,"update":{"columns":["document","friendly_name"]}},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"EvidenceUpdate","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/evidence/update"}],"insert_permissions":[{"permission":{"check":{},"columns":["caption","description","document","finding_id","friendly_name","report_id"],"set":{"uploaded_by_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"_or":[{"finding":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}]},"columns":["caption","description","document","finding_id","friendly_name","report_id"],"set":{"uploaded_by_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"finding","using":{"foreign_key_constraint_on":"finding_id"}},{"name":"report","using":{"foreign_key_constraint_on":"report_id"}},{"name":"user","using":{"foreign_key_constraint_on":"uploaded_by_id"}}],"select_permissions":[{"permission":{"columns":["caption","description","document","finding_id","friendly_name","id","report_id","upload_date","uploaded_by_id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"_or":[{"finding":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}]}},"role":"user"}],"table":{"name":"reporting_evidence","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["caption","description","finding_id","friendly_name","report_id"],"filter":{}},"role":"manager"},{"permission":{"check":{"_or":[{"finding":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}]},"columns":["caption","description","finding_id","friendly_name","report_id"],"filter":{"_or":[{"finding":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}]}},"role":"user"}]},{"array_relationships":[{"name":"comments","using":{"foreign_key_constraint_on":{"column":"finding_id","table":{"name":"reporting_findingnote","schema":"public"}}}}],"configuration":{"column_config":{"cvss_score":{"custom_name":"cvssScore"},"cvss_vector":{"custom_name":"cvssVector"},"extra_fields":{"custom_name":"extraFields"},"finding_guidance":{"custom_name":"findingGuidance"},"finding_type_id":{"custom_name":"findingTypeId"},"host_detection_techniques":{"custom_name":"hostDetectionTechniques"},"network_detection_techniques":{"custom_name":"networkDetectionTechniques"},"severity_id":{"custom_name":"severityId"}},"custom_column_names":{"cvss_score":"cvssScore","cvss_vector":"cvssVector","extra_fields":"extraFields","finding_guidance":"findingGuidance","finding_type_id":"findingTypeId","host_detection_techniques":"hostDetectionTechniques","network_detection_techniques":"networkDetectionTechniques","severity_id":"severityId"},"custom_name":"finding","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"_exists":{"_table":{"name":"users_user","schema":"public"},"_where":{"_and":[{"id":{"_eq":"X-Hasura-User-Id"}},{"enable_finding_delete":{"_eq":true}}]}}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","impact","mitigation","network_detection_techniques","references","replication_steps","severity_id","title"]},"role":"manager"},{"permission":{"check":{"_exists":{"_table":{"name":"users_user","schema":"public"},"_where":{"_and":[{"id":{"_eq":"X-Hasura-User-Id"}},{"enable_finding_create":{"_eq":true}}]}}},"columns":["cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","impact","mitigation","network_detection_techniques","references","replication_steps","severity_id","title"]},"role":"user"}],"object_relationships":[{"name":"severity","using":{"foreign_key_constraint_on":"severity_id"}},{"name":"type","using":{"foreign_key_constraint_on":"finding_type_id"}}],"select_permissions":[{"permission":{"columns":["cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","id","impact","mitigation","network_detection_techniques","references","replication_steps","severity_id","title"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"reporting_finding","schema":"public"},"update_permissions":[{"permission":{"check":null,"columns":["cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","impact","mitigation","network_detection_techniques","references","replication_steps","severity_id","title"],"filter":{}},"role":"manager"},{"permission":{"check":{"_exists":{"_table":{"name":"users_user","schema":"public"},"_where":{"_and":[{"id":{"_eq":"X-Hasura-User-Id"}},{"enable_finding_edit":{"_eq":true}}]}}},"columns":["cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","impact","mitigation","network_detection_techniques","references","replication_steps","severity_id","title"],"filter":{}},"role":"user"}]},{"configuration":{"column_config":{"finding_id":{"custom_name":"findingId"},"operator_id":{"custom_name":"operatorId"}},"custom_column_names":{"finding_id":"findingId","operator_id":"operatorId"},"custom_name":"findingNote","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["finding_id","note"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{},"columns":["finding_id","note"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"finding","using":{"foreign_key_constraint_on":"finding_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["finding_id","id","operator_id","timestamp","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"reporting_findingnote","schema":"public"},"update_permissions":[{"permission":{"check":{"note":{"_neq":"\\"\\""}},"columns":["finding_id","note"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"check":{"operator_id":{"_eq":"X-Hasura-User-Id"}},"columns":["finding_id","note"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}},"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}]},{"array_relationships":[{"name":"findings","using":{"foreign_key_constraint_on":{"column":"finding_type_id","table":{"name":"reporting_finding","schema":"public"}}}},{"name":"reportedFindings","using":{"foreign_key_constraint_on":{"column":"finding_type_id","table":{"name":"reporting_reportfindinglink","schema":"public"}}}}],"configuration":{"column_config":{"finding_type":{"custom_name":"findingType"}},"custom_column_names":{"finding_type":"findingType"},"custom_name":"findingType","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["finding_type","id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"reporting_findingtype","schema":"public"}},{"configuration":{"column_config":{"finding_id":{"custom_name":"findingId"},"operator_id":{"custom_name":"operatorId"}},"custom_column_names":{"finding_id":"findingId","operator_id":"operatorId"},"custom_name":"reportedFindingNote","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{"user":{"id":{"_eq":"X-Hasura-User-Id"}}}},"role":"manager"},{"permission":{"filter":{"_or":[{"finding":{"report":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}}}]}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["finding_id","note"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"_or":[{"finding":{"report":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}}}]},"columns":["finding_id","note"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"finding","using":{"foreign_key_constraint_on":"finding_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["finding_id","id","operator_id","timestamp","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"_or":[{"finding":{"report":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}}}]}},"role":"user"}],"table":{"name":"reporting_localfindingnote","schema":"public"},"update_permissions":[{"permission":{"check":{"note":{"_neq":"\\"\\""}},"columns":["finding_id","note"],"filter":{"user":{"id":{"_eq":"X-Hasura-User-Id"}}}},"role":"manager"},{"permission":{"check":{"_or":[{"finding":{"report":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}}}]},"columns":["finding_id","note"],"filter":{"_or":[{"finding":{"report":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}}}]}},"role":"user"}]},{"configuration":{"column_config":{"extra_fields":{"custom_name":"extraFields"}},"custom_column_names":{"extra_fields":"extraFields"},"custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["description","extra_fields","title"]},"role":"manager"},{"permission":{"check":{},"columns":["description","extra_fields","title"]},"role":"user"}],"select_permissions":[{"permission":{"columns":["id","title","extra_fields","description"],"filter":{}},"role":"manager"},{"permission":{"columns":["id","title","extra_fields","description"],"filter":{}},"role":"user"}],"table":{"name":"reporting_observation","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["description","extra_fields","title"],"filter":{}},"role":"manager"},{"permission":{"check":{},"columns":["description","extra_fields","title"],"filter":{}},"role":"user"}]},{"array_relationships":[{"name":"evidence","using":{"foreign_key_constraint_on":{"column":"report_id","table":{"name":"reporting_evidence","schema":"public"}}}},{"name":"findings","using":{"foreign_key_constraint_on":{"column":"report_id","table":{"name":"reporting_reportfindinglink","schema":"public"}}}},{"name":"observations","using":{"foreign_key_constraint_on":{"column":"report_id","table":{"name":"reporting_reportobservationlink","schema":"public"}}}}],"configuration":{"column_config":{"created_by_id":{"custom_name":"createdById"},"docx_template_id":{"custom_name":"docxTemplateId"},"extra_fields":{"custom_name":"extraFields"},"pptx_template_id":{"custom_name":"pptxTemplateId"},"project_id":{"custom_name":"projectId"}},"custom_column_names":{"created_by_id":"createdById","docx_template_id":"docxTemplateId","extra_fields":"extraFields","pptx_template_id":"pptxTemplateId","project_id":"projectId"},"custom_name":"report","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["docx_template_id","extra_fields","pptx_template_id","project_id","title"],"set":{"created_by_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["docx_template_id","extra_fields","pptx_template_id","project_id","title"],"set":{"created_by_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"docxTemplate","using":{"foreign_key_constraint_on":"docx_template_id"}},{"name":"pptxTemplate","using":{"foreign_key_constraint_on":"pptx_template_id"}},{"name":"project","using":{"foreign_key_constraint_on":"project_id"}},{"name":"user","using":{"foreign_key_constraint_on":"created_by_id"}}],"select_permissions":[{"permission":{"columns":["archived","complete","created_by_id","creation","delivered","docx_template_id","extra_fields","id","last_update","pptx_template_id","project_id","title"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"reporting_report","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["archived","complete","delivered","docx_template_id","extra_fields","pptx_template_id","project_id","title"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["complete","delivered","docx_template_id","extra_fields","pptx_template_id","project_id","title"],"filter":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"comments","using":{"foreign_key_constraint_on":{"column":"finding_id","table":{"name":"reporting_localfindingnote","schema":"public"}}}},{"name":"evidences","using":{"foreign_key_constraint_on":{"column":"finding_id","table":{"name":"reporting_evidence","schema":"public"}}}}],"configuration":{"column_config":{"added_as_blank":{"custom_name":"addedAsBlank"},"affected_entities":{"custom_name":"affectedEntities"},"assigned_to_id":{"custom_name":"assignedToId"},"cvss_score":{"custom_name":"cvssScore"},"cvss_vector":{"custom_name":"cvssVector"},"extra_fields":{"custom_name":"extraFields"},"finding_guidance":{"custom_name":"findingGuidance"},"finding_type_id":{"custom_name":"findingTypeId"},"host_detection_techniques":{"custom_name":"hostDetectionTechniques"},"network_detection_techniques":{"custom_name":"networkDetectionTechniques"},"report_id":{"custom_name":"reportId"},"severity_id":{"custom_name":"severityId"}},"custom_column_names":{"added_as_blank":"addedAsBlank","affected_entities":"affectedEntities","assigned_to_id":"assignedToId","cvss_score":"cvssScore","cvss_vector":"cvssVector","extra_fields":"extraFields","finding_guidance":"findingGuidance","finding_type_id":"findingTypeId","host_detection_techniques":"hostDetectionTechniques","network_detection_techniques":"networkDetectionTechniques","report_id":"reportId","severity_id":"severityId"},"custom_name":"reportedFinding","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"report":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}],"event_triggers":[{"definition":{"enable_manual":false,"insert":{"columns":"*"},"update":{"columns":["severity_id","position"]}},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"CreateReportFinding","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/report/finding/change"},{"definition":{"delete":{"columns":"*"},"enable_manual":false},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"DeleteReportFinding","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/report/finding/delete"}],"insert_permissions":[{"permission":{"check":{},"columns":["added_as_blank","affected_entities","assigned_to_id","complete","cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","impact","mitigation","network_detection_techniques","position","references","replication_steps","report_id","severity_id","title"],"set":{"added_as_blank":"true","assigned_to_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"report":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"columns":["added_as_blank","affected_entities","assigned_to_id","complete","cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","impact","mitigation","network_detection_techniques","position","references","replication_steps","report_id","severity_id","title"],"set":{"added_as_blank":"true","assigned_to_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"assignedTo","using":{"foreign_key_constraint_on":"assigned_to_id"}},{"name":"findingType","using":{"foreign_key_constraint_on":"finding_type_id"}},{"name":"report","using":{"foreign_key_constraint_on":"report_id"}},{"name":"severity","using":{"foreign_key_constraint_on":"severity_id"}}],"select_permissions":[{"permission":{"columns":["added_as_blank","affected_entities","assigned_to_id","complete","cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","id","impact","mitigation","network_detection_techniques","position","references","replication_steps","report_id","severity_id","title"],"filter":{}},"role":"manager"},{"permission":{"columns":["added_as_blank","affected_entities","assigned_to_id","complete","cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","id","impact","mitigation","network_detection_techniques","position","references","replication_steps","report_id","severity_id","title"],"filter":{"report":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}],"table":{"name":"reporting_reportfindinglink","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["added_as_blank","affected_entities","assigned_to_id","complete","cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","impact","mitigation","network_detection_techniques","position","references","replication_steps","report_id","severity_id","title"],"filter":{}},"role":"manager"},{"permission":{"check":{"report":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"columns":["added_as_blank","affected_entities","assigned_to_id","complete","cvss_score","cvss_vector","description","extra_fields","finding_guidance","finding_type_id","host_detection_techniques","impact","mitigation","network_detection_techniques","position","references","replication_steps","report_id","severity_id","title"],"filter":{"report":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}]},{"configuration":{"column_config":{"extra_fields":{"custom_name":"extraFields"}},"custom_column_names":{"extra_fields":"extraFields"},"custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["added_as_blank","assigned_to_id","description","extra_fields","position","report_id","title"],"set":{"assigned_to_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"columns":["added_as_blank","assigned_to_id","description","extra_fields","position","report_id","title"],"set":{"assigned_to_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"asssignedTo","using":{"foreign_key_constraint_on":"assigned_to_id"}},{"name":"report","using":{"foreign_key_constraint_on":"report_id"}}],"select_permissions":[{"permission":{"columns":["assigned_to_id","id","report_id","added_as_blank","title","position","extra_fields","description"],"filter":{}},"role":"manager"},{"permission":{"columns":["assigned_to_id","id","report_id","added_as_blank","title","position","extra_fields","description"],"filter":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}}},"role":"user"}],"table":{"name":"reporting_reportobservationlink","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["added_as_blank","assigned_to_id","description","extra_fields","position","report_id","title"],"filter":{}},"role":"manager"},{"permission":{"check":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"columns":["added_as_blank","assigned_to_id","description","extra_fields","position","report_id","title"],"filter":{"report":{"project":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}]}}}},"role":"user"}]},{"array_relationships":[{"name":"commandcenterReportconfigurationsByDefaultPptxTemplateId","using":{"foreign_key_constraint_on":{"column":"default_pptx_template_id","table":{"name":"commandcenter_reportconfiguration","schema":"public"}}}},{"name":"commandcenter_reportconfigurations","using":{"foreign_key_constraint_on":{"column":"default_docx_template_id","table":{"name":"commandcenter_reportconfiguration","schema":"public"}}}},{"name":"docxTemplates","using":{"foreign_key_constraint_on":{"column":"docx_template_id","table":{"name":"reporting_report","schema":"public"}}}},{"name":"pptxTemplates","using":{"foreign_key_constraint_on":{"column":"pptx_template_id","table":{"name":"reporting_report","schema":"public"}}}}],"configuration":{"column_config":{"client_id":{"custom_name":"clientId"},"doc_type_id":{"custom_name":"docTypeId"},"last_update":{"custom_name":"lastUpdate"},"lint_result":{"custom_name":"lintResult"},"upload_date":{"custom_name":"uploadDate"},"uploaded_by_id":{"custom_name":"uploadedById"}},"custom_column_names":{"client_id":"clientId","doc_type_id":"docTypeId","last_update":"lastUpdate","lint_result":"lintResult","upload_date":"uploadDate","uploaded_by_id":"uploadedById"},"custom_name":"template","custom_root_fields":{}},"object_relationships":[{"name":"client","using":{"foreign_key_constraint_on":"client_id"}},{"name":"reporting_doctype","using":{"foreign_key_constraint_on":"doc_type_id"}},{"name":"user","using":{"foreign_key_constraint_on":"uploaded_by_id"}}],"select_permissions":[{"permission":{"columns":["changelog","client_id","description","doc_type_id","document","id","landscape","last_update","lint_result","name","protected","upload_date","uploaded_by_id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"_or":[{"client_id":{"_is_null":true}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"client":{"projects":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}},{"client":{"projects":{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}}}}]}},"role":"user"}],"table":{"name":"reporting_reporttemplate","schema":"public"}},{"array_relationships":[{"name":"findings","using":{"foreign_key_constraint_on":{"column":"severity_id","table":{"name":"reporting_finding","schema":"public"}}}},{"name":"reportedFindings","using":{"foreign_key_constraint_on":{"column":"severity_id","table":{"name":"reporting_reportfindinglink","schema":"public"}}}}],"configuration":{"column_config":{},"custom_column_names":{},"custom_name":"findingSeverity","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","severity","weight","color"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"reporting_severity","schema":"public"}},{"array_relationships":[{"name":"comments","using":{"foreign_key_constraint_on":{"column":"client_id","table":{"name":"rolodex_clientnote","schema":"public"}}}},{"name":"contacts","using":{"foreign_key_constraint_on":{"column":"client_id","table":{"name":"rolodex_clientcontact","schema":"public"}}}},{"name":"domains","using":{"foreign_key_constraint_on":{"column":"client_id","table":{"name":"shepherd_history","schema":"public"}}}},{"name":"invites","using":{"foreign_key_constraint_on":{"column":"client_id","table":{"name":"rolodex_clientinvite","schema":"public"}}}},{"name":"projects","using":{"foreign_key_constraint_on":{"column":"client_id","table":{"name":"rolodex_project","schema":"public"}}}},{"name":"servers","using":{"foreign_key_constraint_on":{"column":"client_id","table":{"name":"shepherd_serverhistory","schema":"public"}}}},{"name":"templates","using":{"foreign_key_constraint_on":{"column":"client_id","table":{"name":"reporting_reporttemplate","schema":"public"}}}}],"configuration":{"column_config":{"extra_fields":{"custom_name":"extraFields"},"short_name":{"custom_name":"shortName"}},"custom_column_names":{"extra_fields":"extraFields","short_name":"shortName"},"custom_name":"client","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"}],"insert_permissions":[{"permission":{"check":{},"columns":["address","codename","extra_fields","name","note","short_name","timezone"]},"role":"manager"}],"select_permissions":[{"permission":{"columns":["address","codename","extra_fields","id","name","note","short_name","timezone"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}},"role":"user"}],"table":{"name":"rolodex_client","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["address","codename","extra_fields","name","note","short_name","timezone"],"filter":{}},"role":"manager"}]},{"configuration":{"column_config":{"client_id":{"custom_name":"clientId"},"job_title":{"custom_name":"jobTitle"}},"custom_column_names":{"client_id":"clientId","job_title":"jobTitle"},"custom_name":"clientContact","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["client_id","email","job_title","name","note","phone","timezone"]},"role":"manager"},{"permission":{"check":{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}},"columns":["client_id","email","job_title","name","note","phone","timezone"]},"role":"user"}],"object_relationships":[{"name":"client","using":{"foreign_key_constraint_on":"client_id"}}],"select_permissions":[{"permission":{"columns":["email","job_title","name","phone","timezone","client_id","id","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}}},"role":"user"}],"table":{"name":"rolodex_clientcontact","schema":"public"},"update_permissions":[{"permission":{"check":null,"columns":["client_id","email","job_title","name","note","phone","timezone"],"filter":{}},"role":"manager"},{"permission":{"check":{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}},"columns":["client_id","email","job_title","name","note","phone","timezone"],"filter":{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}}},"role":"user"}]},{"array_relationships":[{"name":"projects","using":{"manual_configuration":{"column_mapping":{"client_id":"client_id"},"insertion_order":null,"remote_table":{"name":"rolodex_project","schema":"public"}}}}],"configuration":{"column_config":{"client_id":{"custom_name":"clientId"},"user_id":{"custom_name":"userId"}},"custom_column_names":{"client_id":"clientId","user_id":"userId"},"custom_name":"clientInvite","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"}],"insert_permissions":[{"permission":{"check":{},"columns":["client_id","comment","user_id"]},"role":"manager"}],"object_relationships":[{"name":"client","using":{"foreign_key_constraint_on":"client_id"}},{"name":"user","using":{"foreign_key_constraint_on":"user_id"}}],"select_permissions":[{"permission":{"columns":["client_id","comment","id","user_id"],"filter":{}},"role":"manager"},{"permission":{"columns":["client_id","id","user_id","comment"],"filter":{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}},"role":"user"}],"table":{"name":"rolodex_clientinvite","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["client_id","comment","user_id"],"filter":{}},"role":"manager"}]},{"configuration":{"column_config":{"client_id":{"custom_name":"clientId"},"operator_id":{"custom_name":"operatorId"}},"custom_column_names":{"client_id":"clientId","operator_id":"operatorId"},"custom_name":"clientNote","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"filter":{"_and":[{"operator_id":{"_eq":"X-Hasura-User-Id"}},{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}}]}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["client_id","note"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}},"columns":["client_id","note"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"client","using":{"foreign_key_constraint_on":"client_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["client_id","id","operator_id","timestamp","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}}},"role":"user"}],"table":{"name":"rolodex_clientnote","schema":"public"},"update_permissions":[{"permission":{"check":{"_and":[{"operator_id":{"_eq":"X-Hasura-User-Id"}},{"note":{"_neq":"\\"\\""}}]},"columns":["client_id","note"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"check":{"_and":[{"operator_id":{"_eq":"X-Hasura-User-Id"}},{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}}]},"columns":["client_id","note"],"filter":{"_and":[{"operator_id":{"_eq":"X-Hasura-User-Id"}},{"client":{"_or":[{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"projects":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}]}}]}},"role":"user"}]},{"configuration":{"column_config":{"alert_source":{"custom_name":"alertSource"},"alert_timestamp":{"custom_name":"alertTimestamp"},"created_at":{"custom_name":"createdAt"},"project_id":{"custom_name":"projectId"},"report_timestamp":{"custom_name":"reportTimestamp"},"response_timestamp":{"custom_name":"responseTimestamp"},"status_id":{"custom_name":"statusId"}},"custom_column_names":{"alert_source":"alertSource","alert_timestamp":"alertTimestamp","created_at":"createdAt","project_id":"projectId","report_timestamp":"reportTimestamp","response_timestamp":"responseTimestamp","status_id":"statusId"},"custom_name":"deconfliction","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["alert_source","alert_timestamp","description","project_id","report_timestamp","response_timestamp","status_id","title"]},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["alert_source","alert_timestamp","description","project_id","report_timestamp","response_timestamp","status_id","title"]},"role":"user"}],"object_relationships":[{"name":"deconflictionStatus","using":{"foreign_key_constraint_on":"status_id"}},{"name":"project","using":{"foreign_key_constraint_on":"project_id"}}],"select_permissions":[{"permission":{"columns":["id","project_id","status_id","alert_source","title","description","alert_timestamp","created_at","report_timestamp","response_timestamp"],"filter":{}},"role":"manager"},{"permission":{"columns":["id","project_id","status_id","alert_source","title","description","alert_timestamp","created_at","report_timestamp","response_timestamp"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"rolodex_deconfliction","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["alert_source","alert_timestamp","description","project_id","report_timestamp","response_timestamp","status_id","title"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["alert_source","alert_timestamp","description","project_id","report_timestamp","response_timestamp","status_id","title"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"deconflictions","using":{"foreign_key_constraint_on":{"column":"status_id","table":{"name":"rolodex_deconfliction","schema":"public"}}}}],"configuration":{"column_config":{},"custom_column_names":{},"custom_name":"deconflictionStatus","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","status","weight"],"filter":{}},"role":"manager"},{"permission":{"columns":["id","status","weight"],"filter":{}},"role":"user"}],"table":{"name":"rolodex_deconflictionstatus","schema":"public"}},{"array_relationships":[{"name":"objectives","using":{"foreign_key_constraint_on":{"column":"priority_id","table":{"name":"rolodex_projectobjective","schema":"public"}}}}],"configuration":{"column_config":{},"custom_column_names":{},"custom_name":"objectivePriority","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","weight","priority"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"rolodex_objectivepriority","schema":"public"}},{"array_relationships":[{"name":"objectiveSubTasks","using":{"foreign_key_constraint_on":{"column":"status_id","table":{"name":"rolodex_projectsubtask","schema":"public"}}}},{"name":"objectives","using":{"foreign_key_constraint_on":{"column":"status_id","table":{"name":"rolodex_projectobjective","schema":"public"}}}}],"configuration":{"column_config":{"objective_status":{"custom_name":"objectiveStatus"}},"custom_column_names":{"objective_status":"objectiveStatus"},"custom_name":"objectiveStatus","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","objective_status"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"rolodex_objectivestatus","schema":"public"}},{"array_relationships":[{"name":"archives","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"reporting_archive","schema":"public"}}}},{"name":"assignments","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_projectassignment","schema":"public"}}}},{"name":"cloudServers","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"shepherd_transientserver","schema":"public"}}}},{"name":"comments","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_projectnote","schema":"public"}}}},{"name":"contacts","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_projectcontact","schema":"public"}}}},{"name":"deconflictions","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_deconfliction","schema":"public"}}}},{"name":"domainServerConnections","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"shepherd_domainserverconnection","schema":"public"}}}},{"name":"domains","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"shepherd_history","schema":"public"}}}},{"name":"invites","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_projectinvite","schema":"public"}}}},{"name":"objectives","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_projectobjective","schema":"public"}}}},{"name":"oplogs","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"oplog_oplog","schema":"public"}}}},{"name":"reports","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"reporting_report","schema":"public"}}}},{"name":"scopes","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_projectscope","schema":"public"}}}},{"name":"staticServers","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"shepherd_serverhistory","schema":"public"}}}},{"name":"targets","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_projecttarget","schema":"public"}}}},{"name":"whitecards","using":{"foreign_key_constraint_on":{"column":"project_id","table":{"name":"rolodex_whitecard","schema":"public"}}}}],"configuration":{"column_config":{"client_id":{"custom_name":"clientId"},"end_date":{"custom_name":"endDate"},"end_time":{"custom_name":"endTime"},"extra_fields":{"custom_name":"extraFields"},"operator_id":{"custom_name":"operatorId"},"project_type_id":{"custom_name":"projectTypeId"},"slack_channel":{"custom_name":"slackChannel"},"start_date":{"custom_name":"startDate"},"start_time":{"custom_name":"startTime"}},"custom_column_names":{"client_id":"clientId","end_date":"endDate","end_time":"endTime","extra_fields":"extraFields","operator_id":"operatorId","project_type_id":"projectTypeId","slack_channel":"slackChannel","start_date":"startDate","start_time":"startTime"},"custom_name":"project","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"}],"insert_permissions":[{"permission":{"check":{},"columns":["client_id","codename","end_date","end_time","extra_fields","note","project_type_id","slack_channel","start_date","start_time","timezone"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"}],"object_relationships":[{"name":"client","using":{"foreign_key_constraint_on":"client_id"}},{"name":"projectType","using":{"foreign_key_constraint_on":"project_type_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["client_id","codename","complete","end_date","end_time","extra_fields","id","note","operator_id","project_type_id","slack_channel","start_date","start_time","timezone"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}},"role":"user"}],"table":{"name":"rolodex_project","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["client_id","codename","complete","end_date","end_time","extra_fields","note","project_type_id","slack_channel","start_date","start_time","timezone"],"filter":{}},"role":"manager"}]},{"configuration":{"column_config":{"end_date":{"custom_name":"endDate"},"operator_id":{"custom_name":"operatorId"},"project_id":{"custom_name":"projectId"},"role_id":{"custom_name":"roleId"},"start_date":{"custom_name":"startDate"}},"custom_column_names":{"end_date":"endDate","operator_id":"operatorId","project_id":"projectId","role_id":"roleId","start_date":"startDate"},"custom_name":"projectAssignment","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"}],"insert_permissions":[{"permission":{"check":{},"columns":["end_date","note","operator_id","project_id","role_id","start_date"]},"role":"manager"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}},{"name":"projectRole","using":{"foreign_key_constraint_on":"role_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["id","operator_id","project_id","role_id","end_date","start_date","note"],"filter":{}},"role":"manager"},{"permission":{"columns":["end_date","id","note","operator_id","project_id","role_id","start_date"],"filter":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"role":"user"}],"table":{"name":"rolodex_projectassignment","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["end_date","note","operator_id","project_id","role_id","start_date"],"filter":{}},"role":"manager"}]},{"configuration":{"column_config":{"project_id":{"custom_name":"projectId"}},"custom_column_names":{"project_id":"projectId"},"custom_name":"projectContact","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"role":"user"}],"event_triggers":[{"definition":{"enable_manual":false,"insert":{"columns":"*"},"update":{"columns":["primary"]}},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"UpdateProjectContact","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/projectcontact/update"}],"insert_permissions":[{"permission":{"check":{},"columns":["email","job_title","name","note","phone","primary","project_id","timezone"]},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}},"columns":["email","job_title","name","note","phone","primary","project_id","timezone"]},"role":"user"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}}],"select_permissions":[{"permission":{"columns":["id","project_id","primary","email","job_title","name","phone","timezone","note"],"filter":{}},"role":"manager"},{"permission":{"columns":["id","project_id","primary","email","job_title","name","phone","timezone","note"],"filter":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"role":"user"}],"table":{"name":"rolodex_projectcontact","schema":"public"},"update_permissions":[{"permission":{"check":null,"columns":["email","job_title","name","note","phone","primary","project_id","timezone"],"filter":{}},"role":"manager"},{"permission":{"check":null,"columns":["email","job_title","name","note","phone","primary","project_id","timezone"],"filter":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"assignments","using":{"manual_configuration":{"column_mapping":{"project_id":"project_id"},"insertion_order":null,"remote_table":{"name":"rolodex_projectassignment","schema":"public"}}}}],"configuration":{"column_config":{"project_id":{"custom_name":"projectId"},"user_id":{"custom_name":"userId"}},"custom_column_names":{"project_id":"projectId","user_id":"userId"},"custom_name":"projectInvite","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"}],"insert_permissions":[{"permission":{"check":{},"columns":["comment","project_id","user_id"]},"role":"manager"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}},{"name":"user","using":{"foreign_key_constraint_on":"user_id"}}],"select_permissions":[{"permission":{"columns":["id","project_id","user_id","comment"],"filter":{}},"role":"manager"},{"permission":{"columns":["id","project_id","user_id","comment"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"role":"user"}],"table":{"name":"rolodex_projectinvite","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["comment","project_id","user_id"],"filter":{}},"role":"manager"}]},{"configuration":{"column_config":{"operator_id":{"custom_name":"operatorId"},"project_id":{"custom_name":"projectId"}},"custom_column_names":{"operator_id":"operatorId","project_id":"projectId"},"custom_name":"projectNote","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"filter":{"_and":[{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},{"operator_id":{"_eq":"X-Hasura-User-Id"}}]}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["note","project_id"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["note","project_id"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["id","operator_id","project_id","timestamp","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"rolodex_projectnote","schema":"public"},"update_permissions":[{"permission":{"check":{"note":{"_neq":"\\"\\""}},"columns":["note","project_id"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"check":{"_and":[{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},{"operator_id":{"_eq":"X-Hasura-User-Id"}}]},"columns":["note","project_id"],"filter":{"_and":[{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},{"operator_id":{"_eq":"X-Hasura-User-Id"}}]}},"role":"user"}]},{"array_relationships":[{"name":"objectiveSubTasks","using":{"foreign_key_constraint_on":{"column":"parent_id","table":{"name":"rolodex_projectsubtask","schema":"public"}}}}],"configuration":{"column_config":{"marked_complete":{"custom_name":"markedComplete"},"priority_id":{"custom_name":"priorityId"},"project_id":{"custom_name":"projectId"},"status_id":{"custom_name":"statusId"}},"custom_column_names":{"marked_complete":"markedComplete","priority_id":"priorityId","project_id":"projectId","status_id":"statusId"},"custom_name":"objective","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"event_triggers":[{"definition":{"enable_manual":false,"insert":{"columns":"*"},"update":{"columns":["deadline","complete"]}},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"UpdateProjectObjective","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/projetobjective/update"}],"insert_permissions":[{"permission":{"check":{},"columns":["complete","deadline","description","objective","position","priority_id","project_id","result","status_id"]},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["complete","deadline","description","objective","position","priority_id","project_id","result","status_id"]},"role":"user"}],"object_relationships":[{"name":"objectivePriority","using":{"foreign_key_constraint_on":"priority_id"}},{"name":"objectiveStatus","using":{"foreign_key_constraint_on":"status_id"}},{"name":"project","using":{"foreign_key_constraint_on":"project_id"}}],"select_permissions":[{"permission":{"columns":["complete","deadline","description","id","marked_complete","objective","position","priority_id","project_id","result","status_id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"rolodex_projectobjective","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["complete","deadline","description","objective","position","priority_id","project_id","result","status_id"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["complete","deadline","description","objective","position","priority_id","project_id","result","status_id"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"assignments","using":{"foreign_key_constraint_on":{"column":"role_id","table":{"name":"rolodex_projectassignment","schema":"public"}}}}],"configuration":{"column_config":{"project_role":{"custom_name":"projectRole"}},"custom_column_names":{"project_role":"projectRole"},"custom_name":"projectRole","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","project_role"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"rolodex_projectrole","schema":"public"}},{"configuration":{"column_config":{"project_id":{"custom_name":"projectId"},"requires_caution":{"custom_name":"requiresCaution"}},"custom_column_names":{"project_id":"projectId","requires_caution":"requiresCaution"},"custom_name":"scope","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["description","disallowed","name","project_id","requires_caution","scope"]},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["description","disallowed","name","project_id","requires_caution","scope"]},"role":"user"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}}],"select_permissions":[{"permission":{"columns":["id","project_id","disallowed","requires_caution","name","description","scope"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"rolodex_projectscope","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["description","disallowed","name","project_id","requires_caution","scope"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["description","disallowed","name","project_id","requires_caution","scope"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"configuration":{"column_config":{"marked_complete":{"custom_name":"markedComplete"},"parent_id":{"custom_name":"parentId"},"status_id":{"custom_name":"statusId"}},"custom_column_names":{"marked_complete":"markedComplete","parent_id":"parentId","status_id":"statusId"},"custom_name":"objectiveSubTask","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"objective":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}],"event_triggers":[{"definition":{"enable_manual":false,"insert":{"columns":"*"},"update":{"columns":["deadline","complete"]}},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"UpdateProjectSubTask","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/projetsubtask/update"}],"insert_permissions":[{"permission":{"check":{},"columns":["deadline","parent_id","status_id","task"]},"role":"manager"},{"permission":{"check":{"objective":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"columns":["deadline","parent_id","status_id","task"]},"role":"user"}],"object_relationships":[{"name":"objective","using":{"foreign_key_constraint_on":"parent_id"}},{"name":"objectiveStatus","using":{"foreign_key_constraint_on":"status_id"}}],"select_permissions":[{"permission":{"columns":["complete","deadline","id","marked_complete","parent_id","status_id","task"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"objective":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}],"table":{"name":"rolodex_projectsubtask","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["complete","deadline","parent_id","status_id","task"],"filter":{}},"role":"manager"},{"permission":{"check":{"objective":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"columns":["complete","deadline","parent_id","status_id","task"],"filter":{"objective":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}}},"role":"user"}]},{"configuration":{"column_config":{"ip_address":{"custom_name":"ipAddress"},"project_id":{"custom_name":"projectId"}},"custom_column_names":{"ip_address":"ipAddress","project_id":"projectId"},"custom_name":"target","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["compromised","hostname","ip_address","note","project_id"]},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["compromised","hostname","ip_address","note","project_id"]},"role":"user"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}}],"select_permissions":[{"permission":{"columns":["id","project_id","compromised","hostname","ip_address","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"rolodex_projecttarget","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["compromised","hostname","ip_address","note","project_id"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["compromised","hostname","ip_address","note","project_id"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"projects","using":{"foreign_key_constraint_on":{"column":"project_type_id","table":{"name":"rolodex_project","schema":"public"}}}}],"configuration":{"column_config":{"project_type":{"custom_name":"projectType"}},"custom_column_names":{"project_type":"projectType"},"custom_name":"projectType","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","project_type"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"rolodex_projecttype","schema":"public"}},{"configuration":{"column_config":{"project_id":{"custom_name":"projectId"}},"custom_column_names":{"project_id":"projectId"},"custom_name":"whitecard","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["description","issued","project_id","title"]},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}},"columns":["description","issued","project_id","title"]},"role":"user"}],"object_relationships":[{"name":"project","using":{"foreign_key_constraint_on":"project_id"}}],"select_permissions":[{"permission":{"columns":["id","project_id","title","description","issued"],"filter":{}},"role":"manager"},{"permission":{"columns":["id","project_id","title","description","issued"],"filter":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"role":"user"}],"table":{"name":"rolodex_whitecard","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["description","issued","project_id","title"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}},"columns":["description","issued","project_id","title"],"filter":{"project":{"_or":[{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}},{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"cloudServers","using":{"foreign_key_constraint_on":{"column":"activity_type_id","table":{"name":"shepherd_transientserver","schema":"public"}}}},{"name":"domains","using":{"foreign_key_constraint_on":{"column":"activity_type_id","table":{"name":"shepherd_history","schema":"public"}}}},{"name":"staticServers","using":{"foreign_key_constraint_on":{"column":"activity_type_id","table":{"name":"shepherd_serverhistory","schema":"public"}}}}],"configuration":{"column_config":{},"custom_column_names":{},"custom_name":"activityType","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["activity","id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_activitytype","schema":"public"}},{"configuration":{"column_config":{"ip_address":{"custom_name":"ipAddress"},"static_server_id":{"custom_name":"staticServerId"}},"custom_column_names":{"ip_address":"ipAddress","static_server_id":"staticServerId"},"custom_name":"auxServerAddresses","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["ip_address","primary","static_server_id"]},"role":"manager"},{"permission":{"check":{},"columns":["ip_address","primary","static_server_id"]},"role":"user"}],"object_relationships":[{"name":"server","using":{"foreign_key_constraint_on":"static_server_id"}}],"select_permissions":[{"permission":{"columns":["ip_address","primary","static_server_id"],"filter":{}},"role":"manager"},{"permission":{"columns":["id","ip_address","primary","static_server_id"],"filter":{}},"role":"user"}],"table":{"name":"shepherd_auxserveraddress","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["ip_address","primary","static_server_id"],"filter":{}},"role":"manager"},{"permission":{"check":{},"columns":["ip_address","primary","static_server_id"],"filter":{}},"role":"user"}]},{"array_relationships":[{"name":"checkouts","using":{"foreign_key_constraint_on":{"column":"domain_id","table":{"name":"shepherd_history","schema":"public"}}}},{"name":"comments","using":{"foreign_key_constraint_on":{"column":"domain_id","table":{"name":"shepherd_domainnote","schema":"public"}}}}],"configuration":{"column_config":{"auto_renew":{"custom_name":"autoRenew"},"domain_status_id":{"custom_name":"domainStatusId"},"extra_fields":{"custom_name":"extraFields"},"health_status_id":{"custom_name":"healthStatusId"},"last_health_check":{"custom_name":"lastHealthCheck"},"last_used_by_id":{"custom_name":"lastUsedById"},"reset_dns":{"custom_name":"resetDns"},"vt_permalink":{"custom_name":"vtPermalink"},"whois_status_id":{"custom_name":"whoisStatusId"}},"custom_column_names":{"auto_renew":"autoRenew","domain_status_id":"domainStatusId","extra_fields":"extraFields","health_status_id":"healthStatusId","last_health_check":"lastHealthCheck","last_used_by_id":"lastUsedById","reset_dns":"resetDns","vt_permalink":"vtPermalink","whois_status_id":"whoisStatusId"},"custom_name":"domain","custom_root_fields":{}},"event_triggers":[{"definition":{"enable_manual":true,"insert":{"columns":"*"},"update":{"columns":["domain_status_id","name"]}},"headers":[{"name":"Hasura-Action-Secret","value_from_env":"HASURA_ACTION_SECRET"}],"name":"CleanDomainName","retry_conf":{"interval_sec":10,"num_retries":0,"timeout_sec":60},"webhook":"{{ACTIONS_URL_BASE}}/event/domain/update"}],"insert_permissions":[{"permission":{"check":{},"columns":["auto_renew","categorization","creation","dns","domain_status_id","expiration","expired","extra_fields","health_status_id","name","note","registrar","reset_dns","vt_permalink","whois_status_id"]},"role":"manager"},{"permission":{"check":{},"columns":["auto_renew","burned_explanation","categorization","creation","dns","domain_status_id","expiration","expired","extra_fields","health_status_id","last_health_check","name","note","registrar","reset_dns","vt_permalink","whois_status_id"]},"role":"user"}],"object_relationships":[{"name":"domainStatus","using":{"foreign_key_constraint_on":"domain_status_id"}},{"name":"healthStatus","using":{"foreign_key_constraint_on":"health_status_id"}},{"name":"user","using":{"foreign_key_constraint_on":"last_used_by_id"}},{"name":"whoisStatus","using":{"foreign_key_constraint_on":"whois_status_id"}}],"select_permissions":[{"permission":{"columns":["auto_renew","burned_explanation","categorization","creation","dns","domain_status_id","expiration","expired","extra_fields","health_status_id","id","last_health_check","last_used_by_id","name","note","registrar","reset_dns","vt_permalink","whois_status_id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_domain","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["auto_renew","burned_explanation","categorization","creation","dns","domain_status_id","expiration","expired","extra_fields","health_status_id","name","note","registrar","reset_dns","vt_permalink","whois_status_id"],"filter":{}},"role":"manager"},{"permission":{"check":{},"columns":["auto_renew","burned_explanation","categorization","creation","dns","domain_status_id","expiration","expired","extra_fields","health_status_id","name","note","registrar","reset_dns","vt_permalink","whois_status_id"],"filter":{}},"role":"user"}]},{"configuration":{"column_config":{"domain_id":{"custom_name":"domainId"},"operator_id":{"custom_name":"operatorId"}},"custom_column_names":{"domain_id":"domainId","operator_id":"operatorId"},"custom_name":"domainNote","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["domain_id","note"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{},"columns":["domain_id","note"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"domain","using":{"foreign_key_constraint_on":"domain_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["domain_id","id","operator_id","timestamp","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_domainnote","schema":"public"},"update_permissions":[{"permission":{"check":{"note":{"_neq":"\\"\\""}},"columns":["domain_id","note"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"check":{"operator_id":{"_eq":"X-Hasura-User-Id"}},"columns":["domain_id","note"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"user"}]},{"configuration":{"column_config":{"domain_id":{"custom_name":"domainId"},"project_id":{"custom_name":"projectId"},"static_server_id":{"custom_name":"staticServerId"},"transient_server_id":{"custom_name":"transientServerId"}},"custom_column_names":{"domain_id":"domainId","project_id":"projectId","static_server_id":"staticServerId","transient_server_id":"transientServerId"},"custom_name":"domainServerConnection","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["domain_id","endpoint","project_id","static_server_id","subdomain","transient_server_id"]},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["domain_id","endpoint","project_id","static_server_id","subdomain","transient_server_id"]},"role":"user"}],"object_relationships":[{"name":"cloudServer","using":{"foreign_key_constraint_on":"transient_server_id"}},{"name":"domain","using":{"foreign_key_constraint_on":"domain_id"}},{"name":"project","using":{"foreign_key_constraint_on":"project_id"}},{"name":"staticServer","using":{"foreign_key_constraint_on":"static_server_id"}}],"select_permissions":[{"permission":{"columns":["domain_id","id","project_id","static_server_id","transient_server_id","endpoint","subdomain"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"shepherd_domainserverconnection","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["domain_id","endpoint","project_id","static_server_id","subdomain","transient_server_id"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["domain_id","endpoint","project_id","static_server_id","subdomain","transient_server_id"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"domains","using":{"foreign_key_constraint_on":{"column":"domain_status_id","table":{"name":"shepherd_domain","schema":"public"}}}}],"configuration":{"column_config":{"domain_status":{"custom_name":"domainStatus"}},"custom_column_names":{"domain_status":"domainStatus"},"custom_name":"domainStatus","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["domain_status","id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_domainstatus","schema":"public"}},{"array_relationships":[{"name":"domains","using":{"foreign_key_constraint_on":{"column":"health_status_id","table":{"name":"shepherd_domain","schema":"public"}}}}],"configuration":{"column_config":{"health_status":{"custom_name":"healthStatus"}},"custom_column_names":{"health_status":"healthStatus"},"custom_name":"healthStatus","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["health_status","id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_healthstatus","schema":"public"}},{"array_relationships":[{"name":"domainServerConnections","using":{"foreign_key_constraint_on":{"column":"domain_id","table":{"name":"shepherd_domainserverconnection","schema":"public"}}}}],"configuration":{"column_config":{"activity_type_id":{"custom_name":"activityTypeId"},"client_id":{"custom_name":"clientId"},"domain_id":{"custom_name":"domainId"},"end_date":{"custom_name":"endDate"},"operator_id":{"custom_name":"operatorId"},"project_id":{"custom_name":"projectId"},"start_date":{"custom_name":"startDate"}},"custom_column_names":{"activity_type_id":"activityTypeId","client_id":"clientId","domain_id":"domainId","end_date":"endDate","operator_id":"operatorId","project_id":"projectId","start_date":"startDate"},"custom_name":"domainCheckout","custom_root_fields":{}},"object_relationships":[{"name":"activityType","using":{"foreign_key_constraint_on":"activity_type_id"}},{"name":"client","using":{"foreign_key_constraint_on":"client_id"}},{"name":"domain","using":{"foreign_key_constraint_on":"domain_id"}},{"name":"project","using":{"foreign_key_constraint_on":"project_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["activity_type_id","client_id","domain_id","end_date","id","note","operator_id","project_id","start_date"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"shepherd_history","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["activity_type_id","client_id","domain_id","end_date","note","project_id","start_date"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["activity_type_id","client_id","domain_id","end_date","note","project_id","start_date"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"domainServerConnections","using":{"foreign_key_constraint_on":{"column":"static_server_id","table":{"name":"shepherd_domainserverconnection","schema":"public"}}}}],"configuration":{"column_config":{"activity_type_id":{"custom_name":"activityTypeId"},"client_id":{"custom_name":"clientId"},"end_date":{"custom_name":"endDate"},"operator_id":{"custom_name":"operatorId"},"project_id":{"custom_name":"projectId"},"server_id":{"custom_name":"serverId"},"server_role_id":{"custom_name":"serverRoleId"},"start_date":{"custom_name":"startDate"}},"custom_column_names":{"activity_type_id":"activityTypeId","client_id":"clientId","end_date":"endDate","operator_id":"operatorId","project_id":"projectId","server_id":"serverId","server_role_id":"serverRoleId","start_date":"startDate"},"custom_name":"serverCheckout","custom_root_fields":{}},"insert_permissions":[{"permission":{"check":{},"columns":["activity_type_id","client_id","end_date","note","project_id","server_id","server_role_id","start_date"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["activity_type_id","client_id","end_date","note","project_id","server_id","server_role_id","start_date"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"activityType","using":{"foreign_key_constraint_on":"activity_type_id"}},{"name":"client","using":{"foreign_key_constraint_on":"client_id"}},{"name":"project","using":{"foreign_key_constraint_on":"project_id"}},{"name":"server","using":{"foreign_key_constraint_on":"server_id"}},{"name":"serverRole","using":{"foreign_key_constraint_on":"server_role_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["activity_type_id","client_id","id","operator_id","project_id","server_id","server_role_id","end_date","start_date","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"shepherd_serverhistory","schema":"public"},"update_permissions":[{"permission":{"check":null,"columns":["activity_type_id","client_id","end_date","note","project_id","server_id","server_role_id","start_date"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["activity_type_id","client_id","end_date","note","project_id","server_id","server_role_id","start_date"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"configuration":{"column_config":{"operator_id":{"custom_name":"operatorId"},"server_id":{"custom_name":"serverId"}},"custom_column_names":{"operator_id":"operatorId","server_id":"serverId"},"custom_name":"serverNote","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["note","server_id"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{},"columns":["note","server_id"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"staticServer","using":{"foreign_key_constraint_on":"server_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["id","note","operator_id","server_id","timestamp"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_servernote","schema":"public"},"update_permissions":[{"permission":{"check":{"note":{"_neq":"\\"\\""}},"columns":["note","server_id"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"manager"},{"permission":{"check":{"operator_id":{"_eq":"X-Hasura-User-Id"}},"columns":["note","server_id"],"filter":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},"role":"user"}]},{"array_relationships":[{"name":"cloudServers","using":{"foreign_key_constraint_on":{"column":"server_provider_id","table":{"name":"shepherd_transientserver","schema":"public"}}}},{"name":"staticServers","using":{"foreign_key_constraint_on":{"column":"server_provider_id","table":{"name":"shepherd_staticserver","schema":"public"}}}}],"configuration":{"column_config":{"server_provider":{"custom_name":"serverProvider"}},"custom_column_names":{"server_provider":"serverProvider"},"custom_name":"serverProvider","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","server_provider"],"filter":{}},"role":"manager"},{"permission":{"columns":["id","server_provider"],"filter":{}},"role":"user"}],"table":{"name":"shepherd_serverprovider","schema":"public"}},{"array_relationships":[{"name":"cloudServers","using":{"foreign_key_constraint_on":{"column":"server_role_id","table":{"name":"shepherd_transientserver","schema":"public"}}}},{"name":"staticServers","using":{"foreign_key_constraint_on":{"column":"server_role_id","table":{"name":"shepherd_serverhistory","schema":"public"}}}}],"configuration":{"column_config":{"server_role":{"custom_name":"serverRole"}},"custom_column_names":{"server_role":"serverRole"},"custom_name":"serverRole","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","server_role"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_serverrole","schema":"public"}},{"array_relationships":[{"name":"servers","using":{"foreign_key_constraint_on":{"column":"server_status_id","table":{"name":"shepherd_staticserver","schema":"public"}}}}],"configuration":{"column_config":{"server_status":{"custom_name":"serverStatus"}},"custom_column_names":{"server_status":"serverStatus"},"custom_name":"serverStatus","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","server_status"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_serverstatus","schema":"public"}},{"array_relationships":[{"name":"auxServerAddresses","using":{"foreign_key_constraint_on":{"column":"static_server_id","table":{"name":"shepherd_auxserveraddress","schema":"public"}}}},{"name":"checkouts","using":{"foreign_key_constraint_on":{"column":"server_id","table":{"name":"shepherd_serverhistory","schema":"public"}}}},{"name":"comments","using":{"foreign_key_constraint_on":{"column":"server_id","table":{"name":"shepherd_servernote","schema":"public"}}}}],"configuration":{"column_config":{"extra_fields":{"custom_name":"extraFields"},"ip_address":{"custom_name":"ipAddress"},"last_used_by_id":{"custom_name":"lastUsedById"},"server_provider_id":{"custom_name":"serverProviderId"},"server_status_id":{"custom_name":"serverStatusId"}},"custom_column_names":{"extra_fields":"extraFields","ip_address":"ipAddress","last_used_by_id":"lastUsedById","server_provider_id":"serverProviderId","server_status_id":"serverStatusId"},"custom_name":"staticServer","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["extra_fields","ip_address","name","note","server_provider_id","server_status_id"]},"role":"manager"},{"permission":{"check":{},"columns":["extra_fields","ip_address","name","note","server_provider_id","server_status_id"]},"role":"user"}],"object_relationships":[{"name":"serverProvider","using":{"foreign_key_constraint_on":"server_provider_id"}},{"name":"serverStatus","using":{"foreign_key_constraint_on":"server_status_id"}},{"name":"user","using":{"foreign_key_constraint_on":"last_used_by_id"}}],"select_permissions":[{"permission":{"columns":["extra_fields","id","ip_address","last_used_by_id","name","note","server_provider_id","server_status_id"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_staticserver","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["extra_fields","ip_address","name","note","server_provider_id","server_status_id"],"filter":{}},"role":"manager"},{"permission":{"check":{},"columns":["extra_fields","ip_address","name","note","server_provider_id","server_status_id"],"filter":{}},"role":"user"}]},{"array_relationships":[{"name":"domainServerConnections","using":{"foreign_key_constraint_on":{"column":"transient_server_id","table":{"name":"shepherd_domainserverconnection","schema":"public"}}}}],"configuration":{"column_config":{"activity_type_id":{"custom_name":"activityTypeId"},"aux_address":{"custom_name":"auxAddress"},"ip_address":{"custom_name":"ipAddress"},"operator_id":{"custom_name":"operatorId"},"project_id":{"custom_name":"projectId"},"server_provider_id":{"custom_name":"serverProviderId"},"server_role_id":{"custom_name":"serverRoleId"}},"custom_column_names":{"activity_type_id":"activityTypeId","aux_address":"auxAddress","ip_address":"ipAddress","operator_id":"operatorId","project_id":"projectId","server_provider_id":"serverProviderId","server_role_id":"serverRoleId"},"custom_name":"cloudServer","custom_root_fields":{}},"delete_permissions":[{"permission":{"filter":{}},"role":"manager"},{"permission":{"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"insert_permissions":[{"permission":{"check":{},"columns":["activity_type_id","aux_address","ip_address","name","note","project_id","server_provider_id","server_role_id"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["activity_type_id","aux_address","ip_address","name","note","project_id","server_provider_id","server_role_id"],"set":{"operator_id":"x-hasura-User-Id"}},"role":"user"}],"object_relationships":[{"name":"activityType","using":{"foreign_key_constraint_on":"activity_type_id"}},{"name":"project","using":{"foreign_key_constraint_on":"project_id"}},{"name":"serverProvider","using":{"foreign_key_constraint_on":"server_provider_id"}},{"name":"serverRole","using":{"foreign_key_constraint_on":"server_role_id"}},{"name":"user","using":{"foreign_key_constraint_on":"operator_id"}}],"select_permissions":[{"permission":{"columns":["aux_address","activity_type_id","id","operator_id","project_id","server_provider_id","server_role_id","name","ip_address","note"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}],"table":{"name":"shepherd_transientserver","schema":"public"},"update_permissions":[{"permission":{"check":{},"columns":["activity_type_id","aux_address","ip_address","name","note","project_id","server_provider_id","server_role_id"],"filter":{}},"role":"manager"},{"permission":{"check":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}},"columns":["activity_type_id","aux_address","ip_address","name","note","project_id","server_provider_id","server_role_id"],"filter":{"project":{"_or":[{"assignments":{"operator_id":{"_eq":"X-Hasura-User-Id"}}},{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}},{"client":{"invites":{"user_id":{"_eq":"X-Hasura-User-Id"}}}}]}}},"role":"user"}]},{"array_relationships":[{"name":"domains","using":{"foreign_key_constraint_on":{"column":"whois_status_id","table":{"name":"shepherd_domain","schema":"public"}}}}],"configuration":{"column_config":{"whois_status":{"custom_name":"whoisStatus"}},"custom_column_names":{"whois_status":"whoisStatus"},"custom_name":"whoisStatus","custom_root_fields":{}},"select_permissions":[{"permission":{"columns":["id","whois_status"],"filter":{}},"role":"manager"},{"permission":{"columns":"*","filter":{}},"role":"user"}],"table":{"name":"shepherd_whoisstatus","schema":"public"}},{"array_relationships":[{"name":"taggedItem","using":{"foreign_key_constraint_on":{"column":"tag_id","table":{"name":"taggit_taggeditem","schema":"public"}}}}],"configuration":{"column_config":{},"custom_column_names":{},"custom_name":"tag","custom_root_fields":{}},"select_permissions":[{"comment":"","permission":{"columns":["name","slug","id"],"filter":{}},"role":"manager"}],"table":{"name":"taggit_tag","schema":"public"}},{"configuration":{"column_config":{},"custom_column_names":{},"custom_name":"taggedItem","custom_root_fields":{}},"object_relationships":[{"name":"contentType","using":{"manual_configuration":{"column_mapping":{"content_type_id":"id"},"insertion_order":null,"remote_table":{"name":"django_content_type","schema":"public"}}}},{"name":"tag","using":{"foreign_key_constraint_on":"tag_id"}},{"name":"taggedItem","using":{"foreign_key_constraint_on":"content_type_id"}}],"select_permissions":[{"comment":"","permission":{"columns":["content_type_id","id","object_id","tag_id"],"filter":{}},"role":"manager"}],"table":{"name":"taggit_taggeditem","schema":"public"}},{"array_relationships":[{"name":"assignments","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"rolodex_projectassignment","schema":"public"}}}},{"name":"clientInvites","using":{"foreign_key_constraint_on":{"column":"user_id","table":{"name":"rolodex_clientinvite","schema":"public"}}}},{"name":"clientNotes","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"rolodex_clientnote","schema":"public"}}}},{"name":"cloudServers","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"shepherd_transientserver","schema":"public"}}}},{"name":"domainCheckouts","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"shepherd_history","schema":"public"}}}},{"name":"domainNotes","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"shepherd_domainnote","schema":"public"}}}},{"name":"domains","using":{"foreign_key_constraint_on":{"column":"last_used_by_id","table":{"name":"shepherd_domain","schema":"public"}}}},{"name":"evidences","using":{"foreign_key_constraint_on":{"column":"uploaded_by_id","table":{"name":"reporting_evidence","schema":"public"}}}},{"name":"findingNotes","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"reporting_findingnote","schema":"public"}}}},{"name":"groups","using":{"manual_configuration":{"column_mapping":{"id":"user_id"},"insertion_order":null,"remote_table":{"name":"users_user_groups","schema":"public"}}}},{"name":"projectInvites","using":{"foreign_key_constraint_on":{"column":"user_id","table":{"name":"rolodex_projectinvite","schema":"public"}}}},{"name":"projectNotes","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"rolodex_projectnote","schema":"public"}}}},{"name":"projects","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"rolodex_project","schema":"public"}}}},{"name":"reportTemplates","using":{"foreign_key_constraint_on":{"column":"uploaded_by_id","table":{"name":"reporting_reporttemplate","schema":"public"}}}},{"name":"reportedFindingNotes","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"reporting_localfindingnote","schema":"public"}}}},{"name":"reportedFindings","using":{"foreign_key_constraint_on":{"column":"assigned_to_id","table":{"name":"reporting_reportfindinglink","schema":"public"}}}},{"name":"reportedObservations","using":{"foreign_key_constraint_on":{"column":"assigned_to_id","table":{"name":"reporting_reportobservationlink","schema":"public"}}}},{"name":"reports","using":{"foreign_key_constraint_on":{"column":"created_by_id","table":{"name":"reporting_report","schema":"public"}}}},{"name":"serverCheckouts","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"shepherd_serverhistory","schema":"public"}}}},{"name":"serverNotes","using":{"foreign_key_constraint_on":{"column":"operator_id","table":{"name":"shepherd_servernote","schema":"public"}}}},{"name":"servers","using":{"foreign_key_constraint_on":{"column":"last_used_by_id","table":{"name":"shepherd_staticserver","schema":"public"}}}}],"configuration":{"column_config":{"date_joined":{"custom_name":"dateJoined"},"is_active":{"custom_name":"isActive"},"is_staff":{"custom_name":"isStaff"},"is_superuser":{"custom_name":"isSuperuser"},"last_login":{"custom_name":"lastLogin"}},"custom_column_names":{"date_joined":"dateJoined","is_active":"isActive","is_staff":"isStaff","is_superuser":"isSuperuser","last_login":"lastLogin"},"custom_name":"user","custom_root_fields":{}},"object_relationships":[{"name":"profile","using":{"foreign_key_constraint_on":{"column":"user_id","table":{"name":"home_userprofile","schema":"public"}}}}],"select_permissions":[{"permission":{"columns":["email","id","name","phone","timezone","username"],"filter":{"is_active":{"_eq":true}}},"role":"manager"},{"permission":{"columns":["email","id","name","phone","timezone","username"],"filter":{"is_active":{"_eq":true}}},"role":"user"}],"table":{"name":"users_user","schema":"public"}},{"configuration":{"column_config":{"group_id":{"custom_name":"groupId"},"user_id":{"custom_name":"userId"}},"custom_column_names":{"group_id":"groupId","user_id":"userId"},"custom_name":"userGroup","custom_root_fields":{}},"object_relationships":[{"name":"authGroup","using":{"foreign_key_constraint_on":"group_id"}}],"table":{"name":"users_user_groups","schema":"public"}},{"configuration":{"column_config":{"permission_id":{"custom_name":"permissionId"}},"custom_column_names":{"permission_id":"permissionId"},"custom_name":"userPermission","custom_root_fields":{}},"object_relationships":[{"name":"authPermission","using":{"foreign_key_constraint_on":"permission_id"}}],"table":{"name":"users_user_user_permissions","schema":"public"}}]}],"version":3}	2
\.


--
-- Data for Name: hdb_scheduled_event_invocation_logs; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_scheduled_event_invocation_logs (id, event_id, status, request, response, created_at) FROM stdin;
\.


--
-- Data for Name: hdb_scheduled_events; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_scheduled_events (id, webhook_conf, scheduled_time, retry_conf, payload, header_conf, status, tries, created_at, next_retry_at, comment) FROM stdin;
\.


--
-- Data for Name: hdb_schema_notifications; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_schema_notifications (id, notification, resource_version, instance_id, updated_at) FROM stdin;
1	{"metadata":false,"remote_schemas":[],"sources":["default"],"data_connectors":[]}	2	a9e759a9-aabe-439d-a295-03cce53890a9	2025-10-09 23:41:01.359932+00
\.


--
-- Data for Name: hdb_source_catalog_version; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_source_catalog_version (version, upgraded_on) FROM stdin;
3	2025-10-09 23:41:00.776508+00
\.


--
-- Data for Name: hdb_version; Type: TABLE DATA; Schema: hdb_catalog; Owner: postgres
--

COPY hdb_catalog.hdb_version (hasura_uuid, version, upgraded_on, cli_state, console_state, ee_client_id, ee_client_secret) FROM stdin;
8012b632-391d-4f91-8755-f8a80876612f	48	2025-10-09 23:40:59.304895+00	{}	{}	\N	\N
\.


--
-- Data for Name: account_emailaddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_emailaddress (id, email, verified, "primary", user_id) FROM stdin;
\.


--
-- Data for Name: account_emailconfirmation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.account_emailconfirmation (id, created, sent, key, email_address_id) FROM stdin;
\.


--
-- Data for Name: api_apikey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.api_apikey (id, name, token, created, expiry_date, revoked, user_id) FROM stdin;
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can view permission	1	view_permission
5	Can add group	2	add_group
6	Can change group	2	change_group
7	Can delete group	2	delete_group
8	Can view group	2	view_group
9	Can add content type	3	add_contenttype
10	Can change content type	3	change_contenttype
11	Can delete content type	3	delete_contenttype
12	Can view content type	3	view_contenttype
13	Can add session	4	add_session
14	Can change session	4	change_session
15	Can delete session	4	delete_session
16	Can view session	4	view_session
17	Can add site	5	add_site
18	Can change site	5	change_site
19	Can delete site	5	delete_site
20	Can view site	5	view_site
21	Can add log entry	6	add_logentry
22	Can change log entry	6	change_logentry
23	Can delete log entry	6	delete_logentry
24	Can view log entry	6	view_logentry
25	Can add email address	7	add_emailaddress
26	Can change email address	7	change_emailaddress
27	Can delete email address	7	delete_emailaddress
28	Can view email address	7	view_emailaddress
29	Can add email confirmation	8	add_emailconfirmation
30	Can change email confirmation	8	change_emailconfirmation
31	Can delete email confirmation	8	delete_emailconfirmation
32	Can view email confirmation	8	view_emailconfirmation
33	Can add TOTP device	9	add_totpdevice
34	Can change TOTP device	9	change_totpdevice
35	Can delete TOTP device	9	delete_totpdevice
36	Can view TOTP device	9	view_totpdevice
37	Can add static device	10	add_staticdevice
38	Can change static device	10	change_staticdevice
39	Can delete static device	10	delete_staticdevice
40	Can view static device	10	view_staticdevice
41	Can add static token	11	add_statictoken
42	Can change static token	11	change_statictoken
43	Can delete static token	11	delete_statictoken
44	Can view static token	11	view_statictoken
45	Can add social account	12	add_socialaccount
46	Can change social account	12	change_socialaccount
47	Can delete social account	12	delete_socialaccount
48	Can view social account	12	view_socialaccount
49	Can add social application	13	add_socialapp
50	Can change social application	13	change_socialapp
51	Can delete social application	13	delete_socialapp
52	Can view social application	13	view_socialapp
53	Can add social application token	14	add_socialtoken
54	Can change social application token	14	change_socialtoken
55	Can delete social application token	14	delete_socialtoken
56	Can view social application token	14	view_socialtoken
57	Can add API key	15	add_apikey
58	Can change API key	15	change_apikey
59	Can delete API key	15	delete_apikey
60	Can view API key	15	view_apikey
61	Can add Scheduled task	16	add_schedule
62	Can change Scheduled task	16	change_schedule
63	Can delete Scheduled task	16	delete_schedule
64	Can view Scheduled task	16	view_schedule
65	Can add task	17	add_task
66	Can change task	17	change_task
67	Can delete task	17	delete_task
68	Can view task	17	view_task
69	Can add Failed task	18	add_failure
70	Can change Failed task	18	change_failure
71	Can delete Failed task	18	delete_failure
72	Can view Failed task	18	view_failure
73	Can add Successful task	19	add_success
74	Can change Successful task	19	change_success
75	Can delete Successful task	19	delete_success
76	Can view Successful task	19	view_success
77	Can add Queued task	20	add_ormq
78	Can change Queued task	20	change_ormq
79	Can delete Queued task	20	delete_ormq
80	Can view Queued task	20	view_ormq
81	Can add test model	21	add_testmodel
82	Can change test model	21	change_testmodel
83	Can delete test model	21	delete_testmodel
84	Can view test model	21	view_testmodel
85	Can add tag	22	add_tag
86	Can change tag	22	change_tag
87	Can delete tag	22	delete_tag
88	Can view tag	22	view_tag
89	Can add tagged item	23	add_taggeditem
90	Can change tagged item	23	change_taggeditem
91	Can delete tagged item	23	delete_taggeditem
92	Can view tagged item	23	view_taggeditem
93	Can add user	24	add_user
94	Can change user	24	change_user
95	Can delete user	24	delete_user
96	Can view user	24	view_user
97	Can add User profile	25	add_userprofile
98	Can change User profile	25	change_userprofile
99	Can delete User profile	25	delete_userprofile
100	Can view User profile	25	view_userprofile
101	Can add Client	26	add_client
102	Can change Client	26	change_client
103	Can delete Client	26	delete_client
104	Can view Client	26	view_client
105	Can add Project	27	add_project
106	Can change Project	27	change_project
107	Can delete Project	27	delete_project
108	Can view Project	27	view_project
109	Can add Project role	28	add_projectrole
110	Can change Project role	28	change_projectrole
111	Can delete Project role	28	delete_projectrole
112	Can view Project role	28	view_projectrole
113	Can add Project type	29	add_projecttype
114	Can change Project type	29	change_projecttype
115	Can delete Project type	29	delete_projecttype
116	Can view Project type	29	view_projecttype
117	Can add Project note	30	add_projectnote
118	Can change Project note	30	change_projectnote
119	Can delete Project note	30	delete_projectnote
120	Can view Project note	30	view_projectnote
121	Can add Project assignment	31	add_projectassignment
122	Can change Project assignment	31	change_projectassignment
123	Can delete Project assignment	31	delete_projectassignment
124	Can view Project assignment	31	view_projectassignment
125	Can add Client note	32	add_clientnote
126	Can change Client note	32	change_clientnote
127	Can delete Client note	32	delete_clientnote
128	Can view Client note	32	view_clientnote
129	Can add Client POC	33	add_clientcontact
130	Can change Client POC	33	change_clientcontact
131	Can delete Client POC	33	delete_clientcontact
132	Can view Client POC	33	view_clientcontact
133	Can add Objective status	34	add_objectivestatus
134	Can change Objective status	34	change_objectivestatus
135	Can delete Objective status	34	delete_objectivestatus
136	Can view Objective status	34	view_objectivestatus
137	Can add Project objective	35	add_projectobjective
138	Can change Project objective	35	change_projectobjective
139	Can delete Project objective	35	delete_projectobjective
140	Can view Project objective	35	view_projectobjective
141	Can add Project scope list	36	add_projectscope
142	Can change Project scope list	36	change_projectscope
143	Can delete Project scope list	36	delete_projectscope
144	Can view Project scope list	36	view_projectscope
145	Can add Project target	37	add_projecttarget
146	Can change Project target	37	change_projecttarget
147	Can delete Project target	37	delete_projecttarget
148	Can view Project target	37	view_projecttarget
149	Can add Objective sub-task	38	add_projectsubtask
150	Can change Objective sub-task	38	change_projectsubtask
151	Can delete Objective sub-task	38	delete_projectsubtask
152	Can view Objective sub-task	38	view_projectsubtask
153	Can add Objective priority	39	add_objectivepriority
154	Can change Objective priority	39	change_objectivepriority
155	Can delete Objective priority	39	delete_objectivepriority
156	Can view Objective priority	39	view_objectivepriority
157	Can add Project invite	40	add_projectinvite
158	Can change Project invite	40	change_projectinvite
159	Can delete Project invite	40	delete_projectinvite
160	Can view Project invite	40	view_projectinvite
161	Can add Client invite	41	add_clientinvite
162	Can change Client invite	41	change_clientinvite
163	Can delete Client invite	41	delete_clientinvite
164	Can view Client invite	41	view_clientinvite
165	Can add Deconfliction status	42	add_deconflictionstatus
166	Can change Deconfliction status	42	change_deconflictionstatus
167	Can delete Deconfliction status	42	delete_deconflictionstatus
168	Can view Deconfliction status	42	view_deconflictionstatus
169	Can add Project deconfliction	43	add_deconfliction
170	Can change Project deconfliction	43	change_deconfliction
171	Can delete Project deconfliction	43	delete_deconfliction
172	Can view Project deconfliction	43	view_deconfliction
173	Can add Project white card	44	add_whitecard
174	Can change Project white card	44	change_whitecard
175	Can delete Project white card	44	delete_whitecard
176	Can view Project white card	44	view_whitecard
177	Can add Project POC	45	add_projectcontact
178	Can change Project POC	45	change_projectcontact
179	Can delete Project POC	45	delete_projectcontact
180	Can view Project POC	45	view_projectcontact
181	Can add Activity type	46	add_activitytype
182	Can change Activity type	46	change_activitytype
183	Can delete Activity type	46	delete_activitytype
184	Can view Activity type	46	view_activitytype
185	Can add Domain	47	add_domain
186	Can change Domain	47	change_domain
187	Can delete Domain	47	delete_domain
188	Can view Domain	47	view_domain
189	Can add Domain status	48	add_domainstatus
190	Can change Domain status	48	change_domainstatus
191	Can delete Domain status	48	delete_domainstatus
192	Can view Domain status	48	view_domainstatus
193	Can add Health status	49	add_healthstatus
194	Can change Health status	49	change_healthstatus
195	Can delete Health status	49	delete_healthstatus
196	Can view Health status	49	view_healthstatus
197	Can add Server provider	50	add_serverprovider
198	Can change Server provider	50	change_serverprovider
199	Can delete Server provider	50	delete_serverprovider
200	Can view Server provider	50	view_serverprovider
201	Can add Server role	51	add_serverrole
202	Can change Server role	51	change_serverrole
203	Can delete Server role	51	delete_serverrole
204	Can view Server role	51	view_serverrole
205	Can add Server status	52	add_serverstatus
206	Can change Server status	52	change_serverstatus
207	Can delete Server status	52	delete_serverstatus
208	Can view Server status	52	view_serverstatus
209	Can add WHOIS status	53	add_whoisstatus
210	Can change WHOIS status	53	change_whoisstatus
211	Can delete WHOIS status	53	delete_whoisstatus
212	Can view WHOIS status	53	view_whoisstatus
213	Can add Virtual private server	54	add_transientserver
214	Can change Virtual private server	54	change_transientserver
215	Can delete Virtual private server	54	delete_transientserver
216	Can view Virtual private server	54	view_transientserver
217	Can add Static server	55	add_staticserver
218	Can change Static server	55	change_staticserver
219	Can delete Static server	55	delete_staticserver
220	Can view Static server	55	view_staticserver
221	Can add Server note	56	add_servernote
222	Can change Server note	56	change_servernote
223	Can delete Server note	56	delete_servernote
224	Can view Server note	56	view_servernote
225	Can add Server history	57	add_serverhistory
226	Can change Server history	57	change_serverhistory
227	Can delete Server history	57	delete_serverhistory
228	Can view Server history	57	view_serverhistory
229	Can add Domain history	58	add_history
230	Can change Domain history	58	change_history
231	Can delete Domain history	58	delete_history
232	Can view Domain history	58	view_history
233	Can add Domain and server record	59	add_domainserverconnection
234	Can change Domain and server record	59	change_domainserverconnection
235	Can delete Domain and server record	59	delete_domainserverconnection
236	Can view Domain and server record	59	view_domainserverconnection
237	Can add Domain note	60	add_domainnote
238	Can change Domain note	60	change_domainnote
239	Can delete Domain note	60	delete_domainnote
240	Can view Domain note	60	view_domainnote
241	Can add Auxiliary IP address	61	add_auxserveraddress
242	Can change Auxiliary IP address	61	change_auxserveraddress
243	Can delete Auxiliary IP address	61	delete_auxserveraddress
244	Can view Auxiliary IP address	61	view_auxserveraddress
245	Can add Finding type	62	add_findingtype
246	Can change Finding type	62	change_findingtype
247	Can delete Finding type	62	delete_findingtype
248	Can view Finding type	62	view_findingtype
249	Can add Report	63	add_report
250	Can change Report	63	change_report
251	Can delete Report	63	delete_report
252	Can view Report	63	view_report
253	Can add Severity rating	64	add_severity
254	Can change Severity rating	64	change_severity
255	Can delete Severity rating	64	delete_severity
256	Can view Severity rating	64	view_severity
257	Can add Report finding	65	add_reportfindinglink
258	Can change Report finding	65	change_reportfindinglink
259	Can delete Report finding	65	delete_reportfindinglink
260	Can view Report finding	65	view_reportfindinglink
261	Can add Finding	66	add_finding
262	Can change Finding	66	change_finding
263	Can delete Finding	66	delete_finding
264	Can view Finding	66	view_finding
265	Can add Evidence	67	add_evidence
266	Can change Evidence	67	change_evidence
267	Can delete Evidence	67	delete_evidence
268	Can view Evidence	67	view_evidence
269	Can add Archived report	68	add_archive
270	Can change Archived report	68	change_archive
271	Can delete Archived report	68	delete_archive
272	Can view Archived report	68	view_archive
273	Can add Local finding note	69	add_localfindingnote
274	Can change Local finding note	69	change_localfindingnote
275	Can delete Local finding note	69	delete_localfindingnote
276	Can view Local finding note	69	view_localfindingnote
277	Can add Finding note	70	add_findingnote
278	Can change Finding note	70	change_findingnote
279	Can delete Finding note	70	delete_findingnote
280	Can view Finding note	70	view_findingnote
281	Can add Report template	71	add_reporttemplate
282	Can change Report template	71	change_reporttemplate
283	Can delete Report template	71	delete_reporttemplate
284	Can view Report template	71	view_reporttemplate
285	Can add Document type	72	add_doctype
286	Can change Document type	72	change_doctype
287	Can delete Document type	72	delete_doctype
288	Can view Document type	72	view_doctype
289	Can add Observation	73	add_observation
290	Can change Observation	73	change_observation
291	Can delete Observation	73	delete_observation
292	Can view Observation	73	view_observation
293	Can add Report observation	74	add_reportobservationlink
294	Can change Report observation	74	change_reportobservationlink
295	Can delete Report observation	74	delete_reportobservationlink
296	Can view Report observation	74	view_reportobservationlink
297	Can add Activity log	75	add_oplog
298	Can change Activity log	75	change_oplog
299	Can delete Activity log	75	delete_oplog
300	Can view Activity log	75	view_oplog
301	Can add Activity log entry	76	add_oplogentry
302	Can change Activity log entry	76	change_oplogentry
303	Can delete Activity log entry	76	delete_oplogentry
304	Can view Activity log entry	76	view_oplogentry
305	Can add Cloud Services Configuration	77	add_cloudservicesconfiguration
306	Can change Cloud Services Configuration	77	change_cloudservicesconfiguration
307	Can delete Cloud Services Configuration	77	delete_cloudservicesconfiguration
308	Can view Cloud Services Configuration	77	view_cloudservicesconfiguration
309	Can add Company Information	78	add_companyinformation
310	Can change Company Information	78	change_companyinformation
311	Can delete Company Information	78	delete_companyinformation
312	Can view Company Information	78	view_companyinformation
313	Can add Namecheap Configuration	79	add_namecheapconfiguration
314	Can change Namecheap Configuration	79	change_namecheapconfiguration
315	Can delete Namecheap Configuration	79	delete_namecheapconfiguration
316	Can view Namecheap Configuration	79	view_namecheapconfiguration
317	Can add Global Report Configuration	80	add_reportconfiguration
318	Can change Global Report Configuration	80	change_reportconfiguration
319	Can delete Global Report Configuration	80	delete_reportconfiguration
320	Can view Global Report Configuration	80	view_reportconfiguration
321	Can add Slack Configuration	81	add_slackconfiguration
322	Can change Slack Configuration	81	change_slackconfiguration
323	Can delete Slack Configuration	81	delete_slackconfiguration
324	Can view Slack Configuration	81	view_slackconfiguration
325	Can add VirusTotal Configuration	82	add_virustotalconfiguration
326	Can change VirusTotal Configuration	82	change_virustotalconfiguration
327	Can delete VirusTotal Configuration	82	delete_virustotalconfiguration
328	Can view VirusTotal Configuration	82	view_virustotalconfiguration
329	Can add General Settings	83	add_generalconfiguration
330	Can change General Settings	83	change_generalconfiguration
331	Can delete General Settings	83	delete_generalconfiguration
332	Can view General Settings	83	view_generalconfiguration
333	Can add Extra Field Configuration	84	add_extrafieldmodel
334	Can change Extra Field Configuration	84	change_extrafieldmodel
335	Can delete Extra Field Configuration	84	delete_extrafieldmodel
336	Can view Extra Field Configuration	84	view_extrafieldmodel
337	Can add Extra Field	85	add_extrafieldspec
338	Can change Extra Field	85	change_extrafieldspec
339	Can delete Extra Field	85	delete_extrafieldspec
340	Can view Extra Field	85	view_extrafieldspec
341	Can add Banner Configuration	86	add_bannerconfiguration
342	Can change Banner Configuration	86	change_bannerconfiguration
343	Can delete Banner Configuration	86	delete_bannerconfiguration
344	Can view Banner Configuration	86	view_bannerconfiguration
345	Can add API key	87	add_apikey
346	Can change API key	87	change_apikey
347	Can delete API key	87	delete_apikey
348	Can view API key	87	view_apikey
\.


--
-- Data for Name: commandcenter_bannerconfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_bannerconfiguration (id, enable_banner, banner_message, banner_link, banner_title, expiry_date, public_banner) FROM stdin;
1	f				\N	f
\.


--
-- Data for Name: commandcenter_cloudservicesconfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_cloudservicesconfiguration (id, enable, aws_key, aws_secret, do_api_key, ignore_tag, notification_delay) FROM stdin;
1	f	Your AWS Access Key	Your AWS Secret Key	Digital Ocean API Key	gw_ignore	7
\.


--
-- Data for Name: commandcenter_companyinformation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_companyinformation (id, company_name, company_twitter, company_email, company_address, company_short_name) FROM stdin;
1	Great Lakes XX				Great Lakes XX
\.


--
-- Data for Name: commandcenter_extrafieldmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_extrafieldmodel (model_internal_name, model_display_name, is_collab_editable) FROM stdin;
rolodex.Project	Projects	f
rolodex.Client	Clients	f
reporting.Finding	Findings	t
oplog.OplogEntry	Oplog Entries	f
shepherd.Domain	Domains	f
shepherd.StaticServer	Servers	f
reporting.Report	Reports	t
reporting.Observation	Observations	t
\.


--
-- Data for Name: commandcenter_extrafieldspec; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_extrafieldspec (id, internal_name, display_name, type, target_model_id, _order, user_default_value, description) FROM stdin;
\.


--
-- Data for Name: commandcenter_generalconfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_generalconfiguration (id, default_timezone, hostname) FROM stdin;
1	America/Los_Angeles	ghostwriter.local
\.


--
-- Data for Name: commandcenter_namecheapconfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_namecheapconfiguration (id, enable, api_key, username, api_username, client_ip, page_size) FROM stdin;
1	f	Namecheap API Key	Account Username	API Username	Whitelisted IP Address	100
\.


--
-- Data for Name: commandcenter_reportconfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_reportconfiguration (id, border_weight, border_color, prefix_figure, prefix_table, default_docx_template_id, default_pptx_template_id, enable_borders, label_figure, label_table, report_filename, target_delivery_date, title_case_captions, title_case_exceptions, project_filename, table_caption_location, figure_caption_location) FROM stdin;
1	12700	2D2B6B	 – 	 – 	\N	\N	f	Figure	Table	{{now|format_datetime("Y-m-d_His")}} {{company.name}} - {{client.name}} {{project.project_type}} Report	5	t	a,as,at,an,and,of,the,is,to,by,for,in,on,but,or	{{now|format_datetime("Y-m-d_His")}} {{company.name}} - {{client.name}} {{project.project_type}} Report	top	bottom
\.


--
-- Data for Name: commandcenter_slackconfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_slackconfiguration (id, enable, webhook_url, slack_emoji, slack_channel, slack_username, slack_alert_target) FROM stdin;
1	f	https://hooks.slack.com/services/<your_webhook_url>	:ghost:	#ghostwriter	Ghostwriter	<!here>
\.


--
-- Data for Name: commandcenter_virustotalconfiguration; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.commandcenter_virustotalconfiguration (id, enable, api_key, sleep_time) FROM stdin;
1	f	VirusTotal API Key	20
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
1	2025-10-09 23:49:50.618329+00	2	yuliang	1	[{"added": {}}]	24	1
2	2025-10-09 23:49:55.611411+00	2	yuliang	2	[]	24	1
3	2025-10-09 23:50:05.271836+00	3	nathan	1	[{"added": {}}]	24	1
4	2025-10-09 23:50:15.532687+00	4	adriel	1	[{"added": {}}]	24	1
5	2025-10-09 23:50:23.459093+00	5	adam	1	[{"added": {}}]	24	1
6	2025-10-09 23:50:39.432315+00	6	rippy	1	[{"added": {}}]	24	1
7	2025-10-09 23:50:46.881075+00	6	avigail	2	[{"changed": {"fields": ["Username"]}}]	24	1
8	2025-10-09 23:51:27.766813+00	6	avigail	2	[]	24	1
9	2025-10-09 23:51:38.420568+00	7	rippy	1	[{"added": {}}]	24	1
10	2025-10-10 00:01:09.759533+00	1	Company Information	2	[{"changed": {"fields": ["Company name", "Company short name", "Company address", "Twitter Handle", "Company email"]}}]	78	1
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	contenttypes	contenttype
4	sessions	session
5	sites	site
6	admin	logentry
7	account	emailaddress
8	account	emailconfirmation
9	otp_totp	totpdevice
10	otp_static	staticdevice
11	otp_static	statictoken
12	socialaccount	socialaccount
13	socialaccount	socialapp
14	socialaccount	socialtoken
15	rest_framework_api_key	apikey
16	django_q	schedule
17	django_q	task
18	django_q	failure
19	django_q	success
20	django_q	ormq
21	db	testmodel
22	taggit	tag
23	taggit	taggeditem
24	users	user
25	home	userprofile
26	rolodex	client
27	rolodex	project
28	rolodex	projectrole
29	rolodex	projecttype
30	rolodex	projectnote
31	rolodex	projectassignment
32	rolodex	clientnote
33	rolodex	clientcontact
34	rolodex	objectivestatus
35	rolodex	projectobjective
36	rolodex	projectscope
37	rolodex	projecttarget
38	rolodex	projectsubtask
39	rolodex	objectivepriority
40	rolodex	projectinvite
41	rolodex	clientinvite
42	rolodex	deconflictionstatus
43	rolodex	deconfliction
44	rolodex	whitecard
45	rolodex	projectcontact
46	shepherd	activitytype
47	shepherd	domain
48	shepherd	domainstatus
49	shepherd	healthstatus
50	shepherd	serverprovider
51	shepherd	serverrole
52	shepherd	serverstatus
53	shepherd	whoisstatus
54	shepherd	transientserver
55	shepherd	staticserver
56	shepherd	servernote
57	shepherd	serverhistory
58	shepherd	history
59	shepherd	domainserverconnection
60	shepherd	domainnote
61	shepherd	auxserveraddress
62	reporting	findingtype
63	reporting	report
64	reporting	severity
65	reporting	reportfindinglink
66	reporting	finding
67	reporting	evidence
68	reporting	archive
69	reporting	localfindingnote
70	reporting	findingnote
71	reporting	reporttemplate
72	reporting	doctype
73	reporting	observation
74	reporting	reportobservationlink
75	oplog	oplog
76	oplog	oplogentry
77	commandcenter	cloudservicesconfiguration
78	commandcenter	companyinformation
79	commandcenter	namecheapconfiguration
80	commandcenter	reportconfiguration
81	commandcenter	slackconfiguration
82	commandcenter	virustotalconfiguration
83	commandcenter	generalconfiguration
84	commandcenter	extrafieldmodel
85	commandcenter	extrafieldspec
86	commandcenter	bannerconfiguration
87	api	apikey
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-10-09 23:40:31.844415+00
2	contenttypes	0002_remove_content_type_name	2025-10-09 23:40:31.848571+00
3	auth	0001_initial	2025-10-09 23:40:31.88653+00
4	auth	0002_alter_permission_name_max_length	2025-10-09 23:40:31.889941+00
5	auth	0003_alter_user_email_max_length	2025-10-09 23:40:31.894181+00
6	auth	0004_alter_user_username_opts	2025-10-09 23:40:31.897663+00
7	auth	0005_alter_user_last_login_null	2025-10-09 23:40:31.901074+00
8	auth	0006_require_contenttypes_0002	2025-10-09 23:40:31.902739+00
9	auth	0007_alter_validators_add_error_messages	2025-10-09 23:40:31.906143+00
10	auth	0008_alter_user_username_max_length	2025-10-09 23:40:31.910034+00
11	auth	0009_alter_user_last_name_max_length	2025-10-09 23:40:31.913714+00
12	auth	0010_alter_group_name_max_length	2025-10-09 23:40:31.91795+00
13	auth	0011_update_proxy_permissions	2025-10-09 23:40:31.921931+00
14	users	0001_initial	2025-10-09 23:40:31.970533+00
15	account	0001_initial	2025-10-09 23:40:32.007007+00
16	account	0002_email_max_length	2025-10-09 23:40:32.012576+00
17	account	0003_alter_emailaddress_create_unique_verified_email	2025-10-09 23:40:32.025274+00
18	account	0004_alter_emailaddress_drop_unique_email	2025-10-09 23:40:32.0329+00
19	account	0005_emailaddress_idx_upper_email	2025-10-09 23:40:32.042461+00
20	account	0006_emailaddress_lower	2025-10-09 23:40:32.049298+00
21	account	0007_emailaddress_idx_email	2025-10-09 23:40:32.063724+00
22	account	0008_emailaddress_unique_primary_email_fixup	2025-10-09 23:40:32.072622+00
23	account	0009_emailaddress_unique_primary_email	2025-10-09 23:40:32.083603+00
24	admin	0001_initial	2025-10-09 23:40:32.103884+00
25	admin	0002_logentry_remove_auto_add	2025-10-09 23:40:32.109804+00
26	admin	0003_logentry_add_action_flag_choices	2025-10-09 23:40:32.116346+00
27	api	0001_initial	2025-10-09 23:40:32.137101+00
28	auth	0012_alter_user_first_name_max_length	2025-10-09 23:40:32.179599+00
29	taggit	0001_initial	2025-10-09 23:40:32.215386+00
30	taggit	0002_auto_20150616_2121	2025-10-09 23:40:32.222787+00
31	taggit	0003_taggeditem_add_unique_index	2025-10-09 23:40:32.22844+00
32	taggit	0004_alter_taggeditem_content_type_alter_taggeditem_tag	2025-10-09 23:40:32.241538+00
33	taggit	0005_auto_20220424_2025	2025-10-09 23:40:32.244762+00
34	rolodex	0001_initial	2025-10-09 23:40:32.389891+00
35	rolodex	0002_objectivestatus_projectobjective	2025-10-09 23:40:32.424595+00
36	rolodex	0003_auto_20190828_0007	2025-10-09 23:40:32.430219+00
37	rolodex	0004_auto_20190910_0113	2025-10-09 23:40:32.439771+00
38	rolodex	0005_auto_20191122_2304	2025-10-09 23:40:32.449624+00
39	rolodex	0006_auto_20200825_1947	2025-10-09 23:40:32.600821+00
40	reporting	0001_initial	2025-10-09 23:40:32.752697+00
41	reporting	0002_localfindingnote	2025-10-09 23:40:32.784071+00
42	reporting	0003_findingnote	2025-10-09 23:40:32.819337+00
43	reporting	0004_report_delivered	2025-10-09 23:40:32.83574+00
44	reporting	0005_reportfindinglink_finding_guidance	2025-10-09 23:40:32.8501+00
45	reporting	0006_auto_20191122_2304	2025-10-09 23:40:32.936755+00
46	reporting	0007_auto_20200110_0505	2025-10-09 23:40:32.94755+00
47	reporting	0008_auto_20200825_1947	2025-10-09 23:40:33.101444+00
48	reporting	0009_auto_20200915_0011	2025-10-09 23:40:33.114307+00
49	reporting	0010_reporttemplate	2025-10-09 23:40:33.154355+00
50	reporting	0011_report_template	2025-10-09 23:40:33.175257+00
51	reporting	0012_auto_20200923_2228	2025-10-09 23:40:33.194176+00
52	reporting	0013_reporttemplate_lint_result	2025-10-09 23:40:33.206476+00
53	reporting	0014_auto_20200924_1822	2025-10-09 23:40:33.218776+00
54	reporting	0015_auto_20201016_1756	2025-10-09 23:40:33.268401+00
55	reporting	0016_auto_20201017_0014	2025-10-09 23:40:33.37657+00
56	reporting	0017_auto_20201019_2318	2025-10-09 23:40:33.400469+00
57	reporting	0018_auto_20201027_1914	2025-10-09 23:40:33.41823+00
58	reporting	0019_auto_20201105_0609	2025-10-09 23:40:33.42873+00
59	reporting	0020_auto_20201105_0641	2025-10-09 23:40:33.439127+00
60	reporting	0021_auto_20201119_2343	2025-10-09 23:40:33.449341+00
61	reporting	0022_auto_20210211_2109	2025-10-09 23:40:33.459977+00
62	reporting	0023_auto_20210318_2120	2025-10-09 23:40:33.463952+00
63	reporting	0024_auto_20220205_0026	2025-10-09 23:40:33.91453+00
64	reporting	0025_alter_reporttemplate_lint_result	2025-10-09 23:40:33.945611+00
65	reporting	0026_convert_linting_status_to_json	2025-10-09 23:40:33.961974+00
66	reporting	0027_auto_20220510_1923	2025-10-09 23:40:33.967247+00
67	reporting	0028_auto_20220608_1808	2025-10-09 23:40:33.99435+00
68	reporting	0029_auto_20220706_1717	2025-10-09 23:40:33.997546+00
69	reporting	0030_reportfindinglink_added_as_blank	2025-10-09 23:40:34.008851+00
70	reporting	0031_alter_severity_severity	2025-10-09 23:40:34.014132+00
71	reporting	0032_finding_tags	2025-10-09 23:40:34.084139+00
72	reporting	0033_auto_20221122_1938	2025-10-09 23:40:34.138706+00
73	reporting	0034_reporttemplate_tags	2025-10-09 23:40:34.15219+00
74	reporting	0035_auto_20221214_2132	2025-10-09 23:40:34.165922+00
75	reporting	0036_reporttemplate_landscape	2025-10-09 23:40:34.179112+00
76	reporting	0037_alter_reportfindinglink_cvss_vector	2025-10-09 23:40:34.191372+00
77	reporting	0038_alter_reportfindinglink_added_as_blank	2025-10-09 23:40:34.194033+00
78	reporting	0037_reporttemplate_p_style	2025-10-09 23:40:34.206074+00
79	reporting	0039_merge_20230918_2015	2025-10-09 23:40:34.208328+00
80	reporting	0040_alter_reporttemplate_p_style	2025-10-09 23:40:34.220446+00
81	reporting	0041_auto_20230919_1751	2025-10-09 23:40:34.266456+00
82	reporting	0042_auto_20230919_1809	2025-10-09 23:40:34.303363+00
83	reporting	0043_finding_extra_fields	2025-10-09 23:40:34.3111+00
84	reporting	0044_reportfindinglink_extra_fields	2025-10-09 23:40:34.323139+00
85	reporting	0045_report_extra_fields	2025-10-09 23:40:34.344362+00
86	reporting	0043_observation	2025-10-09 23:40:34.372949+00
87	reporting	0044_reportobservationlink	2025-10-09 23:40:34.404144+00
88	reporting	0043_auto_20231116_1810	2025-10-09 23:40:34.518891+00
89	reporting	0046_merge_20231130_2118	2025-10-09 23:40:34.520864+00
90	reporting	0047_auto_20231201_1441	2025-10-09 23:40:34.537325+00
91	reporting	0048_auto_20240307_1831	2025-10-09 23:40:34.540718+00
92	reporting	0049_auto_20240315_1744	2025-10-09 23:40:34.561561+00
93	reporting	0050_reporttemplate_filename_override	2025-10-09 23:40:34.575265+00
94	reporting	0049_extra_fields_db_default	2025-10-09 23:40:34.5792+00
95	reporting	0051_merge_20240429_1901	2025-10-09 23:40:34.581194+00
96	commandcenter	0001_initial	2025-10-09 23:40:34.638267+00
97	commandcenter	0002_auto_20201009_1918	2025-10-09 23:40:34.641953+00
98	commandcenter	0003_auto_20201027_1914	2025-10-09 23:40:34.678285+00
99	commandcenter	0004_auto_20201028_1633	2025-10-09 23:40:34.7112+00
100	commandcenter	0005_auto_20201102_2207	2025-10-09 23:40:34.731605+00
101	commandcenter	0006_auto_20210614_2224	2025-10-09 23:40:34.743592+00
102	commandcenter	0007_auto_20210616_0340	2025-10-09 23:40:34.749472+00
103	commandcenter	0008_remove_namecheapconfiguration_reset_dns	2025-10-09 23:40:34.753057+00
104	commandcenter	0009_cloudservicesconfiguration_notification_delay	2025-10-09 23:40:34.756824+00
105	commandcenter	0010_auto_20220205_0026	2025-10-09 23:40:34.821794+00
106	commandcenter	0011_alter_slackconfiguration_slack_alert_target	2025-10-09 23:40:34.826244+00
107	commandcenter	0012_generalconfiguration	2025-10-09 23:40:34.834306+00
108	commandcenter	0013_reportconfiguration_report_filename	2025-10-09 23:40:34.841125+00
109	commandcenter	0014_alter_reportconfiguration_report_filename	2025-10-09 23:40:34.847457+00
110	commandcenter	0015_alter_reportconfiguration_report_filename	2025-10-09 23:40:34.853657+00
111	commandcenter	0016_auto_20230922_1642	2025-10-09 23:40:34.858437+00
112	commandcenter	0017_extrafieldmodel_extrafieldspec	2025-10-09 23:40:34.888808+00
113	commandcenter	0018_extrafieldspec_user_default_value	2025-10-09 23:40:34.892537+00
114	commandcenter	0019_auto_20240221_0041	2025-10-09 23:40:34.90364+00
115	commandcenter	0020_auto_20240221_0109	2025-10-09 23:40:34.915025+00
116	commandcenter	0021_alter_reportconfiguration_target_delivery_date	2025-10-09 23:40:34.921876+00
117	commandcenter	0022_auto_20240228_2355	2025-10-09 23:40:34.931342+00
118	commandcenter	0023_generalconfiguration_hostname	2025-10-09 23:40:34.936915+00
119	commandcenter	0024_extrafieldspec_description	2025-10-09 23:40:34.940874+00
120	commandcenter	0025_report_filename_template_convert	2025-10-09 23:40:34.964598+00
121	commandcenter	0026_report_filename_template_convert_fix	2025-10-09 23:40:34.983987+00
122	commandcenter	0027_auto_20240422_1818	2025-10-09 23:40:34.99598+00
123	commandcenter	0028_auto_20240429_1912	2025-10-09 23:40:35.025887+00
124	commandcenter	0029_auto_20240604_2120	2025-10-09 23:40:35.037294+00
125	commandcenter	0030_alter_extrafieldspec_type	2025-10-09 23:40:35.041292+00
126	commandcenter	0031_reportconfiguration_table_caption_location	2025-10-09 23:40:35.048639+00
127	commandcenter	0032_reportconfiguration_figure_caption_location	2025-10-09 23:40:35.108733+00
128	commandcenter	0033_auto_20241204_1810	2025-10-09 23:40:35.122553+00
129	commandcenter	0031_alter_generalconfiguration_default_timezone	2025-10-09 23:40:35.131293+00
130	commandcenter	0034_merge_20250110_1938	2025-10-09 23:40:35.13423+00
131	commandcenter	0035_extrafieldmodel_is_collab_editable	2025-10-09 23:40:35.13817+00
132	commandcenter	0036_bannerconfiguration_and_more	2025-10-09 23:40:35.15078+00
133	commandcenter	0037_rename_banner_url_bannerconfiguration_banner_link_and_more	2025-10-09 23:40:35.151798+00
134	commandcenter	0038_bannerconfiguration_expiry_date	2025-10-09 23:40:35.152679+00
135	commandcenter	0039_alter_bannerconfiguration_expiry_date	2025-10-09 23:40:35.153542+00
136	commandcenter	0040_bannerconfiguration_public_banner	2025-10-09 23:40:35.154311+00
137	commandcenter	0041_alter_bannerconfiguration_public_banner	2025-10-09 23:40:35.155094+00
138	health_check_db	0001_initial	2025-10-09 23:40:35.162811+00
139	django_q	0001_initial	2025-10-09 23:40:35.182002+00
140	django_q	0002_auto_20150630_1624	2025-10-09 23:40:35.187594+00
141	django_q	0003_auto_20150708_1326	2025-10-09 23:40:35.202261+00
142	django_q	0004_auto_20150710_1043	2025-10-09 23:40:35.207395+00
143	django_q	0005_auto_20150718_1506	2025-10-09 23:40:35.21236+00
144	django_q	0006_auto_20150805_1817	2025-10-09 23:40:35.216923+00
145	django_q	0007_ormq	2025-10-09 23:40:35.226596+00
146	django_q	0008_auto_20160224_1026	2025-10-09 23:40:35.229948+00
147	django_q	0009_auto_20171009_0915	2025-10-09 23:40:35.240355+00
148	django_q	0010_auto_20200610_0856	2025-10-09 23:40:35.248002+00
149	django_q	0011_auto_20200628_1055	2025-10-09 23:40:35.254282+00
150	django_q	0012_auto_20200702_1608	2025-10-09 23:40:35.257592+00
151	django_q	0013_task_attempt_count	2025-10-09 23:40:35.261779+00
152	django_q	0014_schedule_cluster	2025-10-09 23:40:35.265873+00
153	django_q	0015_alter_schedule_schedule_type	2025-10-09 23:40:35.269561+00
154	django_q	0016_schedule_intended_date_kwarg	2025-10-09 23:40:35.273216+00
155	django_q	0017_task_cluster_alter	2025-10-09 23:40:35.281077+00
156	django_q	0018_task_success_index	2025-10-09 23:40:35.289167+00
157	home	0001_initial	2025-10-09 23:40:35.295513+00
158	home	0002_userprofile_user	2025-10-09 23:40:35.315403+00
159	home	0003_auto_20190729_2213	2025-10-09 23:40:35.327088+00
160	home	0004_auto_20220125_2358	2025-10-09 23:40:35.338113+00
161	home	0005_alter_userprofile_id	2025-10-09 23:40:35.357522+00
162	home	0006_userprofile_hide_quickstart	2025-10-09 23:40:35.370703+00
163	oplog	0001_initial	2025-10-09 23:40:35.423039+00
164	oplog	0002_auto_20200825_2127	2025-10-09 23:40:35.461623+00
165	oplog	0003_auto_20210729_2132	2025-10-09 23:40:35.486829+00
166	oplog	0004_auto_20220205_0026	2025-10-09 23:40:35.541675+00
167	oplog	0005_auto_20220629_1802	2025-10-09 23:40:35.562969+00
168	oplog	0006_oplog_mute_notifications	2025-10-09 23:40:35.57256+00
169	oplog	0007_oplogentry_tags	2025-10-09 23:40:35.590393+00
170	oplog	0008_auto_20221206_2259	2025-10-09 23:40:35.673148+00
171	oplog	0009_auto_20221206_2306	2025-10-09 23:40:35.781128+00
172	oplog	0010_alter_oplogentry_user_context	2025-10-09 23:40:35.790832+00
173	oplog	0011_auto_20230323_2248	2025-10-09 23:40:35.805275+00
174	oplog	0012_auto_20231211_2154	2025-10-09 23:40:35.823794+00
175	oplog	0012_auto_20231208_2134	2025-10-09 23:40:35.869636+00
176	oplog	0013_merge_0012_auto_20231208_2134_0012_auto_20231211_2154	2025-10-09 23:40:35.872237+00
177	oplog	0012_oplogentry_extra_fields	2025-10-09 23:40:35.881173+00
178	oplog	0014_merge_20231215_1939	2025-10-09 23:40:35.883381+00
179	oplog	0015_oplogentry_oplog_fts	2025-10-09 23:40:35.893153+00
180	oplog	0015_extra_fields_db_default	2025-10-09 23:40:35.896114+00
181	oplog	0016_merge_20240429_1901	2025-10-09 23:40:35.898437+00
182	oplog	0017_auto_20240516_1722	2025-10-09 23:40:35.938213+00
183	oplog	0018_remove_oplogentry_oplog_fts	2025-10-09 23:40:35.947848+00
184	oplog	0019_set_text_defaults	2025-10-09 23:40:35.951916+00
185	otp_static	0001_initial	2025-10-09 23:40:36.009229+00
186	otp_static	0002_throttling	2025-10-09 23:40:36.032311+00
187	otp_static	0003_add_timestamps	2025-10-09 23:40:36.054669+00
188	otp_totp	0001_initial	2025-10-09 23:40:36.081874+00
189	otp_totp	0002_auto_20190420_0723	2025-10-09 23:40:36.104583+00
190	otp_totp	0003_add_timestamps	2025-10-09 23:40:36.13262+00
191	reporting	0052_auto_20240516_1722	2025-10-09 23:40:36.548463+00
192	reporting	0053_alter_evidence_document	2025-10-09 23:40:36.563389+00
193	reporting	0054_set_text_defaults	2025-10-09 23:40:36.567805+00
194	reporting	0055_auto_20240924_2108	2025-10-09 23:40:36.607561+00
195	reporting	0056_alter_observation_title	2025-10-09 23:40:36.618203+00
196	reporting	0057_alter_finding_title	2025-10-09 23:40:36.629374+00
197	reporting	0058_alter_reportfindinglink_title	2025-10-09 23:40:36.645078+00
198	reporting	0056_reporttemplate_evidence_image_width	2025-10-09 23:40:36.661789+00
199	reporting	0057_alter_reporttemplate_upload_date	2025-10-09 23:40:36.678081+00
200	reporting	0059_merge_20250409_1340	2025-10-09 23:40:36.680456+00
201	rest_framework_api_key	0001_initial	2025-10-09 23:40:36.695516+00
202	rest_framework_api_key	0002_auto_20190529_2243	2025-10-09 23:40:36.701941+00
203	rest_framework_api_key	0003_auto_20190623_1952	2025-10-09 23:40:36.705455+00
204	rest_framework_api_key	0004_prefix_hashed_key	2025-10-09 23:40:36.744798+00
205	rest_framework_api_key	0005_auto_20220110_1102	2025-10-09 23:40:36.752239+00
206	rolodex	0007_auto_20201027_1914	2025-10-09 23:40:36.77055+00
207	rolodex	0008_projectscope	2025-10-09 23:40:36.8012+00
208	rolodex	0009_projecttarget	2025-10-09 23:40:36.835878+00
209	rolodex	0010_auto_20210204_1957	2025-10-09 23:40:36.846851+00
210	rolodex	0011_projectsubtask	2025-10-09 23:40:36.884308+00
211	rolodex	0012_auto_20210211_1853	2025-10-09 23:40:36.90188+00
212	rolodex	0013_projectsubtask_marked_complete	2025-10-09 23:40:36.907099+00
213	rolodex	0014_projectobjective_marked_complete	2025-10-09 23:40:36.915977+00
214	rolodex	0015_auto_20210219_2204	2025-10-09 23:40:36.943018+00
215	rolodex	0016_auto_20210224_0645	2025-10-09 23:40:37.048601+00
216	rolodex	0017_projectobjective_position	2025-10-09 23:40:37.057875+00
217	rolodex	0018_auto_20210227_0228	2025-10-09 23:40:37.067091+00
218	rolodex	0019_auto_20210303_2155	2025-10-09 23:40:37.081596+00
219	rolodex	0020_auto_20210922_2337	2025-10-09 23:40:37.091943+00
220	rolodex	0021_project_timezone	2025-10-09 23:40:37.110046+00
221	rolodex	0022_auto_20210923_0011	2025-10-09 23:40:37.148072+00
222	rolodex	0023_auto_20210923_0038	2025-10-09 23:40:37.183829+00
223	rolodex	0024_clientcontact_timezone	2025-10-09 23:40:37.195974+00
224	rolodex	0025_auto_20210923_1540	2025-10-09 23:40:37.208711+00
225	rolodex	0026_auto_20211109_1908	2025-10-09 23:40:37.228402+00
226	rolodex	0027_auto_20220205_0026	2025-10-09 23:40:37.976483+00
227	rolodex	0028_clientinvite_projectinvite	2025-10-09 23:40:38.067063+00
228	rolodex	0029_auto_20220510_1922	2025-10-09 23:40:38.075066+00
229	rolodex	0030_auto_20220526_1737	2025-10-09 23:40:38.122609+00
230	rolodex	0031_auto_20220706_1704	2025-10-09 23:40:38.126574+00
231	rolodex	0032_deconfliction_deconflictionstatus	2025-10-09 23:40:38.179851+00
232	rolodex	0033_auto_20221006_1927	2025-10-09 23:40:38.203427+00
233	rolodex	0034_alter_deconfliction_options	2025-10-09 23:40:38.216172+00
234	rolodex	0035_auto_20221007_1627	2025-10-09 23:40:38.219138+00
235	rolodex	0036_whitecard	2025-10-09 23:40:38.315271+00
236	rolodex	0037_auto_20221015_0407	2025-10-09 23:40:38.338379+00
237	rolodex	0038_auto_20221122_1938	2025-10-09 23:40:38.389493+00
238	rolodex	0039_alter_projecttarget_note	2025-10-09 23:40:38.403304+00
239	rolodex	0040_alter_projecttarget_ip_address	2025-10-09 23:40:38.428624+00
240	rolodex	0041_auto_20230110_2347	2025-10-09 23:40:38.484259+00
241	rolodex	0042_projectcontact	2025-10-09 23:40:38.525374+00
242	rolodex	0043_projectcontact_primary	2025-10-09 23:40:38.541294+00
243	rolodex	0044_auto_20230901_1655	2025-10-09 23:40:38.565103+00
244	rolodex	0045_timezone_triggers	2025-10-09 23:40:38.575315+00
245	rolodex	0046_auto_20240111_2238	2025-10-09 23:40:38.600972+00
246	rolodex	0047_auto_20240112_0004	2025-10-09 23:40:38.632929+00
247	rolodex	0045_project_extra_fields	2025-10-09 23:40:38.659492+00
248	rolodex	0046_client_extra_fields	2025-10-09 23:40:38.677366+00
249	rolodex	0048_merge_20240117_1537	2025-10-09 23:40:38.679782+00
250	rolodex	0049_extra_fields_db_default	2025-10-09 23:40:38.683066+00
251	rolodex	0050_auto_20240516_1722	2025-10-09 23:40:39.308712+00
252	rolodex	0051_set_text_defaults	2025-10-09 23:40:39.313913+00
253	rolodex	0052_projectobjective_result	2025-10-09 23:40:39.330733+00
254	sessions	0001_initial	2025-10-09 23:40:39.349213+00
255	shepherd	0001_initial	2025-10-09 23:40:40.052712+00
256	shepherd	0002_auto_20190726_1841	2025-10-09 23:40:40.059431+00
257	shepherd	0003_auto_20190824_0401	2025-10-09 23:40:40.235278+00
258	shepherd	0004_auto_20190910_0113	2025-10-09 23:40:40.30406+00
259	shepherd	0005_auto_20191001_1352	2025-10-09 23:40:40.370541+00
260	shepherd	0006_auto_20191001_1353	2025-10-09 23:40:40.407989+00
261	shepherd	0007_auto_20191029_1636	2025-10-09 23:40:40.444546+00
262	shepherd	0008_auto_20191122_2304	2025-10-09 23:40:40.464624+00
263	shepherd	0009_auxserveraddress	2025-10-09 23:40:40.513379+00
264	shepherd	0010_auto_20200123_0204	2025-10-09 23:40:40.586876+00
265	shepherd	0011_auto_20200123_0726	2025-10-09 23:40:40.597334+00
266	shepherd	0012_auto_20200616_0441	2025-10-09 23:40:40.61568+00
267	shepherd	0013_auto_20200825_1947	2025-10-09 23:40:40.680812+00
268	shepherd	0014_auto_20200909_1804	2025-10-09 23:40:41.148201+00
269	shepherd	0015_auto_20201120_0620	2025-10-09 23:40:41.190163+00
270	shepherd	0016_auto_20210227_0056	2025-10-09 23:40:41.201105+00
271	shepherd	0017_domain_reset_dns	2025-10-09 23:40:41.285332+00
272	shepherd	0018_auto_20210630_2205	2025-10-09 23:40:41.311802+00
273	shepherd	0019_auto_20210706_2242	2025-10-09 23:40:41.332585+00
274	shepherd	0020_transientserver_address	2025-10-09 23:40:41.359189+00
275	shepherd	0021_auto_20210923_1953	2025-10-09 23:40:41.406002+00
276	shepherd	0022_auto_20210923_2115	2025-10-09 23:40:41.436184+00
277	shepherd	0023_auto_20210923_2142	2025-10-09 23:40:41.489363+00
278	shepherd	0024_auto_20210923_2209	2025-10-09 23:40:41.517236+00
279	shepherd	0025_auto_20210923_2214	2025-10-09 23:40:41.545176+00
280	shepherd	0026_auto_20210923_2217	2025-10-09 23:40:41.572169+00
281	shepherd	0027_auto_20210923_2218	2025-10-09 23:40:41.598623+00
282	shepherd	0028_auto_20210923_2234	2025-10-09 23:40:41.693461+00
283	shepherd	0029_auto_20210923_2235	2025-10-09 23:40:41.719959+00
284	shepherd	0030_auto_20211103_1719	2025-10-09 23:40:41.746502+00
285	shepherd	0031_auto_20220201_2331	2025-10-09 23:40:41.768847+00
286	shepherd	0032_migrate_domain_categories	2025-10-09 23:40:41.809562+00
287	shepherd	0033_delete_old_domain_categories	2025-10-09 23:40:41.941651+00
288	shepherd	0034_remove_domain_health_dns	2025-10-09 23:40:41.961767+00
289	shepherd	0035_auto_20220205_0026	2025-10-09 23:40:43.196057+00
290	shepherd	0036_auto_20220209_1815	2025-10-09 23:40:43.241353+00
291	shepherd	0037_convert_dns_record_to_json	2025-10-09 23:40:43.286317+00
292	shepherd	0038_alter_domain_dns_record	2025-10-09 23:40:43.305449+00
293	shepherd	0039_auto_20220510_1909	2025-10-09 23:40:43.311009+00
294	shepherd	0040_auto_20220510_1949	2025-10-09 23:40:43.316896+00
295	shepherd	0041_auto_20220706_1709	2025-10-09 23:40:43.322329+00
296	shepherd	0042_domain_tags	2025-10-09 23:40:43.412203+00
297	shepherd	0043_staticserver_tags	2025-10-09 23:40:43.448417+00
298	shepherd	0044_alter_domain_reset_dns	2025-10-09 23:40:43.471415+00
299	shepherd	0045_domain_extra_fields	2025-10-09 23:40:43.494777+00
300	shepherd	0046_staticserver_extra_fields	2025-10-09 23:40:43.520164+00
301	shepherd	0047_extra_fields_db_default	2025-10-09 23:40:43.524379+00
302	shepherd	0048_auto_20240516_1722	2025-10-09 23:40:43.931847+00
303	shepherd	0049_set_text_defaults	2025-10-09 23:40:43.937231+00
304	shepherd	0050_auto_20240917_1521	2025-10-09 23:40:44.008819+00
305	shepherd	0050_alter_transientserver_ip_address	2025-10-09 23:40:44.043007+00
306	shepherd	0051_merge_20240918_1642	2025-10-09 23:40:44.045832+00
307	sites	0001_initial	2025-10-09 23:40:44.054453+00
308	sites	0002_alter_domain_unique	2025-10-09 23:40:44.065841+00
309	sites	0003_set_site_domain_and_name	2025-10-09 23:40:44.191978+00
310	sites	0004_auto_20210406_0058	2025-10-09 23:40:44.197202+00
311	sites	0005_auto_20210614_1732	2025-10-09 23:40:44.202331+00
312	sites	0006_auto_20210922_2325	2025-10-09 23:40:44.207895+00
313	sites	0007_auto_20230818_2257	2025-10-09 23:40:44.253333+00
314	socialaccount	0001_initial	2025-10-09 23:40:44.409987+00
315	socialaccount	0002_token_max_lengths	2025-10-09 23:40:44.441963+00
316	socialaccount	0003_extra_data_default_dict	2025-10-09 23:40:44.461428+00
317	socialaccount	0004_app_provider_id_settings	2025-10-09 23:40:44.487457+00
318	socialaccount	0005_socialtoken_nullable_app	2025-10-09 23:40:44.526652+00
319	socialaccount	0006_alter_socialaccount_extra_data	2025-10-09 23:40:44.559455+00
320	taggit	0006_rename_taggeditem_content_type_object_id_taggit_tagg_content_8fc721_idx	2025-10-09 23:40:44.588213+00
321	users	0002_auto_20190729_1749	2025-10-09 23:40:44.695992+00
322	users	0003_auto_20210922_2349	2025-10-09 23:40:44.734295+00
323	users	0004_auto_20220126_1735	2025-10-09 23:40:44.757843+00
324	users	0005_alter_user_id	2025-10-09 23:40:45.24109+00
325	users	0006_user_role	2025-10-09 23:40:45.270782+00
326	users	0007_alter_user_role	2025-10-09 23:40:45.292676+00
327	users	0008_auto_20230615_1951	2025-10-09 23:40:45.333349+00
328	users	0009_auto_20230615_2201	2025-10-09 23:40:45.391182+00
329	users	0010_alter_user_role	2025-10-09 23:40:45.468797+00
330	users	0011_user_require_2fa	2025-10-09 23:40:45.490244+00
331	users	0012_auto_20240220_1810	2025-10-09 23:40:45.548571+00
332	db	0001_initial	2025-10-09 23:40:45.555367+00
333	commandcenter	0036_bannerconfiguration_and_more_squashed_0041_alter_bannerconfiguration_public_banner	2025-10-09 23:40:45.557803+00
\.


--
-- Data for Name: django_q_ormq; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_q_ormq (id, key, payload, lock) FROM stdin;
\.


--
-- Data for Name: django_q_schedule; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_q_schedule (id, func, hook, args, kwargs, schedule_type, repeats, next_run, task, name, minutes, cron, cluster, intended_date_kwarg) FROM stdin;
\.


--
-- Data for Name: django_q_task; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_q_task (name, func, hook, args, kwargs, result, started, stopped, success, id, "group", attempt_count, cluster) FROM stdin;
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
ginoutte9bhr3tgenc6wstc8n8u8nx1x	.eJxVkEFuwyAQRe8ya8tyjAHjZfc5QVVZA4xrmgYiBqutrNy9ps0mu9H_b97i74DOpS2WGbeyUizBYQkpzlcqa_IM0-sO_zdMcEPmr5Q9NIAFppNWXScHKYbW9HroBtXAxpQjXumgI5YVI9zfGvizz7WbQxUJeMosugvFWvgPjO-pdSmWHGxbkfbRcntOnj5fHuyTYEVej2_lyJvRaKV6q8aTUMuotF0EGtJ6Ecrj2DvRe93T6KSX0hihpVwEDVZ1WlcpE3MdgL5vIf_A1DXAwZPFDNMOfAx0OdKSN7rffwHP42lW:1v70aa:MkKkqSDlRE-u6VlvADs9Ds_tqtOcEpQGp1QrL6fXHPI	2025-10-10 09:02:28.022651+00
ddt0x3fc36ahrf9zffh32rweujtay1d3	.eJxVkE1rhDAQhv_KMmcR12wS9dbeC6X0VoqMyVjTdRNJYj8Q_3uT7l72NszzzgvzbIBKudXGHtc4kY1GYTTO9heKk9MBurcNrjN0sGAI385rKAAjdEcpqoqfGsHKljEu-LGANZC3eKGUthgntLC_F_Df3mfWm1zE4G43oDqTzUB_ov1wpXI2ejOUOVLeaCifnKb58Za9K5gwTOlaKNJt00oh6kE0RybGRshhZNiSlCMTGptasVrLmhrFNedtyyTnI6PTICopc2mgELIA-lmM_4WuKiAYTQN66DYISdA5baNfaU8WVDRf1HtanI-Z5--ShWjinBU8zPPhOaFweHWrD4eXa3Df_wDrtn0q:1v70fy:LCJgP-717i_vuxKIUen7UQmyl0pW0s8MoL8IN0mL4Ls	2025-10-10 09:08:02.853884+00
roxen15pzjrcfko4u04kv6pq4yolfqxi	.eJxVkMtqwzAQRX8lzNoYyZYc27t2Xyilu1KMHuNajS0FjdwHwf9eq8kmu-Gey4G5F1DGhNWnQa1pQp-cUckFPyyYpmAJ-rcLXG_o4ayIvkO0UIBK0PNjw5gUompLXresqgpYCaNXC-5lZRfnYXsv4N89ZDS4rOFwl2llTugzsJ_Kf4TSBJ-i02WulDdK5VOwOD_euneCSdGUtTWXdmScN6YyxkiUQiquJZMG7dgJM3ZSt8hEy1nb1J2Qx7rSo2iOwtZcd1lKSJTfx5-zi7_QswLIWdQqQn8B2uc57WmKK277Bia5LxwinkNMmefveAHJpTkv8DDPh-cd0eE1rJEOL9fitv0B38N8Yw:1v70Zx:NrUYHHyUiZ7WbYJVpGk5RFDjW_b4_epo5Yi1jwuLceU	2025-10-10 09:01:49.689786+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.django_site (id, domain, name) FROM stdin;
1	ghostwriter.local	Ghostwriter
\.


--
-- Data for Name: health_check_db_testmodel; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.health_check_db_testmodel (id, title) FROM stdin;
\.


--
-- Data for Name: home_userprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.home_userprofile (id, avatar, user_id, hide_quickstart) FROM stdin;
1		1	t
2		2	f
4		4	f
5		5	f
6		6	f
7		7	f
3		3	t
\.


--
-- Data for Name: oplog_oplog; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oplog_oplog (id, name, project_id, mute_notifications) FROM stdin;
\.


--
-- Data for Name: oplog_oplogentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.oplog_oplogentry (id, start_date, end_date, source_ip, dest_ip, tool, user_context, command, description, output, comments, operator_name, oplog_id_id, entry_identifier, extra_fields) FROM stdin;
\.


--
-- Data for Name: otp_static_staticdevice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_static_staticdevice (id, name, confirmed, user_id, throttling_failure_count, throttling_failure_timestamp, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: otp_static_statictoken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_static_statictoken (id, token, device_id) FROM stdin;
\.


--
-- Data for Name: otp_totp_totpdevice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.otp_totp_totpdevice (id, name, confirmed, key, step, t0, digits, tolerance, drift, last_t, user_id, throttling_failure_count, throttling_failure_timestamp, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: reporting_archive; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_archive (id, report_archive, project_id) FROM stdin;
\.


--
-- Data for Name: reporting_doctype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_doctype (id, doc_type, extension, name) FROM stdin;
1	docx	docx	Report DOCX
2	pptx	pptx	PPTX
3	project_docx	docx	Project DOCX
\.


--
-- Data for Name: reporting_evidence; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_evidence (id, document, friendly_name, upload_date, caption, description, finding_id, uploaded_by_id, report_id) FROM stdin;
\.


--
-- Data for Name: reporting_finding; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_finding (id, title, description, impact, mitigation, replication_steps, host_detection_techniques, network_detection_techniques, "references", finding_guidance, finding_type_id, severity_id, cvss_score, cvss_vector, extra_fields) FROM stdin;
\.


--
-- Data for Name: reporting_findingnote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_findingnote (id, "timestamp", note, finding_id, operator_id) FROM stdin;
\.


--
-- Data for Name: reporting_findingtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_findingtype (id, finding_type) FROM stdin;
1	Network
2	Physical
3	Wireless
4	Web
5	Mobile
6	Cloud
7	Host
\.


--
-- Data for Name: reporting_localfindingnote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_localfindingnote (id, "timestamp", note, finding_id, operator_id) FROM stdin;
\.


--
-- Data for Name: reporting_observation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_observation (id, title, description, extra_fields) FROM stdin;
\.


--
-- Data for Name: reporting_report; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_report (id, title, creation, last_update, complete, archived, created_by_id, project_id, delivered, docx_template_id, pptx_template_id, extra_fields) FROM stdin;
1	All Ports Tours Report	2025-10-09	2025-10-10	f	f	1	1	f	1	2	{}
\.


--
-- Data for Name: reporting_reportfindinglink; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_reportfindinglink (id, title, "position", affected_entities, description, impact, mitigation, replication_steps, host_detection_techniques, network_detection_techniques, "references", complete, assigned_to_id, finding_type_id, report_id, severity_id, finding_guidance, cvss_score, cvss_vector, added_as_blank, extra_fields) FROM stdin;
\.


--
-- Data for Name: reporting_reportobservationlink; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_reportobservationlink (id, title, "position", description, added_as_blank, assigned_to_id, report_id, extra_fields) FROM stdin;
\.


--
-- Data for Name: reporting_reporttemplate; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_reporttemplate (id, document, name, upload_date, last_update, description, protected, client_id, uploaded_by_id, lint_result, changelog, doc_type_id, landscape, p_style, filename_override, evidence_image_width) FROM stdin;
1	/app/ghostwriter/media/templates/template.docx	Default Word Template	2025-10-09	2025-10-09	A sample Word template provided by Ghostwriter.	f	\N	\N	{"errors": [], "result": "success", "warnings": []}		1	f	Normal		6.5
2	/app/ghostwriter/media/templates/template.pptx	Default PowerPoint Template	2025-10-09	2025-10-09	A sample PowerPoint presentation template provided by Ghostwriter.	f	\N	\N	{"errors": [], "result": "success", "warnings": []}		2	f			6.5
\.


--
-- Data for Name: reporting_severity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reporting_severity (id, severity, weight, color) FROM stdin;
5	Critical	1	966FD6
4	High	2	FF7E79
3	Medium	3	F4B083
2	Low	4	A8D08D
1	Informational	5	8EAADB
\.


--
-- Data for Name: rest_framework_api_key_apikey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rest_framework_api_key_apikey (id, created, name, revoked, expiry_date, hashed_key, prefix) FROM stdin;
\.


--
-- Data for Name: rolodex_client; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_client (id, name, short_name, codename, note, address, timezone, extra_fields) FROM stdin;
1	All Ports Tours	APT	ALLPORTSTOURS			America/Los_Angeles	{}
\.


--
-- Data for Name: rolodex_clientcontact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_clientcontact (id, name, job_title, email, phone, note, client_id, timezone) FROM stdin;
\.


--
-- Data for Name: rolodex_clientinvite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_clientinvite (id, comment, client_id, user_id) FROM stdin;
1		1	5
2		1	4
3		1	6
4		1	3
5		1	7
6		1	2
\.


--
-- Data for Name: rolodex_clientnote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_clientnote (id, "timestamp", note, client_id, operator_id) FROM stdin;
\.


--
-- Data for Name: rolodex_deconfliction; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_deconfliction (id, created_at, report_timestamp, alert_timestamp, response_timestamp, title, description, alert_source, project_id, status_id) FROM stdin;
\.


--
-- Data for Name: rolodex_deconflictionstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_deconflictionstatus (id, status, weight) FROM stdin;
1	Undetermined	1
2	Confirmed	2
3	Unrelated	3
\.


--
-- Data for Name: rolodex_objectivepriority; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_objectivepriority (id, weight, priority) FROM stdin;
1	0	Primary
2	1	Secondary
3	2	Tertiary
\.


--
-- Data for Name: rolodex_objectivestatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_objectivestatus (id, objective_status) FROM stdin;
1	Active
2	On Hold
3	In Progress
4	Missed
\.


--
-- Data for Name: rolodex_project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_project (id, codename, start_date, end_date, note, slack_channel, complete, client_id, operator_id, project_type_id, timezone, end_time, start_time, extra_fields) FROM stdin;
1	ALLPORTSTOURSPROJECT	2025-10-18	2025-10-18			f	1	\N	2	America/Los_Angeles	17:00:00	09:00:00	{}
\.


--
-- Data for Name: rolodex_projectassignment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projectassignment (id, start_date, end_date, note, operator_id, project_id, role_id) FROM stdin;
\.


--
-- Data for Name: rolodex_projectcontact; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projectcontact (id, name, job_title, email, phone, timezone, note, project_id, "primary") FROM stdin;
\.


--
-- Data for Name: rolodex_projectinvite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projectinvite (id, comment, project_id, user_id) FROM stdin;
\.


--
-- Data for Name: rolodex_projectnote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projectnote (id, "timestamp", note, operator_id, project_id) FROM stdin;
\.


--
-- Data for Name: rolodex_projectobjective; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projectobjective (id, objective, complete, deadline, project_id, status_id, marked_complete, description, priority_id, "position", result) FROM stdin;
\.


--
-- Data for Name: rolodex_projectrole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projectrole (id, project_role) FROM stdin;
1	Assessment Lead
2	Assessment Oversight
3	Operator
\.


--
-- Data for Name: rolodex_projectscope; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projectscope (id, name, scope, description, disallowed, requires_caution, project_id) FROM stdin;
\.


--
-- Data for Name: rolodex_projectsubtask; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projectsubtask (id, task, complete, deadline, parent_id, status_id, marked_complete) FROM stdin;
\.


--
-- Data for Name: rolodex_projecttarget; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projecttarget (id, ip_address, hostname, note, compromised, project_id) FROM stdin;
\.


--
-- Data for Name: rolodex_projecttype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_projecttype (id, project_type) FROM stdin;
1	Red Team
2	Penetration Test
3	Phishing Assessment
4	Web Application Assessment
\.


--
-- Data for Name: rolodex_whitecard; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rolodex_whitecard (id, issued, title, description, project_id) FROM stdin;
\.


--
-- Data for Name: shepherd_activitytype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_activitytype (id, activity) FROM stdin;
1	Command and Control
2	Phishing
\.


--
-- Data for Name: shepherd_auxserveraddress; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_auxserveraddress (id, ip_address, static_server_id, "primary") FROM stdin;
\.


--
-- Data for Name: shepherd_domain; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_domain (id, name, registrar, creation, expiration, note, burned_explanation, domain_status_id, health_status_id, last_used_by_id, whois_status_id, auto_renew, expired, last_health_check, vt_permalink, reset_dns, categorization, dns, extra_fields) FROM stdin;
\.


--
-- Data for Name: shepherd_domainnote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_domainnote (id, "timestamp", note, domain_id, operator_id) FROM stdin;
\.


--
-- Data for Name: shepherd_domainserverconnection; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_domainserverconnection (id, endpoint, subdomain, domain_id, project_id, static_server_id, transient_server_id) FROM stdin;
\.


--
-- Data for Name: shepherd_domainstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_domainstatus (id, domain_status) FROM stdin;
1	Available
2	Unavailable
3	Reserved
4	Burned
5	Expired
\.


--
-- Data for Name: shepherd_healthstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_healthstatus (id, health_status) FROM stdin;
1	Healthy
2	Burned
3	Questionable
\.


--
-- Data for Name: shepherd_history; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_history (id, start_date, end_date, note, activity_type_id, client_id, domain_id, operator_id, project_id) FROM stdin;
\.


--
-- Data for Name: shepherd_serverhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_serverhistory (id, start_date, end_date, note, activity_type_id, client_id, operator_id, project_id, server_id, server_role_id) FROM stdin;
\.


--
-- Data for Name: shepherd_servernote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_servernote (id, "timestamp", note, operator_id, server_id) FROM stdin;
\.


--
-- Data for Name: shepherd_serverprovider; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_serverprovider (id, server_provider) FROM stdin;
1	Amazon Web Services
2	Microsoft Azure
3	Digital Ocean
4	Google Compute Engine
5	Linode
6	Rackspace
\.


--
-- Data for Name: shepherd_serverrole; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_serverrole (id, server_role) FROM stdin;
1	Team Server / C2 Server
2	Redirector
3	Payload Hosting
4	SMTP
5	Burner Workstation
\.


--
-- Data for Name: shepherd_serverstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_serverstatus (id, server_status) FROM stdin;
1	Available
2	Unavailable
3	Reserved
\.


--
-- Data for Name: shepherd_staticserver; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_staticserver (id, ip_address, note, last_used_by_id, server_provider_id, server_status_id, name, extra_fields) FROM stdin;
\.


--
-- Data for Name: shepherd_transientserver; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_transientserver (id, ip_address, note, activity_type_id, operator_id, project_id, server_provider_id, server_role_id, name, aux_address) FROM stdin;
\.


--
-- Data for Name: shepherd_whoisstatus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.shepherd_whoisstatus (id, whois_status) FROM stdin;
1	Enabled
2	Disabled
3	Unknown
\.


--
-- Data for Name: socialaccount_socialaccount; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socialaccount_socialaccount (id, provider, uid, last_login, date_joined, extra_data, user_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socialaccount_socialapp (id, provider, name, client_id, secret, key, provider_id, settings) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialapp_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socialaccount_socialapp_sites (id, socialapp_id, site_id) FROM stdin;
\.


--
-- Data for Name: socialaccount_socialtoken; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.socialaccount_socialtoken (id, token, token_secret, expires_at, account_id, app_id) FROM stdin;
\.


--
-- Data for Name: taggit_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.taggit_tag (id, name, slug) FROM stdin;
\.


--
-- Data for Name: taggit_taggeditem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.taggit_taggeditem (id, object_id, content_type_id, tag_id) FROM stdin;
\.


--
-- Data for Name: users_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_user (id, password, last_login, is_superuser, username, email, is_staff, is_active, date_joined, name, phone, timezone, role, enable_finding_create, enable_finding_edit, enable_finding_delete, require_2fa, enable_observation_create, enable_observation_delete, enable_observation_edit) FROM stdin;
3	argon2$argon2id$v=19$m=102400,t=2,p=8$VUdKbjEwaFE5cm53dzdzamVDcjF6Sg$Fmmy4YXpgUhLCFm29rI8yewucRHjTv9YvrssEtmbCbc	2025-10-10 00:07:43.943787+00	f	nathan		f	t	2025-10-09 23:50:05.153559+00		\N	America/Los_Angeles	user	f	f	f	f	f	f	f
1	argon2$argon2id$v=19$m=102400,t=2,p=8$WmtyNVNKYXFOQzRLMjBiRUY5WU1kRQ$JSlh+81S+gqpi3VKPQ57fQyXubZhVHCc/XrB4/idY2s	2025-10-10 00:03:01.815921+00	t	admin		t	t	2025-10-09 23:40:55.406319+00		\N	America/Los_Angeles	admin	f	f	f	f	f	f	f
2	argon2$argon2id$v=19$m=102400,t=2,p=8$TGIwOU41TGRucTdqYlBZd2J0OVNDUw$jcfEP/2Vm2qAqRL7UqySBcGAXDwX9C1/5Qcc3rPZE3I	2025-10-10 00:05:54.073659+00	f	yuliang		f	t	2025-10-09 23:49:50+00		\N	America/Los_Angeles	user	f	f	f	f	f	f	f
4	argon2$argon2id$v=19$m=102400,t=2,p=8$bXJSZ0tVWjVWNnA1YVBST2M4VjBSTA$pTRbJ4QIyCIUOrF2AF60x+F7Pi6OCTlanmNxWx9nhR8	2025-10-10 00:06:11.871981+00	f	adriel		f	t	2025-10-09 23:50:15.406256+00		\N	America/Los_Angeles	user	f	f	f	f	f	f	f
5	argon2$argon2id$v=19$m=102400,t=2,p=8$RDFkZldHSG82bmxRNFRwUHJJVjhuYQ$hWfIjqXCE0kVXrGDzMljLOSE/biOYjM847eosvLWLRc	2025-10-10 00:06:49.850913+00	f	adam		f	t	2025-10-09 23:50:23.303437+00		\N	America/Los_Angeles	user	f	f	f	f	f	f	f
7	argon2$argon2id$v=19$m=102400,t=2,p=8$eVZ1ZlE2RmJwczFBRnZNZnhpNGIzMA$Rh6GqdwYN3E/EcVWSLKHIbtqMG0C5Wt/uw0oinKNWsc	2025-10-10 00:07:06.9254+00	f	rippy		f	t	2025-10-09 23:51:38.293069+00		\N	America/Los_Angeles	user	f	f	f	f	f	f	f
6	argon2$argon2id$v=19$m=102400,t=2,p=8$S0h2aGNLTjM1NWNLbXhYaWJaNEZkZA$qDVauFZUxSRgDt7NVSgxw877zHCiwlI/Trmi1Rl6+n8	2025-10-10 00:07:22.056609+00	f	avigail		f	t	2025-10-09 23:50:39+00		\N	America/Los_Angeles	user	f	f	f	f	f	f	f
\.


--
-- Data for Name: users_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: users_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: account_emailaddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_emailaddress_id_seq', 1, false);


--
-- Name: account_emailconfirmation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.account_emailconfirmation_id_seq', 1, false);


--
-- Name: api_apikey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.api_apikey_id_seq', 1, false);


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 348, true);


--
-- Name: commandcenter_bannerconfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_bannerconfiguration_id_seq', 1, false);


--
-- Name: commandcenter_cloudservicesconfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_cloudservicesconfiguration_id_seq', 1, false);


--
-- Name: commandcenter_companyinformation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_companyinformation_id_seq', 1, false);


--
-- Name: commandcenter_extrafieldspec_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_extrafieldspec_id_seq', 1, false);


--
-- Name: commandcenter_generalconfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_generalconfiguration_id_seq', 1, false);


--
-- Name: commandcenter_namecheapconfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_namecheapconfiguration_id_seq', 1, false);


--
-- Name: commandcenter_reportconfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_reportconfiguration_id_seq', 1, false);


--
-- Name: commandcenter_slackconfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_slackconfiguration_id_seq', 1, false);


--
-- Name: commandcenter_virustotalconfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.commandcenter_virustotalconfiguration_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 10, true);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 87, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 333, true);


--
-- Name: django_q_ormq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_q_ormq_id_seq', 1, false);


--
-- Name: django_q_schedule_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_q_schedule_id_seq', 1, false);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, false);


--
-- Name: health_check_db_testmodel_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.health_check_db_testmodel_id_seq', 1, false);


--
-- Name: home_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.home_userprofile_id_seq', 7, true);


--
-- Name: oplog_oplog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oplog_oplog_id_seq', 1, false);


--
-- Name: oplog_oplogentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.oplog_oplogentry_id_seq', 1, false);


--
-- Name: otp_static_staticdevice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.otp_static_staticdevice_id_seq', 1, false);


--
-- Name: otp_static_statictoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.otp_static_statictoken_id_seq', 1, false);


--
-- Name: otp_totp_totpdevice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.otp_totp_totpdevice_id_seq', 1, false);


--
-- Name: reporting_archive_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_archive_id_seq', 1, false);


--
-- Name: reporting_doctype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_doctype_id_seq', 3, true);


--
-- Name: reporting_evidence_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_evidence_id_seq', 1, false);


--
-- Name: reporting_finding_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_finding_id_seq', 1, false);


--
-- Name: reporting_findingnote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_findingnote_id_seq', 1, false);


--
-- Name: reporting_findingtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_findingtype_id_seq', 7, true);


--
-- Name: reporting_localfindingnote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_localfindingnote_id_seq', 1, false);


--
-- Name: reporting_observation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_observation_id_seq', 1, false);


--
-- Name: reporting_report_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_report_id_seq', 1, true);


--
-- Name: reporting_reportfindinglink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_reportfindinglink_id_seq', 1, false);


--
-- Name: reporting_reportobservationlink_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_reportobservationlink_id_seq', 1, false);


--
-- Name: reporting_reporttemplate_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_reporttemplate_id_seq', 2, true);


--
-- Name: reporting_severity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reporting_severity_id_seq', 5, true);


--
-- Name: rolodex_client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_client_id_seq', 1, true);


--
-- Name: rolodex_clientcontact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_clientcontact_id_seq', 1, false);


--
-- Name: rolodex_clientinvite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_clientinvite_id_seq', 6, true);


--
-- Name: rolodex_clientnote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_clientnote_id_seq', 1, false);


--
-- Name: rolodex_deconfliction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_deconfliction_id_seq', 1, false);


--
-- Name: rolodex_deconflictionstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_deconflictionstatus_id_seq', 3, true);


--
-- Name: rolodex_objectivepriority_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_objectivepriority_id_seq', 3, true);


--
-- Name: rolodex_objectivestatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_objectivestatus_id_seq', 4, true);


--
-- Name: rolodex_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_project_id_seq', 1, true);


--
-- Name: rolodex_projectassignment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projectassignment_id_seq', 1, false);


--
-- Name: rolodex_projectcontact_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projectcontact_id_seq', 1, false);


--
-- Name: rolodex_projectinvite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projectinvite_id_seq', 1, false);


--
-- Name: rolodex_projectnote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projectnote_id_seq', 1, false);


--
-- Name: rolodex_projectobjective_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projectobjective_id_seq', 1, false);


--
-- Name: rolodex_projectrole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projectrole_id_seq', 3, true);


--
-- Name: rolodex_projectscope_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projectscope_id_seq', 1, false);


--
-- Name: rolodex_projectsubtask_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projectsubtask_id_seq', 1, false);


--
-- Name: rolodex_projecttarget_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projecttarget_id_seq', 1, false);


--
-- Name: rolodex_projecttype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_projecttype_id_seq', 4, true);


--
-- Name: rolodex_whitecard_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rolodex_whitecard_id_seq', 1, false);


--
-- Name: shepherd_activitytype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_activitytype_id_seq', 2, true);


--
-- Name: shepherd_auxserveraddress_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_auxserveraddress_id_seq', 1, false);


--
-- Name: shepherd_domain_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_domain_id_seq', 1, false);


--
-- Name: shepherd_domainnote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_domainnote_id_seq', 1, false);


--
-- Name: shepherd_domainserverconnection_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_domainserverconnection_id_seq', 1, false);


--
-- Name: shepherd_domainstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_domainstatus_id_seq', 5, true);


--
-- Name: shepherd_healthstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_healthstatus_id_seq', 3, true);


--
-- Name: shepherd_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_history_id_seq', 1, false);


--
-- Name: shepherd_serverhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_serverhistory_id_seq', 1, false);


--
-- Name: shepherd_servernote_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_servernote_id_seq', 1, false);


--
-- Name: shepherd_serverprovider_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_serverprovider_id_seq', 6, true);


--
-- Name: shepherd_serverrole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_serverrole_id_seq', 5, true);


--
-- Name: shepherd_serverstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_serverstatus_id_seq', 3, true);


--
-- Name: shepherd_staticserver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_staticserver_id_seq', 1, false);


--
-- Name: shepherd_transientserver_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_transientserver_id_seq', 1, false);


--
-- Name: shepherd_whoisstatus_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.shepherd_whoisstatus_id_seq', 3, true);


--
-- Name: socialaccount_socialaccount_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socialaccount_socialaccount_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_id_seq', 1, false);


--
-- Name: socialaccount_socialapp_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socialaccount_socialapp_sites_id_seq', 1, false);


--
-- Name: socialaccount_socialtoken_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.socialaccount_socialtoken_id_seq', 1, false);


--
-- Name: taggit_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.taggit_tag_id_seq', 1, false);


--
-- Name: taggit_taggeditem_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.taggit_taggeditem_id_seq', 1, false);


--
-- Name: users_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_groups_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_id_seq', 7, true);


--
-- Name: users_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_user_user_permissions_id_seq', 1, false);


--
-- Name: event_invocation_logs event_invocation_logs_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.event_invocation_logs
    ADD CONSTRAINT event_invocation_logs_pkey PRIMARY KEY (id);


--
-- Name: event_log event_log_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.event_log
    ADD CONSTRAINT event_log_pkey PRIMARY KEY (id);


--
-- Name: hdb_action_log hdb_action_log_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_action_log
    ADD CONSTRAINT hdb_action_log_pkey PRIMARY KEY (id);


--
-- Name: hdb_cron_event_invocation_logs hdb_cron_event_invocation_logs_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_event_invocation_logs
    ADD CONSTRAINT hdb_cron_event_invocation_logs_pkey PRIMARY KEY (id);


--
-- Name: hdb_cron_events hdb_cron_events_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_events
    ADD CONSTRAINT hdb_cron_events_pkey PRIMARY KEY (id);


--
-- Name: hdb_event_log_cleanups hdb_event_log_cleanups_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_event_log_cleanups
    ADD CONSTRAINT hdb_event_log_cleanups_pkey PRIMARY KEY (id);


--
-- Name: hdb_event_log_cleanups hdb_event_log_cleanups_trigger_name_scheduled_at_key; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_event_log_cleanups
    ADD CONSTRAINT hdb_event_log_cleanups_trigger_name_scheduled_at_key UNIQUE (trigger_name, scheduled_at);


--
-- Name: hdb_metadata hdb_metadata_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_metadata
    ADD CONSTRAINT hdb_metadata_pkey PRIMARY KEY (id);


--
-- Name: hdb_metadata hdb_metadata_resource_version_key; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_metadata
    ADD CONSTRAINT hdb_metadata_resource_version_key UNIQUE (resource_version);


--
-- Name: hdb_scheduled_event_invocation_logs hdb_scheduled_event_invocation_logs_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_event_invocation_logs
    ADD CONSTRAINT hdb_scheduled_event_invocation_logs_pkey PRIMARY KEY (id);


--
-- Name: hdb_scheduled_events hdb_scheduled_events_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_events
    ADD CONSTRAINT hdb_scheduled_events_pkey PRIMARY KEY (id);


--
-- Name: hdb_schema_notifications hdb_schema_notifications_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_schema_notifications
    ADD CONSTRAINT hdb_schema_notifications_pkey PRIMARY KEY (id);


--
-- Name: hdb_version hdb_version_pkey; Type: CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_version
    ADD CONSTRAINT hdb_version_pkey PRIMARY KEY (hasura_uuid);


--
-- Name: account_emailaddress account_emailaddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_pkey PRIMARY KEY (id);


--
-- Name: account_emailaddress account_emailaddress_user_id_email_987c8728_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_email_987c8728_uniq UNIQUE (user_id, email);


--
-- Name: account_emailconfirmation account_emailconfirmation_key_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_key_key UNIQUE (key);


--
-- Name: account_emailconfirmation account_emailconfirmation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirmation_pkey PRIMARY KEY (id);


--
-- Name: api_apikey api_apikey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_apikey
    ADD CONSTRAINT api_apikey_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_bannerconfiguration commandcenter_bannerconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_bannerconfiguration
    ADD CONSTRAINT commandcenter_bannerconfiguration_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_cloudservicesconfiguration commandcenter_cloudservicesconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_cloudservicesconfiguration
    ADD CONSTRAINT commandcenter_cloudservicesconfiguration_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_companyinformation commandcenter_companyinformation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_companyinformation
    ADD CONSTRAINT commandcenter_companyinformation_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_extrafieldspec commandcenter_extrafield_target_model_id_internal_75bb84ca_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_extrafieldspec
    ADD CONSTRAINT commandcenter_extrafield_target_model_id_internal_75bb84ca_uniq UNIQUE (target_model_id, internal_name);


--
-- Name: commandcenter_extrafieldmodel commandcenter_extrafieldmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_extrafieldmodel
    ADD CONSTRAINT commandcenter_extrafieldmodel_pkey PRIMARY KEY (model_internal_name);


--
-- Name: commandcenter_extrafieldspec commandcenter_extrafieldspec_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_extrafieldspec
    ADD CONSTRAINT commandcenter_extrafieldspec_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_generalconfiguration commandcenter_generalconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_generalconfiguration
    ADD CONSTRAINT commandcenter_generalconfiguration_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_namecheapconfiguration commandcenter_namecheapconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_namecheapconfiguration
    ADD CONSTRAINT commandcenter_namecheapconfiguration_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_reportconfiguration commandcenter_reportconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_reportconfiguration
    ADD CONSTRAINT commandcenter_reportconfiguration_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_slackconfiguration commandcenter_slackconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_slackconfiguration
    ADD CONSTRAINT commandcenter_slackconfiguration_pkey PRIMARY KEY (id);


--
-- Name: commandcenter_virustotalconfiguration commandcenter_virustotalconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_virustotalconfiguration
    ADD CONSTRAINT commandcenter_virustotalconfiguration_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_q_ormq django_q_ormq_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_q_ormq
    ADD CONSTRAINT django_q_ormq_pkey PRIMARY KEY (id);


--
-- Name: django_q_schedule django_q_schedule_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_q_schedule
    ADD CONSTRAINT django_q_schedule_pkey PRIMARY KEY (id);


--
-- Name: django_q_task django_q_task_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_q_task
    ADD CONSTRAINT django_q_task_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: health_check_db_testmodel health_check_db_testmodel_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.health_check_db_testmodel
    ADD CONSTRAINT health_check_db_testmodel_pkey PRIMARY KEY (id);


--
-- Name: home_userprofile home_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_userprofile
    ADD CONSTRAINT home_userprofile_pkey PRIMARY KEY (id);


--
-- Name: home_userprofile home_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_userprofile
    ADD CONSTRAINT home_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: oplog_oplog oplog_oplog_name_project_id_cf3103ee_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oplog_oplog
    ADD CONSTRAINT oplog_oplog_name_project_id_cf3103ee_uniq UNIQUE (name, project_id);


--
-- Name: oplog_oplog oplog_oplog_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oplog_oplog
    ADD CONSTRAINT oplog_oplog_pkey PRIMARY KEY (id);


--
-- Name: oplog_oplogentry oplog_oplogentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oplog_oplogentry
    ADD CONSTRAINT oplog_oplogentry_pkey PRIMARY KEY (id);


--
-- Name: otp_static_staticdevice otp_static_staticdevice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_static_staticdevice
    ADD CONSTRAINT otp_static_staticdevice_pkey PRIMARY KEY (id);


--
-- Name: otp_static_statictoken otp_static_statictoken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_static_statictoken
    ADD CONSTRAINT otp_static_statictoken_pkey PRIMARY KEY (id);


--
-- Name: otp_totp_totpdevice otp_totp_totpdevice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_totp_totpdevice
    ADD CONSTRAINT otp_totp_totpdevice_pkey PRIMARY KEY (id);


--
-- Name: reporting_archive reporting_archive_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_archive
    ADD CONSTRAINT reporting_archive_pkey PRIMARY KEY (id);


--
-- Name: reporting_doctype reporting_doctype_doc_type_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_doctype
    ADD CONSTRAINT reporting_doctype_doc_type_key UNIQUE (doc_type);


--
-- Name: reporting_doctype reporting_doctype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_doctype
    ADD CONSTRAINT reporting_doctype_pkey PRIMARY KEY (id);


--
-- Name: reporting_evidence reporting_evidence_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_evidence
    ADD CONSTRAINT reporting_evidence_pkey PRIMARY KEY (id);


--
-- Name: reporting_finding reporting_finding_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_finding
    ADD CONSTRAINT reporting_finding_pkey PRIMARY KEY (id);


--
-- Name: reporting_findingnote reporting_findingnote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_findingnote
    ADD CONSTRAINT reporting_findingnote_pkey PRIMARY KEY (id);


--
-- Name: reporting_findingtype reporting_findingtype_finding_type_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_findingtype
    ADD CONSTRAINT reporting_findingtype_finding_type_key UNIQUE (finding_type);


--
-- Name: reporting_findingtype reporting_findingtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_findingtype
    ADD CONSTRAINT reporting_findingtype_pkey PRIMARY KEY (id);


--
-- Name: reporting_localfindingnote reporting_localfindingnote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_localfindingnote
    ADD CONSTRAINT reporting_localfindingnote_pkey PRIMARY KEY (id);


--
-- Name: reporting_observation reporting_observation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_observation
    ADD CONSTRAINT reporting_observation_pkey PRIMARY KEY (id);


--
-- Name: reporting_report reporting_report_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_report
    ADD CONSTRAINT reporting_report_pkey PRIMARY KEY (id);


--
-- Name: reporting_reportfindinglink reporting_reportfindinglink_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reportfindinglink
    ADD CONSTRAINT reporting_reportfindinglink_pkey PRIMARY KEY (id);


--
-- Name: reporting_reportobservationlink reporting_reportobservationlink_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reportobservationlink
    ADD CONSTRAINT reporting_reportobservationlink_pkey PRIMARY KEY (id);


--
-- Name: reporting_reporttemplate reporting_reporttemplate_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reporttemplate
    ADD CONSTRAINT reporting_reporttemplate_pkey PRIMARY KEY (id);


--
-- Name: reporting_severity reporting_severity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_severity
    ADD CONSTRAINT reporting_severity_pkey PRIMARY KEY (id);


--
-- Name: reporting_severity reporting_severity_severity_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_severity
    ADD CONSTRAINT reporting_severity_severity_key UNIQUE (severity);


--
-- Name: rest_framework_api_key_apikey rest_framework_api_key_apikey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_framework_api_key_apikey
    ADD CONSTRAINT rest_framework_api_key_apikey_pkey PRIMARY KEY (id);


--
-- Name: rest_framework_api_key_apikey rest_framework_api_key_apikey_prefix_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rest_framework_api_key_apikey
    ADD CONSTRAINT rest_framework_api_key_apikey_prefix_key UNIQUE (prefix);


--
-- Name: rolodex_client rolodex_client_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_client
    ADD CONSTRAINT rolodex_client_name_key UNIQUE (name);


--
-- Name: rolodex_client rolodex_client_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_client
    ADD CONSTRAINT rolodex_client_pkey PRIMARY KEY (id);


--
-- Name: rolodex_clientcontact rolodex_clientcontact_name_client_id_f6ee6e36_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientcontact
    ADD CONSTRAINT rolodex_clientcontact_name_client_id_f6ee6e36_uniq UNIQUE (name, client_id);


--
-- Name: rolodex_clientcontact rolodex_clientcontact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientcontact
    ADD CONSTRAINT rolodex_clientcontact_pkey PRIMARY KEY (id);


--
-- Name: rolodex_clientinvite rolodex_clientinvite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientinvite
    ADD CONSTRAINT rolodex_clientinvite_pkey PRIMARY KEY (id);


--
-- Name: rolodex_clientnote rolodex_clientnote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientnote
    ADD CONSTRAINT rolodex_clientnote_pkey PRIMARY KEY (id);


--
-- Name: rolodex_deconfliction rolodex_deconfliction_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_deconfliction
    ADD CONSTRAINT rolodex_deconfliction_pkey PRIMARY KEY (id);


--
-- Name: rolodex_deconflictionstatus rolodex_deconflictionstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_deconflictionstatus
    ADD CONSTRAINT rolodex_deconflictionstatus_pkey PRIMARY KEY (id);


--
-- Name: rolodex_deconflictionstatus rolodex_deconflictionstatus_status_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_deconflictionstatus
    ADD CONSTRAINT rolodex_deconflictionstatus_status_key UNIQUE (status);


--
-- Name: rolodex_objectivepriority rolodex_objectivepriority_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_objectivepriority
    ADD CONSTRAINT rolodex_objectivepriority_pkey PRIMARY KEY (id);


--
-- Name: rolodex_objectivepriority rolodex_objectivepriority_priority_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_objectivepriority
    ADD CONSTRAINT rolodex_objectivepriority_priority_key UNIQUE (priority);


--
-- Name: rolodex_objectivestatus rolodex_objectivestatus_objective_status_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_objectivestatus
    ADD CONSTRAINT rolodex_objectivestatus_objective_status_key UNIQUE (objective_status);


--
-- Name: rolodex_objectivestatus rolodex_objectivestatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_objectivestatus
    ADD CONSTRAINT rolodex_objectivestatus_pkey PRIMARY KEY (id);


--
-- Name: rolodex_project rolodex_project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_project
    ADD CONSTRAINT rolodex_project_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projectassignment rolodex_projectassignment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectassignment
    ADD CONSTRAINT rolodex_projectassignment_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projectcontact rolodex_projectcontact_name_project_id_bb480f62_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectcontact
    ADD CONSTRAINT rolodex_projectcontact_name_project_id_bb480f62_uniq UNIQUE (name, project_id);


--
-- Name: rolodex_projectcontact rolodex_projectcontact_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectcontact
    ADD CONSTRAINT rolodex_projectcontact_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projectinvite rolodex_projectinvite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectinvite
    ADD CONSTRAINT rolodex_projectinvite_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projectnote rolodex_projectnote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectnote
    ADD CONSTRAINT rolodex_projectnote_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projectobjective rolodex_projectobjective_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectobjective
    ADD CONSTRAINT rolodex_projectobjective_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projectrole rolodex_projectrole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectrole
    ADD CONSTRAINT rolodex_projectrole_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projectrole rolodex_projectrole_project_role_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectrole
    ADD CONSTRAINT rolodex_projectrole_project_role_key UNIQUE (project_role);


--
-- Name: rolodex_projectscope rolodex_projectscope_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectscope
    ADD CONSTRAINT rolodex_projectscope_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projectsubtask rolodex_projectsubtask_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectsubtask
    ADD CONSTRAINT rolodex_projectsubtask_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projecttarget rolodex_projecttarget_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projecttarget
    ADD CONSTRAINT rolodex_projecttarget_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projecttype rolodex_projecttype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projecttype
    ADD CONSTRAINT rolodex_projecttype_pkey PRIMARY KEY (id);


--
-- Name: rolodex_projecttype rolodex_projecttype_project_type_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projecttype
    ADD CONSTRAINT rolodex_projecttype_project_type_key UNIQUE (project_type);


--
-- Name: rolodex_whitecard rolodex_whitecard_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_whitecard
    ADD CONSTRAINT rolodex_whitecard_pkey PRIMARY KEY (id);


--
-- Name: shepherd_activitytype shepherd_activitytype_activity_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_activitytype
    ADD CONSTRAINT shepherd_activitytype_activity_key UNIQUE (activity);


--
-- Name: shepherd_activitytype shepherd_activitytype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_activitytype
    ADD CONSTRAINT shepherd_activitytype_pkey PRIMARY KEY (id);


--
-- Name: shepherd_auxserveraddress shepherd_auxserveraddress_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_auxserveraddress
    ADD CONSTRAINT shepherd_auxserveraddress_pkey PRIMARY KEY (id);


--
-- Name: shepherd_domain shepherd_domain_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domain
    ADD CONSTRAINT shepherd_domain_name_key UNIQUE (name);


--
-- Name: shepherd_domain shepherd_domain_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domain
    ADD CONSTRAINT shepherd_domain_pkey PRIMARY KEY (id);


--
-- Name: shepherd_domainnote shepherd_domainnote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainnote
    ADD CONSTRAINT shepherd_domainnote_pkey PRIMARY KEY (id);


--
-- Name: shepherd_domainserverconnection shepherd_domainserverconnection_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainserverconnection
    ADD CONSTRAINT shepherd_domainserverconnection_pkey PRIMARY KEY (id);


--
-- Name: shepherd_domainstatus shepherd_domainstatus_domain_status_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainstatus
    ADD CONSTRAINT shepherd_domainstatus_domain_status_key UNIQUE (domain_status);


--
-- Name: shepherd_domainstatus shepherd_domainstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainstatus
    ADD CONSTRAINT shepherd_domainstatus_pkey PRIMARY KEY (id);


--
-- Name: shepherd_healthstatus shepherd_healthstatus_health_status_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_healthstatus
    ADD CONSTRAINT shepherd_healthstatus_health_status_key UNIQUE (health_status);


--
-- Name: shepherd_healthstatus shepherd_healthstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_healthstatus
    ADD CONSTRAINT shepherd_healthstatus_pkey PRIMARY KEY (id);


--
-- Name: shepherd_history shepherd_history_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_history
    ADD CONSTRAINT shepherd_history_pkey PRIMARY KEY (id);


--
-- Name: shepherd_serverhistory shepherd_serverhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverhistory
    ADD CONSTRAINT shepherd_serverhistory_pkey PRIMARY KEY (id);


--
-- Name: shepherd_servernote shepherd_servernote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_servernote
    ADD CONSTRAINT shepherd_servernote_pkey PRIMARY KEY (id);


--
-- Name: shepherd_serverprovider shepherd_serverprovider_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverprovider
    ADD CONSTRAINT shepherd_serverprovider_pkey PRIMARY KEY (id);


--
-- Name: shepherd_serverprovider shepherd_serverprovider_server_provider_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverprovider
    ADD CONSTRAINT shepherd_serverprovider_server_provider_key UNIQUE (server_provider);


--
-- Name: shepherd_serverrole shepherd_serverrole_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverrole
    ADD CONSTRAINT shepherd_serverrole_pkey PRIMARY KEY (id);


--
-- Name: shepherd_serverrole shepherd_serverrole_server_role_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverrole
    ADD CONSTRAINT shepherd_serverrole_server_role_key UNIQUE (server_role);


--
-- Name: shepherd_serverstatus shepherd_serverstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverstatus
    ADD CONSTRAINT shepherd_serverstatus_pkey PRIMARY KEY (id);


--
-- Name: shepherd_serverstatus shepherd_serverstatus_server_status_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverstatus
    ADD CONSTRAINT shepherd_serverstatus_server_status_key UNIQUE (server_status);


--
-- Name: shepherd_staticserver shepherd_staticserver_ip_address_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_staticserver
    ADD CONSTRAINT shepherd_staticserver_ip_address_key UNIQUE (ip_address);


--
-- Name: shepherd_staticserver shepherd_staticserver_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_staticserver
    ADD CONSTRAINT shepherd_staticserver_pkey PRIMARY KEY (id);


--
-- Name: shepherd_transientserver shepherd_transientserver_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_transientserver
    ADD CONSTRAINT shepherd_transientserver_pkey PRIMARY KEY (id);


--
-- Name: shepherd_whoisstatus shepherd_whoisstatus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_whoisstatus
    ADD CONSTRAINT shepherd_whoisstatus_pkey PRIMARY KEY (id);


--
-- Name: shepherd_whoisstatus shepherd_whoisstatus_whois_status_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_whoisstatus
    ADD CONSTRAINT shepherd_whoisstatus_whois_status_key UNIQUE (whois_status);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_provider_uid_fc810c6e_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_provider_uid_fc810c6e_uniq UNIQUE (provider, uid);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp__socialapp_id_site_id_71a9a768_uniq UNIQUE (socialapp_id, site_id);


--
-- Name: socialaccount_socialapp socialaccount_socialapp_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp
    ADD CONSTRAINT socialaccount_socialapp_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialapp_sites socialaccount_socialapp_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_socialapp_sites_pkey PRIMARY KEY (id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_app_id_account_id_fca4e0ac_uniq UNIQUE (app_id, account_id);


--
-- Name: socialaccount_socialtoken socialaccount_socialtoken_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_socialtoken_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag taggit_tag_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_name_key UNIQUE (name);


--
-- Name: taggit_tag taggit_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_pkey PRIMARY KEY (id);


--
-- Name: taggit_tag taggit_tag_slug_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taggit_tag
    ADD CONSTRAINT taggit_tag_slug_key UNIQUE (slug);


--
-- Name: taggit_taggeditem taggit_taggeditem_content_type_id_object_id_tag_id_4bb97a8e_uni; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_content_type_id_object_id_tag_id_4bb97a8e_uni UNIQUE (content_type_id, object_id, tag_id);


--
-- Name: taggit_taggeditem taggit_taggeditem_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_pkey PRIMARY KEY (id);


--
-- Name: users_user_groups users_user_groups_user_id_group_id_b88eab82_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_group_id_b88eab82_uniq UNIQUE (user_id, group_id);


--
-- Name: users_user users_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_permission_id_43338c45_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_permission_id_43338c45_uniq UNIQUE (user_id, permission_id);


--
-- Name: users_user users_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user
    ADD CONSTRAINT users_user_username_key UNIQUE (username);


--
-- Name: event_invocation_logs_event_id_idx; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE INDEX event_invocation_logs_event_id_idx ON hdb_catalog.event_invocation_logs USING btree (event_id);


--
-- Name: event_log_fetch_events; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE INDEX event_log_fetch_events ON hdb_catalog.event_log USING btree (locked NULLS FIRST, next_retry_at NULLS FIRST, created_at) WHERE ((delivered = false) AND (error = false) AND (archived = false));


--
-- Name: event_log_trigger_name_idx; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE INDEX event_log_trigger_name_idx ON hdb_catalog.event_log USING btree (trigger_name);


--
-- Name: hdb_cron_event_invocation_event_id; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE INDEX hdb_cron_event_invocation_event_id ON hdb_catalog.hdb_cron_event_invocation_logs USING btree (event_id);


--
-- Name: hdb_cron_event_status; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE INDEX hdb_cron_event_status ON hdb_catalog.hdb_cron_events USING btree (status);


--
-- Name: hdb_cron_events_unique_scheduled; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE UNIQUE INDEX hdb_cron_events_unique_scheduled ON hdb_catalog.hdb_cron_events USING btree (trigger_name, scheduled_time) WHERE (status = 'scheduled'::text);


--
-- Name: hdb_scheduled_event_status; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE INDEX hdb_scheduled_event_status ON hdb_catalog.hdb_scheduled_events USING btree (status);


--
-- Name: hdb_source_catalog_version_one_row; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE UNIQUE INDEX hdb_source_catalog_version_one_row ON hdb_catalog.hdb_source_catalog_version USING btree (((version IS NOT NULL)));


--
-- Name: hdb_version_one_row; Type: INDEX; Schema: hdb_catalog; Owner: postgres
--

CREATE UNIQUE INDEX hdb_version_one_row ON hdb_catalog.hdb_version USING btree (((version IS NOT NULL)));


--
-- Name: account_emailaddress_email_03be32b2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailaddress_email_03be32b2 ON public.account_emailaddress USING btree (email);


--
-- Name: account_emailaddress_email_03be32b2_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailaddress_email_03be32b2_like ON public.account_emailaddress USING btree (email varchar_pattern_ops);


--
-- Name: account_emailaddress_user_id_2c513194; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailaddress_user_id_2c513194 ON public.account_emailaddress USING btree (user_id);


--
-- Name: account_emailconfirmation_email_address_id_5b7f8c58; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailconfirmation_email_address_id_5b7f8c58 ON public.account_emailconfirmation USING btree (email_address_id);


--
-- Name: account_emailconfirmation_key_f43612bd_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX account_emailconfirmation_key_f43612bd_like ON public.account_emailconfirmation USING btree (key varchar_pattern_ops);


--
-- Name: api_apikey_created_9c07f10e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_apikey_created_9c07f10e ON public.api_apikey USING btree (created);


--
-- Name: api_apikey_user_id_7ebe0e24; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX api_apikey_user_id_7ebe0e24 ON public.api_apikey USING btree (user_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: commandcenter_extrafieldmodel_model_internal_name_89263132_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX commandcenter_extrafieldmodel_model_internal_name_89263132_like ON public.commandcenter_extrafieldmodel USING btree (model_internal_name varchar_pattern_ops);


--
-- Name: commandcenter_extrafieldspec_target_model_id_9542c716; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX commandcenter_extrafieldspec_target_model_id_9542c716 ON public.commandcenter_extrafieldspec USING btree (target_model_id);


--
-- Name: commandcenter_extrafieldspec_target_model_id_9542c716_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX commandcenter_extrafieldspec_target_model_id_9542c716_like ON public.commandcenter_extrafieldspec USING btree (target_model_id varchar_pattern_ops);


--
-- Name: commandcenter_reportconfig_default_docx_template_id_f383cbd0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX commandcenter_reportconfig_default_docx_template_id_f383cbd0 ON public.commandcenter_reportconfiguration USING btree (default_docx_template_id);


--
-- Name: commandcenter_reportconfig_default_pptx_template_id_9fc0d6e9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX commandcenter_reportconfig_default_pptx_template_id_9fc0d6e9 ON public.commandcenter_reportconfiguration USING btree (default_pptx_template_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_q_task_id_32882367_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_q_task_id_32882367_like ON public.django_q_task USING btree (id varchar_pattern_ops);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: oplog_oplog_oplog_i_0e03f5_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oplog_oplog_oplog_i_0e03f5_idx ON public.oplog_oplogentry USING btree (oplog_id_id, entry_identifier);


--
-- Name: oplog_oplog_project_id_fe4a93f0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oplog_oplog_project_id_fe4a93f0 ON public.oplog_oplog USING btree (project_id);


--
-- Name: oplog_oplogentry_oplog_id_id_18ef13d0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX oplog_oplogentry_oplog_id_id_18ef13d0 ON public.oplog_oplogentry USING btree (oplog_id_id);


--
-- Name: otp_static_staticdevice_user_id_7f9cff2b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX otp_static_staticdevice_user_id_7f9cff2b ON public.otp_static_staticdevice USING btree (user_id);


--
-- Name: otp_static_statictoken_device_id_74b7c7d1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX otp_static_statictoken_device_id_74b7c7d1 ON public.otp_static_statictoken USING btree (device_id);


--
-- Name: otp_static_statictoken_token_d0a51866; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX otp_static_statictoken_token_d0a51866 ON public.otp_static_statictoken USING btree (token);


--
-- Name: otp_static_statictoken_token_d0a51866_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX otp_static_statictoken_token_d0a51866_like ON public.otp_static_statictoken USING btree (token varchar_pattern_ops);


--
-- Name: otp_totp_totpdevice_user_id_0fb18292; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX otp_totp_totpdevice_user_id_0fb18292 ON public.otp_totp_totpdevice USING btree (user_id);


--
-- Name: reporting_archive_project_id_e00a60e1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_archive_project_id_e00a60e1 ON public.reporting_archive USING btree (project_id);


--
-- Name: reporting_doctype_doc_type_4f8902f4_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_doctype_doc_type_4f8902f4_like ON public.reporting_doctype USING btree (doc_type varchar_pattern_ops);


--
-- Name: reporting_evidence_finding_id_00138d5b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_evidence_finding_id_00138d5b ON public.reporting_evidence USING btree (finding_id);


--
-- Name: reporting_evidence_report_id_e9637ec2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_evidence_report_id_e9637ec2 ON public.reporting_evidence USING btree (report_id);


--
-- Name: reporting_evidence_uploaded_by_id_71b7b76f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_evidence_uploaded_by_id_71b7b76f ON public.reporting_evidence USING btree (uploaded_by_id);


--
-- Name: reporting_finding_finding_type_id_576232af; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_finding_finding_type_id_576232af ON public.reporting_finding USING btree (finding_type_id);


--
-- Name: reporting_finding_severity_id_c4aea0a2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_finding_severity_id_c4aea0a2 ON public.reporting_finding USING btree (severity_id);


--
-- Name: reporting_findingnote_finding_id_e9bb21d2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_findingnote_finding_id_e9bb21d2 ON public.reporting_findingnote USING btree (finding_id);


--
-- Name: reporting_findingnote_operator_id_ec6a14fc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_findingnote_operator_id_ec6a14fc ON public.reporting_findingnote USING btree (operator_id);


--
-- Name: reporting_findingtype_finding_type_b1ff95e7_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_findingtype_finding_type_b1ff95e7_like ON public.reporting_findingtype USING btree (finding_type varchar_pattern_ops);


--
-- Name: reporting_localfindingnote_finding_id_667858fe; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_localfindingnote_finding_id_667858fe ON public.reporting_localfindingnote USING btree (finding_id);


--
-- Name: reporting_localfindingnote_operator_id_ccc74743; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_localfindingnote_operator_id_ccc74743 ON public.reporting_localfindingnote USING btree (operator_id);


--
-- Name: reporting_report_created_by_id_1c6d7e8d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_report_created_by_id_1c6d7e8d ON public.reporting_report USING btree (created_by_id);


--
-- Name: reporting_report_docx_template_id_f9bf3a47; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_report_docx_template_id_f9bf3a47 ON public.reporting_report USING btree (docx_template_id);


--
-- Name: reporting_report_pptx_template_id_b818b902; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_report_pptx_template_id_b818b902 ON public.reporting_report USING btree (pptx_template_id);


--
-- Name: reporting_report_project_id_8d586862; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_report_project_id_8d586862 ON public.reporting_report USING btree (project_id);


--
-- Name: reporting_reportfindinglink_assigned_to_id_586a64f4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reportfindinglink_assigned_to_id_586a64f4 ON public.reporting_reportfindinglink USING btree (assigned_to_id);


--
-- Name: reporting_reportfindinglink_finding_type_id_b165acad; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reportfindinglink_finding_type_id_b165acad ON public.reporting_reportfindinglink USING btree (finding_type_id);


--
-- Name: reporting_reportfindinglink_report_id_173cdfe4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reportfindinglink_report_id_173cdfe4 ON public.reporting_reportfindinglink USING btree (report_id);


--
-- Name: reporting_reportfindinglink_severity_id_ed92c09e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reportfindinglink_severity_id_ed92c09e ON public.reporting_reportfindinglink USING btree (severity_id);


--
-- Name: reporting_reportobservationlink_assigned_to_id_a155d68d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reportobservationlink_assigned_to_id_a155d68d ON public.reporting_reportobservationlink USING btree (assigned_to_id);


--
-- Name: reporting_reportobservationlink_report_id_bf40bf64; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reportobservationlink_report_id_bf40bf64 ON public.reporting_reportobservationlink USING btree (report_id);


--
-- Name: reporting_reporttemplate_client_id_119d84a5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reporttemplate_client_id_119d84a5 ON public.reporting_reporttemplate USING btree (client_id);


--
-- Name: reporting_reporttemplate_doc_type_id_6e8237de; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reporttemplate_doc_type_id_6e8237de ON public.reporting_reporttemplate USING btree (doc_type_id);


--
-- Name: reporting_reporttemplate_uploaded_by_id_03b1497c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_reporttemplate_uploaded_by_id_03b1497c ON public.reporting_reporttemplate USING btree (uploaded_by_id);


--
-- Name: reporting_severity_severity_22f33466_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX reporting_severity_severity_22f33466_like ON public.reporting_severity USING btree (severity varchar_pattern_ops);


--
-- Name: rest_framework_api_key_apikey_created_c61872d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_framework_api_key_apikey_created_c61872d9 ON public.rest_framework_api_key_apikey USING btree (created);


--
-- Name: rest_framework_api_key_apikey_id_6e07e68e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_framework_api_key_apikey_id_6e07e68e_like ON public.rest_framework_api_key_apikey USING btree (id varchar_pattern_ops);


--
-- Name: rest_framework_api_key_apikey_prefix_4e0db5f8_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rest_framework_api_key_apikey_prefix_4e0db5f8_like ON public.rest_framework_api_key_apikey USING btree (prefix varchar_pattern_ops);


--
-- Name: rolodex_client_name_98e55485_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_client_name_98e55485_like ON public.rolodex_client USING btree (name varchar_pattern_ops);


--
-- Name: rolodex_clientcontact_client_id_48f1bd5e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_clientcontact_client_id_48f1bd5e ON public.rolodex_clientcontact USING btree (client_id);


--
-- Name: rolodex_clientinvite_client_id_5d0aef60; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_clientinvite_client_id_5d0aef60 ON public.rolodex_clientinvite USING btree (client_id);


--
-- Name: rolodex_clientinvite_user_id_7ca0ba49; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_clientinvite_user_id_7ca0ba49 ON public.rolodex_clientinvite USING btree (user_id);


--
-- Name: rolodex_clientnote_client_id_c2ca9488; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_clientnote_client_id_c2ca9488 ON public.rolodex_clientnote USING btree (client_id);


--
-- Name: rolodex_clientnote_operator_id_739d4005; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_clientnote_operator_id_739d4005 ON public.rolodex_clientnote USING btree (operator_id);


--
-- Name: rolodex_deconfliction_project_id_be3e6403; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_deconfliction_project_id_be3e6403 ON public.rolodex_deconfliction USING btree (project_id);


--
-- Name: rolodex_deconfliction_status_id_a282790f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_deconfliction_status_id_a282790f ON public.rolodex_deconfliction USING btree (status_id);


--
-- Name: rolodex_deconflictionstatus_status_3e3caae3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_deconflictionstatus_status_3e3caae3_like ON public.rolodex_deconflictionstatus USING btree (status varchar_pattern_ops);


--
-- Name: rolodex_objectivepriority_priority_b62df365_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_objectivepriority_priority_b62df365_like ON public.rolodex_objectivepriority USING btree (priority varchar_pattern_ops);


--
-- Name: rolodex_objectivestatus_objective_status_788992bb_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_objectivestatus_objective_status_788992bb_like ON public.rolodex_objectivestatus USING btree (objective_status varchar_pattern_ops);


--
-- Name: rolodex_project_client_id_ebd2cbf5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_project_client_id_ebd2cbf5 ON public.rolodex_project USING btree (client_id);


--
-- Name: rolodex_project_operator_id_9e407adf; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_project_operator_id_9e407adf ON public.rolodex_project USING btree (operator_id);


--
-- Name: rolodex_project_project_type_id_07953f1d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_project_project_type_id_07953f1d ON public.rolodex_project USING btree (project_type_id);


--
-- Name: rolodex_projectassignment_operator_id_c4c462d8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectassignment_operator_id_c4c462d8 ON public.rolodex_projectassignment USING btree (operator_id);


--
-- Name: rolodex_projectassignment_project_id_ce701acc; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectassignment_project_id_ce701acc ON public.rolodex_projectassignment USING btree (project_id);


--
-- Name: rolodex_projectassignment_role_id_cbab79b0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectassignment_role_id_cbab79b0 ON public.rolodex_projectassignment USING btree (role_id);


--
-- Name: rolodex_projectcontact_project_id_f7320727; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectcontact_project_id_f7320727 ON public.rolodex_projectcontact USING btree (project_id);


--
-- Name: rolodex_projectinvite_project_id_d510b642; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectinvite_project_id_d510b642 ON public.rolodex_projectinvite USING btree (project_id);


--
-- Name: rolodex_projectinvite_user_id_13704bd9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectinvite_user_id_13704bd9 ON public.rolodex_projectinvite USING btree (user_id);


--
-- Name: rolodex_projectnote_operator_id_5b9299b1; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectnote_operator_id_5b9299b1 ON public.rolodex_projectnote USING btree (operator_id);


--
-- Name: rolodex_projectnote_project_id_79acb8a5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectnote_project_id_79acb8a5 ON public.rolodex_projectnote USING btree (project_id);


--
-- Name: rolodex_projectobjective_priority_id_cf6de852; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectobjective_priority_id_cf6de852 ON public.rolodex_projectobjective USING btree (priority_id);


--
-- Name: rolodex_projectobjective_project_id_62b27a4b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectobjective_project_id_62b27a4b ON public.rolodex_projectobjective USING btree (project_id);


--
-- Name: rolodex_projectobjective_status_id_98de9086; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectobjective_status_id_98de9086 ON public.rolodex_projectobjective USING btree (status_id);


--
-- Name: rolodex_projectrole_project_role_4166a92d_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectrole_project_role_4166a92d_like ON public.rolodex_projectrole USING btree (project_role varchar_pattern_ops);


--
-- Name: rolodex_projectscope_project_id_dcf53f05; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectscope_project_id_dcf53f05 ON public.rolodex_projectscope USING btree (project_id);


--
-- Name: rolodex_projectsubtask_parent_id_63a99f77; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectsubtask_parent_id_63a99f77 ON public.rolodex_projectsubtask USING btree (parent_id);


--
-- Name: rolodex_projectsubtask_status_id_c5e132c9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projectsubtask_status_id_c5e132c9 ON public.rolodex_projectsubtask USING btree (status_id);


--
-- Name: rolodex_projecttarget_project_id_69dd3e2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projecttarget_project_id_69dd3e2f ON public.rolodex_projecttarget USING btree (project_id);


--
-- Name: rolodex_projecttype_project_type_d0196b5d_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_projecttype_project_type_d0196b5d_like ON public.rolodex_projecttype USING btree (project_type varchar_pattern_ops);


--
-- Name: rolodex_whitecard_project_id_772a701c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX rolodex_whitecard_project_id_772a701c ON public.rolodex_whitecard USING btree (project_id);


--
-- Name: shepherd_activitytype_activity_63101d2c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_activitytype_activity_63101d2c_like ON public.shepherd_activitytype USING btree (activity varchar_pattern_ops);


--
-- Name: shepherd_auxserveraddress_static_server_id_5112503d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_auxserveraddress_static_server_id_5112503d ON public.shepherd_auxserveraddress USING btree (static_server_id);


--
-- Name: shepherd_domain_domain_status_id_a2fa7330; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domain_domain_status_id_a2fa7330 ON public.shepherd_domain USING btree (domain_status_id);


--
-- Name: shepherd_domain_health_status_id_cebe65d3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domain_health_status_id_cebe65d3 ON public.shepherd_domain USING btree (health_status_id);


--
-- Name: shepherd_domain_last_used_by_id_119db0c5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domain_last_used_by_id_119db0c5 ON public.shepherd_domain USING btree (last_used_by_id);


--
-- Name: shepherd_domain_name_41096be4_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domain_name_41096be4_like ON public.shepherd_domain USING btree (name varchar_pattern_ops);


--
-- Name: shepherd_domain_whois_status_id_a0721cb6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domain_whois_status_id_a0721cb6 ON public.shepherd_domain USING btree (whois_status_id);


--
-- Name: shepherd_domainnote_domain_id_9e6a4961; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domainnote_domain_id_9e6a4961 ON public.shepherd_domainnote USING btree (domain_id);


--
-- Name: shepherd_domainnote_operator_id_040fcb51; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domainnote_operator_id_040fcb51 ON public.shepherd_domainnote USING btree (operator_id);


--
-- Name: shepherd_domainserverconnection_domain_id_398e22e4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domainserverconnection_domain_id_398e22e4 ON public.shepherd_domainserverconnection USING btree (domain_id);


--
-- Name: shepherd_domainserverconnection_project_id_35af0efe; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domainserverconnection_project_id_35af0efe ON public.shepherd_domainserverconnection USING btree (project_id);


--
-- Name: shepherd_domainserverconnection_static_server_id_2ab6ed26; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domainserverconnection_static_server_id_2ab6ed26 ON public.shepherd_domainserverconnection USING btree (static_server_id);


--
-- Name: shepherd_domainserverconnection_transient_server_id_48f0ff5a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domainserverconnection_transient_server_id_48f0ff5a ON public.shepherd_domainserverconnection USING btree (transient_server_id);


--
-- Name: shepherd_domainstatus_domain_status_5c10b8e9_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_domainstatus_domain_status_5c10b8e9_like ON public.shepherd_domainstatus USING btree (domain_status varchar_pattern_ops);


--
-- Name: shepherd_healthstatus_health_status_17241bb6_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_healthstatus_health_status_17241bb6_like ON public.shepherd_healthstatus USING btree (health_status varchar_pattern_ops);


--
-- Name: shepherd_history_activity_type_id_a2669c34; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_history_activity_type_id_a2669c34 ON public.shepherd_history USING btree (activity_type_id);


--
-- Name: shepherd_history_client_id_89d8cfd3; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_history_client_id_89d8cfd3 ON public.shepherd_history USING btree (client_id);


--
-- Name: shepherd_history_domain_id_5ac2c2ca; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_history_domain_id_5ac2c2ca ON public.shepherd_history USING btree (domain_id);


--
-- Name: shepherd_history_operator_id_0acb0189; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_history_operator_id_0acb0189 ON public.shepherd_history USING btree (operator_id);


--
-- Name: shepherd_history_project_id_1fe0dabb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_history_project_id_1fe0dabb ON public.shepherd_history USING btree (project_id);


--
-- Name: shepherd_serverhistory_activity_type_id_b8698fb0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverhistory_activity_type_id_b8698fb0 ON public.shepherd_serverhistory USING btree (activity_type_id);


--
-- Name: shepherd_serverhistory_client_id_132ff5c2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverhistory_client_id_132ff5c2 ON public.shepherd_serverhistory USING btree (client_id);


--
-- Name: shepherd_serverhistory_operator_id_34e8e348; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverhistory_operator_id_34e8e348 ON public.shepherd_serverhistory USING btree (operator_id);


--
-- Name: shepherd_serverhistory_project_id_1c40d316; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverhistory_project_id_1c40d316 ON public.shepherd_serverhistory USING btree (project_id);


--
-- Name: shepherd_serverhistory_server_id_cd484fac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverhistory_server_id_cd484fac ON public.shepherd_serverhistory USING btree (server_id);


--
-- Name: shepherd_serverhistory_server_role_id_d6b6cc81; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverhistory_server_role_id_d6b6cc81 ON public.shepherd_serverhistory USING btree (server_role_id);


--
-- Name: shepherd_servernote_operator_id_0645b3ab; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_servernote_operator_id_0645b3ab ON public.shepherd_servernote USING btree (operator_id);


--
-- Name: shepherd_servernote_server_id_30ba51f2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_servernote_server_id_30ba51f2 ON public.shepherd_servernote USING btree (server_id);


--
-- Name: shepherd_serverprovider_server_provider_b5fbd433_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverprovider_server_provider_b5fbd433_like ON public.shepherd_serverprovider USING btree (server_provider varchar_pattern_ops);


--
-- Name: shepherd_serverrole_server_role_083b015e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverrole_server_role_083b015e_like ON public.shepherd_serverrole USING btree (server_role varchar_pattern_ops);


--
-- Name: shepherd_serverstatus_server_status_f5001f85_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_serverstatus_server_status_f5001f85_like ON public.shepherd_serverstatus USING btree (server_status varchar_pattern_ops);


--
-- Name: shepherd_staticserver_last_used_by_id_442a30d9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_staticserver_last_used_by_id_442a30d9 ON public.shepherd_staticserver USING btree (last_used_by_id);


--
-- Name: shepherd_staticserver_server_provider_id_11a19799; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_staticserver_server_provider_id_11a19799 ON public.shepherd_staticserver USING btree (server_provider_id);


--
-- Name: shepherd_staticserver_server_status_id_d41f1ab4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_staticserver_server_status_id_d41f1ab4 ON public.shepherd_staticserver USING btree (server_status_id);


--
-- Name: shepherd_transientserver_activity_type_id_97b100c2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_transientserver_activity_type_id_97b100c2 ON public.shepherd_transientserver USING btree (activity_type_id);


--
-- Name: shepherd_transientserver_operator_id_d2301a78; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_transientserver_operator_id_d2301a78 ON public.shepherd_transientserver USING btree (operator_id);


--
-- Name: shepherd_transientserver_project_id_f0e29dd2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_transientserver_project_id_f0e29dd2 ON public.shepherd_transientserver USING btree (project_id);


--
-- Name: shepherd_transientserver_server_provider_id_e89609a9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_transientserver_server_provider_id_e89609a9 ON public.shepherd_transientserver USING btree (server_provider_id);


--
-- Name: shepherd_transientserver_server_role_id_7e24d482; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_transientserver_server_role_id_7e24d482 ON public.shepherd_transientserver USING btree (server_role_id);


--
-- Name: shepherd_whoisstatus_whois_status_10b8b42e_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX shepherd_whoisstatus_whois_status_10b8b42e_like ON public.shepherd_whoisstatus USING btree (whois_status varchar_pattern_ops);


--
-- Name: socialaccount_socialaccount_user_id_8146e70c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialaccount_user_id_8146e70c ON public.socialaccount_socialaccount USING btree (user_id);


--
-- Name: socialaccount_socialapp_sites_site_id_2579dee5; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialapp_sites_site_id_2579dee5 ON public.socialaccount_socialapp_sites USING btree (site_id);


--
-- Name: socialaccount_socialapp_sites_socialapp_id_97fb6e7d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialapp_sites_socialapp_id_97fb6e7d ON public.socialaccount_socialapp_sites USING btree (socialapp_id);


--
-- Name: socialaccount_socialtoken_account_id_951f210e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialtoken_account_id_951f210e ON public.socialaccount_socialtoken USING btree (account_id);


--
-- Name: socialaccount_socialtoken_app_id_636a42d7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX socialaccount_socialtoken_app_id_636a42d7 ON public.socialaccount_socialtoken USING btree (app_id);


--
-- Name: success_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX success_index ON public.django_q_task USING btree ("group", name, func) WHERE success;


--
-- Name: taggit_tag_name_58eb2ed9_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX taggit_tag_name_58eb2ed9_like ON public.taggit_tag USING btree (name varchar_pattern_ops);


--
-- Name: taggit_tag_slug_6be58b2c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX taggit_tag_slug_6be58b2c_like ON public.taggit_tag USING btree (slug varchar_pattern_ops);


--
-- Name: taggit_tagg_content_8fc721_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX taggit_tagg_content_8fc721_idx ON public.taggit_taggeditem USING btree (content_type_id, object_id);


--
-- Name: taggit_taggeditem_content_type_id_9957a03c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX taggit_taggeditem_content_type_id_9957a03c ON public.taggit_taggeditem USING btree (content_type_id);


--
-- Name: taggit_taggeditem_object_id_e2d7d1df; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX taggit_taggeditem_object_id_e2d7d1df ON public.taggit_taggeditem USING btree (object_id);


--
-- Name: taggit_taggeditem_tag_id_f4f5b767; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX taggit_taggeditem_tag_id_f4f5b767 ON public.taggit_taggeditem USING btree (tag_id);


--
-- Name: unique_primary_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_primary_email ON public.account_emailaddress USING btree (user_id, "primary") WHERE "primary";


--
-- Name: unique_verified_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX unique_verified_email ON public.account_emailaddress USING btree (email) WHERE verified;


--
-- Name: users_user_groups_group_id_9afc8d0e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_groups_group_id_9afc8d0e ON public.users_user_groups USING btree (group_id);


--
-- Name: users_user_groups_user_id_5f6f5a90; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_groups_user_id_5f6f5a90 ON public.users_user_groups USING btree (user_id);


--
-- Name: users_user_user_permissions_permission_id_0b93982e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_user_permissions_permission_id_0b93982e ON public.users_user_user_permissions USING btree (permission_id);


--
-- Name: users_user_user_permissions_user_id_20aca447; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_user_permissions_user_id_20aca447 ON public.users_user_user_permissions USING btree (user_id);


--
-- Name: users_user_username_06e46fe6_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX users_user_username_06e46fe6_like ON public.users_user USING btree (username varchar_pattern_ops);


--
-- Name: rolodex_client check_timezone_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER check_timezone_trigger BEFORE INSERT OR UPDATE ON public.rolodex_client FOR EACH ROW EXECUTE FUNCTION public.is_timezone();


--
-- Name: rolodex_clientcontact check_timezone_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER check_timezone_trigger BEFORE INSERT OR UPDATE ON public.rolodex_clientcontact FOR EACH ROW EXECUTE FUNCTION public.is_timezone();


--
-- Name: rolodex_project check_timezone_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER check_timezone_trigger BEFORE INSERT OR UPDATE ON public.rolodex_project FOR EACH ROW EXECUTE FUNCTION public.is_timezone();


--
-- Name: rolodex_projectcontact check_timezone_trigger; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER check_timezone_trigger BEFORE INSERT OR UPDATE ON public.rolodex_projectcontact FOR EACH ROW EXECUTE FUNCTION public.is_timezone();


--
-- Name: shepherd_domain notify_hasura_CleanDomainName_INSERT; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_CleanDomainName_INSERT" AFTER INSERT ON public.shepherd_domain FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_CleanDomainName_INSERT"();


--
-- Name: shepherd_domain notify_hasura_CleanDomainName_UPDATE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_CleanDomainName_UPDATE" AFTER UPDATE ON public.shepherd_domain FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_CleanDomainName_UPDATE"();


--
-- Name: oplog_oplogentry notify_hasura_CreateOplogEntry_INSERT; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_CreateOplogEntry_INSERT" AFTER INSERT ON public.oplog_oplogentry FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_CreateOplogEntry_INSERT"();


--
-- Name: reporting_reportfindinglink notify_hasura_CreateReportFinding_INSERT; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_CreateReportFinding_INSERT" AFTER INSERT ON public.reporting_reportfindinglink FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_CreateReportFinding_INSERT"();


--
-- Name: reporting_reportfindinglink notify_hasura_CreateReportFinding_UPDATE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_CreateReportFinding_UPDATE" AFTER UPDATE ON public.reporting_reportfindinglink FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_CreateReportFinding_UPDATE"();


--
-- Name: oplog_oplogentry notify_hasura_DeleteOplogEntry_DELETE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_DeleteOplogEntry_DELETE" AFTER DELETE ON public.oplog_oplogentry FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_DeleteOplogEntry_DELETE"();


--
-- Name: reporting_reportfindinglink notify_hasura_DeleteReportFinding_DELETE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_DeleteReportFinding_DELETE" AFTER DELETE ON public.reporting_reportfindinglink FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_DeleteReportFinding_DELETE"();


--
-- Name: reporting_evidence notify_hasura_EvidenceUpdate_DELETE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_EvidenceUpdate_DELETE" AFTER DELETE ON public.reporting_evidence FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_EvidenceUpdate_DELETE"();


--
-- Name: reporting_evidence notify_hasura_EvidenceUpdate_UPDATE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_EvidenceUpdate_UPDATE" AFTER UPDATE ON public.reporting_evidence FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_EvidenceUpdate_UPDATE"();


--
-- Name: oplog_oplogentry notify_hasura_UpdateOplogEntry_UPDATE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_UpdateOplogEntry_UPDATE" AFTER UPDATE ON public.oplog_oplogentry FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_UpdateOplogEntry_UPDATE"();


--
-- Name: rolodex_projectcontact notify_hasura_UpdateProjectContact_INSERT; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_UpdateProjectContact_INSERT" AFTER INSERT ON public.rolodex_projectcontact FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_UpdateProjectContact_INSERT"();


--
-- Name: rolodex_projectcontact notify_hasura_UpdateProjectContact_UPDATE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_UpdateProjectContact_UPDATE" AFTER UPDATE ON public.rolodex_projectcontact FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_UpdateProjectContact_UPDATE"();


--
-- Name: rolodex_projectobjective notify_hasura_UpdateProjectObjective_INSERT; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_UpdateProjectObjective_INSERT" AFTER INSERT ON public.rolodex_projectobjective FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_UpdateProjectObjective_INSERT"();


--
-- Name: rolodex_projectobjective notify_hasura_UpdateProjectObjective_UPDATE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_UpdateProjectObjective_UPDATE" AFTER UPDATE ON public.rolodex_projectobjective FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_UpdateProjectObjective_UPDATE"();


--
-- Name: rolodex_projectsubtask notify_hasura_UpdateProjectSubTask_INSERT; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_UpdateProjectSubTask_INSERT" AFTER INSERT ON public.rolodex_projectsubtask FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_UpdateProjectSubTask_INSERT"();


--
-- Name: rolodex_projectsubtask notify_hasura_UpdateProjectSubTask_UPDATE; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER "notify_hasura_UpdateProjectSubTask_UPDATE" AFTER UPDATE ON public.rolodex_projectsubtask FOR EACH ROW EXECUTE FUNCTION hdb_catalog."notify_hasura_UpdateProjectSubTask_UPDATE"();


--
-- Name: hdb_cron_event_invocation_logs hdb_cron_event_invocation_logs_event_id_fkey; Type: FK CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_cron_event_invocation_logs
    ADD CONSTRAINT hdb_cron_event_invocation_logs_event_id_fkey FOREIGN KEY (event_id) REFERENCES hdb_catalog.hdb_cron_events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: hdb_scheduled_event_invocation_logs hdb_scheduled_event_invocation_logs_event_id_fkey; Type: FK CONSTRAINT; Schema: hdb_catalog; Owner: postgres
--

ALTER TABLE ONLY hdb_catalog.hdb_scheduled_event_invocation_logs
    ADD CONSTRAINT hdb_scheduled_event_invocation_logs_event_id_fkey FOREIGN KEY (event_id) REFERENCES hdb_catalog.hdb_scheduled_events(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: account_emailaddress account_emailaddress_user_id_2c513194_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailaddress
    ADD CONSTRAINT account_emailaddress_user_id_2c513194_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: account_emailconfirmation account_emailconfirm_email_address_id_5b7f8c58_fk_account_e; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.account_emailconfirmation
    ADD CONSTRAINT account_emailconfirm_email_address_id_5b7f8c58_fk_account_e FOREIGN KEY (email_address_id) REFERENCES public.account_emailaddress(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: api_apikey api_apikey_user_id_7ebe0e24_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.api_apikey
    ADD CONSTRAINT api_apikey_user_id_7ebe0e24_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: commandcenter_extrafieldspec commandcenter_extraf_target_model_id_9542c716_fk_commandce; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_extrafieldspec
    ADD CONSTRAINT commandcenter_extraf_target_model_id_9542c716_fk_commandce FOREIGN KEY (target_model_id) REFERENCES public.commandcenter_extrafieldmodel(model_internal_name) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: commandcenter_reportconfiguration commandcenter_report_default_docx_templat_f383cbd0_fk_reporting; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_reportconfiguration
    ADD CONSTRAINT commandcenter_report_default_docx_templat_f383cbd0_fk_reporting FOREIGN KEY (default_docx_template_id) REFERENCES public.reporting_reporttemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: commandcenter_reportconfiguration commandcenter_report_default_pptx_templat_9fc0d6e9_fk_reporting; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.commandcenter_reportconfiguration
    ADD CONSTRAINT commandcenter_report_default_pptx_templat_9fc0d6e9_fk_reporting FOREIGN KEY (default_pptx_template_id) REFERENCES public.reporting_reporttemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: home_userprofile home_userprofile_user_id_d1f7b466_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.home_userprofile
    ADD CONSTRAINT home_userprofile_user_id_d1f7b466_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oplog_oplog oplog_oplog_project_id_fe4a93f0_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oplog_oplog
    ADD CONSTRAINT oplog_oplog_project_id_fe4a93f0_fk FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oplog_oplogentry oplog_oplogentry_oplog_id_id_18ef13d0_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.oplog_oplogentry
    ADD CONSTRAINT oplog_oplogentry_oplog_id_id_18ef13d0_fk FOREIGN KEY (oplog_id_id) REFERENCES public.oplog_oplog(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: otp_static_staticdevice otp_static_staticdevice_user_id_7f9cff2b_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_static_staticdevice
    ADD CONSTRAINT otp_static_staticdevice_user_id_7f9cff2b_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: otp_static_statictoken otp_static_statictok_device_id_74b7c7d1_fk_otp_stati; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_static_statictoken
    ADD CONSTRAINT otp_static_statictok_device_id_74b7c7d1_fk_otp_stati FOREIGN KEY (device_id) REFERENCES public.otp_static_staticdevice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: otp_totp_totpdevice otp_totp_totpdevice_user_id_0fb18292_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.otp_totp_totpdevice
    ADD CONSTRAINT otp_totp_totpdevice_user_id_0fb18292_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_archive reporting_archive_project_id_e00a60e1_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_archive
    ADD CONSTRAINT reporting_archive_project_id_e00a60e1_fk FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_evidence reporting_evidence_finding_id_00138d5b_fk_reporting; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_evidence
    ADD CONSTRAINT reporting_evidence_finding_id_00138d5b_fk_reporting FOREIGN KEY (finding_id) REFERENCES public.reporting_reportfindinglink(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_evidence reporting_evidence_report_id_e9637ec2_fk_reporting_report_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_evidence
    ADD CONSTRAINT reporting_evidence_report_id_e9637ec2_fk_reporting_report_id FOREIGN KEY (report_id) REFERENCES public.reporting_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_evidence reporting_evidence_uploaded_by_id_71b7b76f_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_evidence
    ADD CONSTRAINT reporting_evidence_uploaded_by_id_71b7b76f_fk FOREIGN KEY (uploaded_by_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_finding reporting_finding_finding_type_id_576232af_fk_reporting; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_finding
    ADD CONSTRAINT reporting_finding_finding_type_id_576232af_fk_reporting FOREIGN KEY (finding_type_id) REFERENCES public.reporting_findingtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_finding reporting_finding_severity_id_c4aea0a2_fk_reporting_severity_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_finding
    ADD CONSTRAINT reporting_finding_severity_id_c4aea0a2_fk_reporting_severity_id FOREIGN KEY (severity_id) REFERENCES public.reporting_severity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_findingnote reporting_findingnote_finding_id_e9bb21d2_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_findingnote
    ADD CONSTRAINT reporting_findingnote_finding_id_e9bb21d2_fk FOREIGN KEY (finding_id) REFERENCES public.reporting_finding(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_findingnote reporting_findingnote_operator_id_ec6a14fc_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_findingnote
    ADD CONSTRAINT reporting_findingnote_operator_id_ec6a14fc_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_localfindingnote reporting_localfindingnote_finding_id_667858fe_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_localfindingnote
    ADD CONSTRAINT reporting_localfindingnote_finding_id_667858fe_fk FOREIGN KEY (finding_id) REFERENCES public.reporting_reportfindinglink(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_localfindingnote reporting_localfindingnote_operator_id_ccc74743_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_localfindingnote
    ADD CONSTRAINT reporting_localfindingnote_operator_id_ccc74743_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_report reporting_report_created_by_id_1c6d7e8d_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_report
    ADD CONSTRAINT reporting_report_created_by_id_1c6d7e8d_fk FOREIGN KEY (created_by_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_report reporting_report_docx_template_id_f9bf3a47_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_report
    ADD CONSTRAINT reporting_report_docx_template_id_f9bf3a47_fk FOREIGN KEY (docx_template_id) REFERENCES public.reporting_reporttemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_report reporting_report_pptx_template_id_b818b902_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_report
    ADD CONSTRAINT reporting_report_pptx_template_id_b818b902_fk FOREIGN KEY (pptx_template_id) REFERENCES public.reporting_reporttemplate(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_report reporting_report_project_id_8d586862_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_report
    ADD CONSTRAINT reporting_report_project_id_8d586862_fk FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reportfindinglink reporting_reportfind_finding_type_id_b165acad_fk_reporting; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reportfindinglink
    ADD CONSTRAINT reporting_reportfind_finding_type_id_b165acad_fk_reporting FOREIGN KEY (finding_type_id) REFERENCES public.reporting_findingtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reportfindinglink reporting_reportfind_severity_id_ed92c09e_fk_reporting; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reportfindinglink
    ADD CONSTRAINT reporting_reportfind_severity_id_ed92c09e_fk_reporting FOREIGN KEY (severity_id) REFERENCES public.reporting_severity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reportfindinglink reporting_reportfindinglink_assigned_to_id_586a64f4_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reportfindinglink
    ADD CONSTRAINT reporting_reportfindinglink_assigned_to_id_586a64f4_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reportfindinglink reporting_reportfindinglink_report_id_173cdfe4_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reportfindinglink
    ADD CONSTRAINT reporting_reportfindinglink_report_id_173cdfe4_fk FOREIGN KEY (report_id) REFERENCES public.reporting_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reportobservationlink reporting_reportobse_report_id_bf40bf64_fk_reporting; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reportobservationlink
    ADD CONSTRAINT reporting_reportobse_report_id_bf40bf64_fk_reporting FOREIGN KEY (report_id) REFERENCES public.reporting_report(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reportobservationlink reporting_reportobservationlink_assigned_to_id_a155d68d_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reportobservationlink
    ADD CONSTRAINT reporting_reportobservationlink_assigned_to_id_a155d68d_fk FOREIGN KEY (assigned_to_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reporttemplate reporting_reporttemplate_client_id_119d84a5_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reporttemplate
    ADD CONSTRAINT reporting_reporttemplate_client_id_119d84a5_fk FOREIGN KEY (client_id) REFERENCES public.rolodex_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reporttemplate reporting_reporttemplate_doc_type_id_6e8237de_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reporttemplate
    ADD CONSTRAINT reporting_reporttemplate_doc_type_id_6e8237de_fk FOREIGN KEY (doc_type_id) REFERENCES public.reporting_doctype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: reporting_reporttemplate reporting_reporttemplate_uploaded_by_id_03b1497c_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reporting_reporttemplate
    ADD CONSTRAINT reporting_reporttemplate_uploaded_by_id_03b1497c_fk FOREIGN KEY (uploaded_by_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_clientcontact rolodex_clientcontact_client_id_48f1bd5e_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientcontact
    ADD CONSTRAINT rolodex_clientcontact_client_id_48f1bd5e_fk FOREIGN KEY (client_id) REFERENCES public.rolodex_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_clientinvite rolodex_clientinvite_client_id_5d0aef60_fk_rolodex_client_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientinvite
    ADD CONSTRAINT rolodex_clientinvite_client_id_5d0aef60_fk_rolodex_client_id FOREIGN KEY (client_id) REFERENCES public.rolodex_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_clientinvite rolodex_clientinvite_user_id_7ca0ba49_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientinvite
    ADD CONSTRAINT rolodex_clientinvite_user_id_7ca0ba49_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_clientnote rolodex_clientnote_client_id_c2ca9488_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientnote
    ADD CONSTRAINT rolodex_clientnote_client_id_c2ca9488_fk FOREIGN KEY (client_id) REFERENCES public.rolodex_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_clientnote rolodex_clientnote_operator_id_739d4005_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_clientnote
    ADD CONSTRAINT rolodex_clientnote_operator_id_739d4005_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_deconfliction rolodex_deconflictio_status_id_a282790f_fk_rolodex_d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_deconfliction
    ADD CONSTRAINT rolodex_deconflictio_status_id_a282790f_fk_rolodex_d FOREIGN KEY (status_id) REFERENCES public.rolodex_deconflictionstatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_deconfliction rolodex_deconfliction_project_id_be3e6403_fk_rolodex_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_deconfliction
    ADD CONSTRAINT rolodex_deconfliction_project_id_be3e6403_fk_rolodex_project_id FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_project rolodex_project_client_id_ebd2cbf5_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_project
    ADD CONSTRAINT rolodex_project_client_id_ebd2cbf5_fk FOREIGN KEY (client_id) REFERENCES public.rolodex_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_project rolodex_project_operator_id_9e407adf_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_project
    ADD CONSTRAINT rolodex_project_operator_id_9e407adf_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_project rolodex_project_project_type_id_07953f1d_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_project
    ADD CONSTRAINT rolodex_project_project_type_id_07953f1d_fk FOREIGN KEY (project_type_id) REFERENCES public.rolodex_projecttype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectassignment rolodex_projectassignment_operator_id_c4c462d8_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectassignment
    ADD CONSTRAINT rolodex_projectassignment_operator_id_c4c462d8_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectassignment rolodex_projectassignment_project_id_ce701acc_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectassignment
    ADD CONSTRAINT rolodex_projectassignment_project_id_ce701acc_fk FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectassignment rolodex_projectassignment_role_id_cbab79b0_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectassignment
    ADD CONSTRAINT rolodex_projectassignment_role_id_cbab79b0_fk FOREIGN KEY (role_id) REFERENCES public.rolodex_projectrole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectcontact rolodex_projectconta_project_id_f7320727_fk_rolodex_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectcontact
    ADD CONSTRAINT rolodex_projectconta_project_id_f7320727_fk_rolodex_p FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectinvite rolodex_projectinvite_project_id_d510b642_fk_rolodex_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectinvite
    ADD CONSTRAINT rolodex_projectinvite_project_id_d510b642_fk_rolodex_project_id FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectinvite rolodex_projectinvite_user_id_13704bd9_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectinvite
    ADD CONSTRAINT rolodex_projectinvite_user_id_13704bd9_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectnote rolodex_projectnote_operator_id_5b9299b1_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectnote
    ADD CONSTRAINT rolodex_projectnote_operator_id_5b9299b1_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectnote rolodex_projectnote_project_id_79acb8a5_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectnote
    ADD CONSTRAINT rolodex_projectnote_project_id_79acb8a5_fk FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectobjective rolodex_projectobjective_priority_id_cf6de852_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectobjective
    ADD CONSTRAINT rolodex_projectobjective_priority_id_cf6de852_fk FOREIGN KEY (priority_id) REFERENCES public.rolodex_objectivepriority(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectobjective rolodex_projectobjective_project_id_62b27a4b_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectobjective
    ADD CONSTRAINT rolodex_projectobjective_project_id_62b27a4b_fk FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectobjective rolodex_projectobjective_status_id_98de9086_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectobjective
    ADD CONSTRAINT rolodex_projectobjective_status_id_98de9086_fk FOREIGN KEY (status_id) REFERENCES public.rolodex_objectivestatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectscope rolodex_projectscope_project_id_dcf53f05_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectscope
    ADD CONSTRAINT rolodex_projectscope_project_id_dcf53f05_fk FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectsubtask rolodex_projectsubtask_parent_id_63a99f77_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectsubtask
    ADD CONSTRAINT rolodex_projectsubtask_parent_id_63a99f77_fk FOREIGN KEY (parent_id) REFERENCES public.rolodex_projectobjective(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projectsubtask rolodex_projectsubtask_status_id_c5e132c9_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projectsubtask
    ADD CONSTRAINT rolodex_projectsubtask_status_id_c5e132c9_fk FOREIGN KEY (status_id) REFERENCES public.rolodex_objectivestatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_projecttarget rolodex_projecttarget_project_id_69dd3e2f_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_projecttarget
    ADD CONSTRAINT rolodex_projecttarget_project_id_69dd3e2f_fk FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: rolodex_whitecard rolodex_whitecard_project_id_772a701c_fk_rolodex_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rolodex_whitecard
    ADD CONSTRAINT rolodex_whitecard_project_id_772a701c_fk_rolodex_project_id FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_auxserveraddress shepherd_auxserveraddress_static_server_id_5112503d_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_auxserveraddress
    ADD CONSTRAINT shepherd_auxserveraddress_static_server_id_5112503d_fk FOREIGN KEY (static_server_id) REFERENCES public.shepherd_staticserver(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domain shepherd_domain_domain_status_id_a2fa7330_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domain
    ADD CONSTRAINT shepherd_domain_domain_status_id_a2fa7330_fk FOREIGN KEY (domain_status_id) REFERENCES public.shepherd_domainstatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domain shepherd_domain_health_status_id_cebe65d3_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domain
    ADD CONSTRAINT shepherd_domain_health_status_id_cebe65d3_fk FOREIGN KEY (health_status_id) REFERENCES public.shepherd_healthstatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domain shepherd_domain_last_used_by_id_119db0c5_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domain
    ADD CONSTRAINT shepherd_domain_last_used_by_id_119db0c5_fk FOREIGN KEY (last_used_by_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domain shepherd_domain_whois_status_id_a0721cb6_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domain
    ADD CONSTRAINT shepherd_domain_whois_status_id_a0721cb6_fk FOREIGN KEY (whois_status_id) REFERENCES public.shepherd_whoisstatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domainnote shepherd_domainnote_domain_id_9e6a4961_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainnote
    ADD CONSTRAINT shepherd_domainnote_domain_id_9e6a4961_fk FOREIGN KEY (domain_id) REFERENCES public.shepherd_domain(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domainnote shepherd_domainnote_operator_id_040fcb51_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainnote
    ADD CONSTRAINT shepherd_domainnote_operator_id_040fcb51_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domainserverconnection shepherd_domainserve_project_id_35af0efe_fk_rolodex_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainserverconnection
    ADD CONSTRAINT shepherd_domainserve_project_id_35af0efe_fk_rolodex_p FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domainserverconnection shepherd_domainserverconnection_domain_id_398e22e4_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainserverconnection
    ADD CONSTRAINT shepherd_domainserverconnection_domain_id_398e22e4_fk FOREIGN KEY (domain_id) REFERENCES public.shepherd_history(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domainserverconnection shepherd_domainserverconnection_static_server_id_2ab6ed26_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainserverconnection
    ADD CONSTRAINT shepherd_domainserverconnection_static_server_id_2ab6ed26_fk FOREIGN KEY (static_server_id) REFERENCES public.shepherd_serverhistory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_domainserverconnection shepherd_domainserverconnection_transient_server_id_48f0ff5a_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_domainserverconnection
    ADD CONSTRAINT shepherd_domainserverconnection_transient_server_id_48f0ff5a_fk FOREIGN KEY (transient_server_id) REFERENCES public.shepherd_transientserver(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_history shepherd_history_activity_type_id_a2669c34_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_history
    ADD CONSTRAINT shepherd_history_activity_type_id_a2669c34_fk FOREIGN KEY (activity_type_id) REFERENCES public.shepherd_activitytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_history shepherd_history_client_id_89d8cfd3_fk_rolodex_client_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_history
    ADD CONSTRAINT shepherd_history_client_id_89d8cfd3_fk_rolodex_client_id FOREIGN KEY (client_id) REFERENCES public.rolodex_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_history shepherd_history_domain_id_5ac2c2ca_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_history
    ADD CONSTRAINT shepherd_history_domain_id_5ac2c2ca_fk FOREIGN KEY (domain_id) REFERENCES public.shepherd_domain(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_history shepherd_history_operator_id_0acb0189_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_history
    ADD CONSTRAINT shepherd_history_operator_id_0acb0189_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_history shepherd_history_project_id_1fe0dabb_fk_rolodex_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_history
    ADD CONSTRAINT shepherd_history_project_id_1fe0dabb_fk_rolodex_project_id FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_serverhistory shepherd_serverhisto_project_id_1c40d316_fk_rolodex_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverhistory
    ADD CONSTRAINT shepherd_serverhisto_project_id_1c40d316_fk_rolodex_p FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_serverhistory shepherd_serverhistory_activity_type_id_b8698fb0_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverhistory
    ADD CONSTRAINT shepherd_serverhistory_activity_type_id_b8698fb0_fk FOREIGN KEY (activity_type_id) REFERENCES public.shepherd_activitytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_serverhistory shepherd_serverhistory_client_id_132ff5c2_fk_rolodex_client_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverhistory
    ADD CONSTRAINT shepherd_serverhistory_client_id_132ff5c2_fk_rolodex_client_id FOREIGN KEY (client_id) REFERENCES public.rolodex_client(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_serverhistory shepherd_serverhistory_operator_id_34e8e348_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverhistory
    ADD CONSTRAINT shepherd_serverhistory_operator_id_34e8e348_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_serverhistory shepherd_serverhistory_server_id_cd484fac_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverhistory
    ADD CONSTRAINT shepherd_serverhistory_server_id_cd484fac_fk FOREIGN KEY (server_id) REFERENCES public.shepherd_staticserver(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_serverhistory shepherd_serverhistory_server_role_id_d6b6cc81_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_serverhistory
    ADD CONSTRAINT shepherd_serverhistory_server_role_id_d6b6cc81_fk FOREIGN KEY (server_role_id) REFERENCES public.shepherd_serverrole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_servernote shepherd_servernote_operator_id_0645b3ab_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_servernote
    ADD CONSTRAINT shepherd_servernote_operator_id_0645b3ab_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_servernote shepherd_servernote_server_id_30ba51f2_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_servernote
    ADD CONSTRAINT shepherd_servernote_server_id_30ba51f2_fk FOREIGN KEY (server_id) REFERENCES public.shepherd_staticserver(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_staticserver shepherd_staticserver_last_used_by_id_442a30d9_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_staticserver
    ADD CONSTRAINT shepherd_staticserver_last_used_by_id_442a30d9_fk FOREIGN KEY (last_used_by_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_staticserver shepherd_staticserver_server_provider_id_11a19799_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_staticserver
    ADD CONSTRAINT shepherd_staticserver_server_provider_id_11a19799_fk FOREIGN KEY (server_provider_id) REFERENCES public.shepherd_serverprovider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_staticserver shepherd_staticserver_server_status_id_d41f1ab4_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_staticserver
    ADD CONSTRAINT shepherd_staticserver_server_status_id_d41f1ab4_fk FOREIGN KEY (server_status_id) REFERENCES public.shepherd_serverstatus(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_transientserver shepherd_transientse_project_id_f0e29dd2_fk_rolodex_p; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_transientserver
    ADD CONSTRAINT shepherd_transientse_project_id_f0e29dd2_fk_rolodex_p FOREIGN KEY (project_id) REFERENCES public.rolodex_project(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_transientserver shepherd_transientserver_activity_type_id_97b100c2_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_transientserver
    ADD CONSTRAINT shepherd_transientserver_activity_type_id_97b100c2_fk FOREIGN KEY (activity_type_id) REFERENCES public.shepherd_activitytype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_transientserver shepherd_transientserver_operator_id_d2301a78_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_transientserver
    ADD CONSTRAINT shepherd_transientserver_operator_id_d2301a78_fk FOREIGN KEY (operator_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_transientserver shepherd_transientserver_server_provider_id_e89609a9_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_transientserver
    ADD CONSTRAINT shepherd_transientserver_server_provider_id_e89609a9_fk FOREIGN KEY (server_provider_id) REFERENCES public.shepherd_serverprovider(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: shepherd_transientserver shepherd_transientserver_server_role_id_7e24d482_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.shepherd_transientserver
    ADD CONSTRAINT shepherd_transientserver_server_role_id_7e24d482_fk FOREIGN KEY (server_role_id) REFERENCES public.shepherd_serverrole(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_account_id_951f210e_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_account_id_951f210e_fk_socialacc FOREIGN KEY (account_id) REFERENCES public.socialaccount_socialaccount(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialtoken socialaccount_social_app_id_636a42d7_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialtoken
    ADD CONSTRAINT socialaccount_social_app_id_636a42d7_fk_socialacc FOREIGN KEY (app_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_site_id_2579dee5_fk_django_si; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_site_id_2579dee5_fk_django_si FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialapp_sites socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialapp_sites
    ADD CONSTRAINT socialaccount_social_socialapp_id_97fb6e7d_fk_socialacc FOREIGN KEY (socialapp_id) REFERENCES public.socialaccount_socialapp(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: socialaccount_socialaccount socialaccount_socialaccount_user_id_8146e70c_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.socialaccount_socialaccount
    ADD CONSTRAINT socialaccount_socialaccount_user_id_8146e70c_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem taggit_taggeditem_content_type_id_9957a03c_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_content_type_id_9957a03c_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: taggit_taggeditem taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.taggit_taggeditem
    ADD CONSTRAINT taggit_taggeditem_tag_id_f4f5b767_fk_taggit_tag_id FOREIGN KEY (tag_id) REFERENCES public.taggit_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_group_id_9afc8d0e_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_group_id_9afc8d0e_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_groups users_user_groups_user_id_5f6f5a90_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_groups
    ADD CONSTRAINT users_user_groups_user_id_5f6f5a90_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_perm_permission_id_0b93982e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_perm_permission_id_0b93982e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: users_user_user_permissions users_user_user_permissions_user_id_20aca447_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users_user_user_permissions
    ADD CONSTRAINT users_user_user_permissions_user_id_20aca447_fk FOREIGN KEY (user_id) REFERENCES public.users_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

